package kr.keymate.app;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.text.InputFilter;
import android.view.*;
import android.widget.*;
import com.grack.nanojson.*;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;

/** Public discovery and explicit posting. The playback engine and private notes remain independent. */
final class CommunityUi implements AutoCloseable {
 interface Importer {boolean save(CommunityData.ListItem item,boolean keys);}
 private final Activity a;private final Supplier<Playlists> library;private final BiConsumer<Song,Integer> play;private final Importer importer;private final Runnable privacy;
 private final SharedPreferences prefs;private final ExecutorService io=Executors.newSingleThreadExecutor();private CommunityClient client;
 private final LinearLayout home;private final List<CommunityData.ListItem> feed=new ArrayList<>();private AlertDialog dialog;
 private boolean closed,busy,loaded,feedFailed,feedMore;private String nickname="";private CommunityData.Draft draft;private Intent pendingIntent;
 CommunityUi(Activity activity,Supplier<Playlists> library,BiConsumer<Song,Integer> play,Importer importer,Runnable privacy){
  a=activity;this.library=library;this.play=play;this.importer=importer;this.privacy=privacy;prefs=a.getSharedPreferences("community_ui",Context.MODE_PRIVATE);home=column();
  try{CommunitySecrets secrets=new CommunitySecrets(a);client=new CommunityClient(BuildConfig.COMMUNITY_URL,BuildConfig.COMMUNITY_KEY,new CommunityClient.Store(){public String read(String key)throws IOException{return secrets.read(key);}public void write(String key,String value)throws IOException{secrets.write(key,value);}});
   String raw=prefs.getString("draft",null);if(raw!=null)draft=CommunityData.Draft.decode(raw);
  }catch(IOException ignored){/* Preserve unreadable data; do not claim a connected account. */}
  renderHome();
 }
 LinearLayout home(){return home;}
 private String s(int id,Object...args){return a.getString(id,args);}
 private LinearLayout column(){LinearLayout v=new LinearLayout(a);v.setOrientation(LinearLayout.VERTICAL);v.setPadding(dp(4),dp(12),dp(4),dp(12));return v;}
 private int dp(int value){return SingKeyUi.dp(a,value);}
 private Button button(int label,Runnable click){return SingKeyUi.button(a,s(label),v->click.run(),false);}
 private Button primary(int label,Runnable click){return SingKeyUi.button(a,s(label),v->click.run(),true);}
 private Button quiet(int label,Runnable click){return AppDialog.quiet(a,s(label),v->click.run());}
 private void label(LinearLayout body,int res){TextView text=SingKeyUi.label(a,s(res),14,true);text.setLineSpacing(dp(4),1f);body.addView(text);}
 private void show(String title,LinearLayout body){if(dialog!=null)dialog.dismiss();body.setPadding(dp(24),dp(4),dp(24),dp(12));AppDialog.space(body,12);dialog=new AppDialog(a).setTitle(title).setView(AppDialog.scroll(a,body)).setNegativeButton(R.string.close,null).create();dialog.show();}
 private void toast(int message){Toast.makeText(a,message,Toast.LENGTH_LONG).show();}
 private void error(Exception e){toast(e instanceof CommunityClient.Failure&&((CommunityClient.Failure)e).status==401?R.string.community_sign_in_again:R.string.community_error);}
 private boolean ready(){if(client==null||!client.configured()){toast(R.string.community_not_ready);return false;}return true;}
 private <T> void request(Callable<T> action,Consumer<T> done){request(action,done,e->{});}
 private <T> void request(Callable<T> action,Consumer<T> done,Consumer<Exception> failed){if(closed)return;if(busy){toast(R.string.community_wait);return;}busy=true;renderHome();io.execute(()->{try{T value=action.call();a.runOnUiThread(()->{if(closed)return;busy=false;renderHome();done.accept(value);drainIntent();});}catch(Exception e){a.runOnUiThread(()->{if(closed)return;busy=false;failed.accept(e);renderHome();error(e);drainIntent();});}});}
 private void drainIntent(){if(!busy&&pendingIntent!=null){Intent next=pendingIntent;pendingIntent=null;intent(next);}}
 private CommunityDiscovery.Result discover(CommunityDiscovery.Section section,int offset,List<CommunityData.ListItem> earlier,Set<String> blocked)throws IOException{
  boolean mine=section==CommunityDiscovery.Section.MINE;
  return CommunityDiscovery.load(start->{JsonObject p=new JsonObject();p.put("p_mine",mine);p.put("p_offset",start);return CommunityData.lists(client.rpc("community_feed",p,mine));},earlier,offset,section,blocked);
 }
 private Set<String> blockedOwners(){return new HashSet<>(prefs.getStringSet("blocked",Collections.emptySet()));}
 void refresh(){if(closed||busy||!readyQuiet())return;feedFailed=false;Set<String> blocked=blockedOwners();request(()->discover(null,0,Collections.emptyList(),blocked),result->{feed.clear();feed.addAll(result.items);feedMore=result.hasMore;loaded=true;renderHome();},e->feedFailed=true);}
 private boolean readyQuiet(){return client!=null&&client.configured();}
 private boolean blocked(String owner){return prefs.getStringSet("blocked",Collections.emptySet()).contains(owner);}
 private void gap(LinearLayout body,int height){body.addView(new Space(a),new LinearLayout.LayoutParams(1,dp(height)));}
 private void renderHome(){
  home.removeAllViews();
  if(busy)home.addView(new ProgressBar(a),new LinearLayout.LayoutParams(dp(28),dp(28)));
  homeSection(CommunityDiscovery.Section.PICKS);
  gap(home,24);
  homeSection(CommunityDiscovery.Section.COMMUNITY);
  if(!readyQuiet())label(home,R.string.community_not_ready);
  else if(feedFailed){label(home,R.string.community_error);home.addView(button(R.string.community_refresh,this::refresh));}
  gap(home,12);
 }
 private int sectionTitle(CommunityDiscovery.Section section){return section==CommunityDiscovery.Section.PICKS?R.string.community_picks_title:section==CommunityDiscovery.Section.MINE?R.string.community_mine:R.string.community_title;}
 private int sectionEmpty(CommunityDiscovery.Section section){return section==CommunityDiscovery.Section.PICKS?R.string.community_picks_empty:R.string.community_empty;}
 private void homeSection(CommunityDiscovery.Section section){
  LinearLayout heading=new LinearLayout(a);heading.setGravity(Gravity.CENTER_VERTICAL);
  heading.addView(SingKeyUi.heading(a,s(sectionTitle(section)),20),new LinearLayout.LayoutParams(0,-2,1));
  if(readyQuiet())heading.addView(SingKeyUi.iconButton(a,R.drawable.ic_sk_chevron_right,s(R.string.community_browse)+" · "+s(sectionTitle(section)),v->browseSection(section,0,Collections.emptyList())));
  home.addView(heading);gap(home,12);
  LinearLayout cards=home;
  if(section==CommunityDiscovery.Section.PICKS){
   HorizontalScrollView rail=new HorizontalScrollView(a);rail.setHorizontalScrollBarEnabled(false);
   cards=new LinearLayout(a);cards.setOrientation(LinearLayout.HORIZONTAL);
   rail.addView(cards,new HorizontalScrollView.LayoutParams(-2,-2));home.addView(rail,new LinearLayout.LayoutParams(-1,-2));
  }
  int count=0;for(CommunityData.ListItem item:feed)if(CommunityDiscovery.matches(item,section)&&!blocked(item.owner)&&count<3){
   LinearLayout tile=card(item);
   if(section==CommunityDiscovery.Section.PICKS){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(248),-1);lp.rightMargin=dp(12);tile.setLayoutParams(lp);}
   cards.addView(tile);count++;
  }
  if(count==0&&readyQuiet()&&!feedFailed){if(!loaded)label(home,R.string.community_loading);else if(!feedMore)label(home,sectionEmpty(section));}
  if(section==CommunityDiscovery.Section.COMMUNITY&&readyQuiet()){gap(home,8);home.addView(button(R.string.community_publish,this::chooseList));}
 }
 private LinearLayout card(CommunityData.ListItem item){LinearLayout body=SingKeyUi.card(a);
  if(item.curated)body.setBackground(SingKeyUi.outline(a,0xff1b2417,14,0xff46582c));
  body.addView(SingKeyUi.heading(a,item.title,18));gap(body,8);
  for(int i=0;i<Math.min(2,item.tracks.size());i++){TextView title=SingKeyUi.label(a,item.tracks.get(i).title,13,true);title.setMaxLines(2);title.setEllipsize(android.text.TextUtils.TruncateAt.END);body.addView(title);}
  gap(body,12);
  body.addView(SingKeyUi.label(a,item.curated?a.getResources().getQuantityString(R.plurals.community_picks_count,item.tracks.size(),item.tracks.size()):s(R.string.community_author,item.nickname,item.tracks.size(),item.likes),12,true));
  body.setOnClickListener(v->open(item.id));SingKeyUi.feedback(body,14);return body;}
 void browse(boolean mine,int offset,List<CommunityData.ListItem> earlier){browseSection(mine?CommunityDiscovery.Section.MINE:CommunityDiscovery.Section.COMMUNITY,offset,earlier);}
 private void browseSection(CommunityDiscovery.Section section,int offset,List<CommunityData.ListItem> earlier){if(!ready())return;if(section==CommunityDiscovery.Section.MINE&&!client.signedIn()){account();return;}
  Set<String> blocked=blockedOwners();
  request(()->discover(section,offset,earlier,blocked),result->{LinearLayout body=column();for(CommunityData.ListItem item:result.items)if(!blocked(item.owner))body.addView(card(item));if(result.items.isEmpty()&&!result.hasMore)label(body,sectionEmpty(section));if(result.hasMore)body.addView(button(R.string.community_more,()->browseSection(section,result.nextOffset,result.items)));body.addView(button(R.string.community_refresh,()->browseSection(section,0,Collections.emptyList())));show(s(sectionTitle(section)),body);});
 }
 void open(String id){open(id,false);}
 private void open(String id,boolean refreshHome){if(!ready())return;try{CommunityData.uuid(id);}catch(IOException e){error(e);return;}JsonObject p=new JsonObject();p.put("p_id",id);
  request(()->CommunityData.lists(client.rpc("community_feed",p,false)),items->{if(items.isEmpty()||blocked(items.get(0).owner)){toast(R.string.community_unavailable);refresh();return;}detail(items.get(0));if(refreshHome)refresh();});
 }
 private void detail(CommunityData.ListItem item){LinearLayout body=column();body.addView(SingKeyUi.label(a,s(R.string.community_author,item.nickname,item.tracks.size(),item.likes),13,true));
  label(body,R.string.community_play_key);for(CommunityData.Track track:item.tracks){LinearLayout row=new LinearLayout(a);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(0,dp(8),0,dp(8));LinearLayout info=column();info.setPadding(0,0,dp(12),0);info.addView(SingKeyUi.heading(a,track.title,15));if(track.key!=null){TextView key=SingKeyUi.label(a,s(R.string.community_shared_key,track.key>0?"+"+track.key:""+track.key),13,true);key.setPadding(0,dp(4),0,0);info.addView(key);}row.addView(info,new LinearLayout.LayoutParams(0,-2,1));Button playButton=SingKeyUi.iconButton(a,R.drawable.ic_sk_play,s(R.string.play)+" · "+track.title,v->{if(dialog!=null)dialog.dismiss();play.accept(track.song(),localKey(track));});row.addView(playButton);body.addView(row);}
  body.addView(primary(R.string.community_import,()->importList(item)));
  body.addView(SingKeyUi.button(a,s(item.liked?R.string.community_unlike:R.string.community_like),v->withMember(()->{JsonObject p=new JsonObject();p.put("p_id",item.id);p.put("p_liked",!item.liked);request(()->client.rpc("community_like",p,true),x->open(item.id,true));}),false));
  body.addView(button(R.string.community_share,()->share(item)));
  if(client!=null&&item.owner.equals(client.userId()))body.addView(quiet(R.string.community_withdraw,()->confirm(R.string.community_withdraw_confirm,()->{JsonObject p=new JsonObject();p.put("p_id",item.id);request(()->client.rpc("community_withdraw",p,true),v->{if(dialog!=null)dialog.dismiss();refresh();});})));
  else{body.addView(quiet(R.string.community_report,()->report(item)));body.addView(quiet(R.string.community_block,()->confirm(R.string.community_block_confirm,()->block(item))));}
  show(item.title,body);
 }
 private int localKey(CommunityData.Track t){Playlists lists=library.get();if(lists!=null)for(Playlists.ListEntry l:lists.entries()){SavedSongs.Entry e=l.songs.find(t.song().url);if(e!=null)return e.key;}return 0;}
 private void importList(CommunityData.ListItem item){LinearLayout body=column();label(body,R.string.community_import_help);CheckBox keys=new CheckBox(a);keys.setText(R.string.community_use_keys);AppDialog.choice(keys);body.addView(keys);body.addView(primary(R.string.community_import,()->{if(importer.save(item,keys.isChecked())){toast(R.string.community_imported);if(dialog!=null)dialog.dismiss();}}));show(item.title,body);}
 private void share(CommunityData.ListItem item){if(BuildConfig.COMMUNITY_WEB_URL.isEmpty()){toast(R.string.community_link_not_ready);return;}Intent send=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,item.title+"\n"+BuildConfig.COMMUNITY_WEB_URL+"?list="+item.id);a.startActivity(Intent.createChooser(send,s(R.string.community_share)));}
 void chooseList(){Playlists lists=library.get();if(lists==null){toast(R.string.library_unreadable);return;}if(draft!=null){preview();return;}List<Playlists.ListEntry> options=new ArrayList<>();for(Playlists.ListEntry l:lists.entries())if(!l.songs.entries().isEmpty())options.add(l);if(options.isEmpty()){toast(R.string.community_need_songs);return;}String[] names=new String[options.size()];for(int i=0;i<names.length;i++)names[i]=options.get(i).name;new AppDialog(a).setTitle(R.string.community_select_list).setItems(names,(d,w)->compose(options.get(w))).setNegativeButton(R.string.cancel,null).show();}
 void compose(Playlists.ListEntry list){LinearLayout body=column();label(body,R.string.community_publish_help);EditText title=new EditText(a);title.setHint(R.string.community_list_title);title.setContentDescription(s(R.string.community_list_title));SingKeyUi.field(title);title.setFilters(new InputFilter[]{new InputFilter.LengthFilter(80)});title.setSingleLine();title.setText(list.name);AppDialog.fieldLabel(body,R.string.community_list_title,title);body.addView(title);
  List<CommunityData.Track> tracks=new ArrayList<>();List<CheckBox> choices=new ArrayList<>();
  for(SavedSongs.Entry e:list.songs.entries()){String canonical=SearchSafety.canonicalVideo(e.song.url);if(canonical==null)continue;try{CommunityData.Track t=new CommunityData.Track(canonical.substring(canonical.length()-11),e.song.title,e.key);tracks.add(t);CheckBox cb=new CheckBox(a);cb.setText(t.title);AppDialog.choice(cb);cb.setChecked(list.songs.entries().size()<=50);choices.add(cb);body.addView(cb);}catch(IOException ignored){}}
  CheckBox keys=new CheckBox(a);keys.setText(R.string.community_show_keys);AppDialog.choice(keys);body.addView(keys);
  body.addView(primary(R.string.community_preview,()->{List<CommunityData.Track> picked=new ArrayList<>();for(int i=0;i<tracks.size();i++)if(choices.get(i).isChecked())picked.add(tracks.get(i));try{CommunityData.Draft next=new CommunityData.Draft(UUID.randomUUID().toString(),title.getText().toString(),picked,keys.isChecked());if(!prefs.edit().putString("draft",next.encode()).commit())throw new IOException("Save failed");draft=next;preview();}catch(IOException e){toast(R.string.community_invalid_draft);}}));show(s(R.string.community_publish),body);
 }
 private void preview(){if(draft==null)return;CommunityData.Draft captured=draft;LinearLayout body=column();label(body,R.string.community_preview_help);body.addView(SingKeyUi.heading(a,captured.title,20));for(CommunityData.Track t:captured.tracks)body.addView(SingKeyUi.label(a,t.title+(captured.shareKeys&&t.key!=null?" · "+s(R.string.community_shared_key,t.key>0?"+"+t.key:""+t.key):""),14,false));
  body.addView(primary(R.string.community_post_now,()->withMember(()->{request(()->client.rpc("community_publish",captured.json(),true),raw->{try{String id=JsonParser.any().from(raw).toString();CommunityData.uuid(id);prefs.edit().remove("draft").apply();draft=null;toast(R.string.community_posted);open(id,true);}catch(Exception e){error(e);}});})));body.addView(quiet(R.string.community_discard,()->{if(prefs.edit().remove("draft").commit()){draft=null;if(dialog!=null)dialog.dismiss();chooseList();}else toast(R.string.save_failed);}));show(s(R.string.community_preview),body);}
 private void withMember(Runnable next){if(!ready())return;if(!client.signedIn()){account();return;}request(()->CommunityClient.parse(client.rpc("community_profile",new JsonObject(),true)),profile->{nickname=profile.getString("nickname","");if(nickname.isEmpty())profile(next);else next.run();});}
 private void profile(Runnable next){LinearLayout body=column();label(body,R.string.community_profile_help);EditText name=new EditText(a);name.setHint(R.string.community_nickname);name.setContentDescription(s(R.string.community_nickname));name.setSingleLine();name.setText(nickname);name.setFilters(new InputFilter[]{new InputFilter.LengthFilter(24)});SingKeyUi.field(name);AppDialog.fieldLabel(body,R.string.community_nickname,name);body.addView(name);label(body,R.string.community_rules);CheckBox agree=new CheckBox(a);agree.setText(R.string.community_agree);AppDialog.choice(agree);body.addView(agree);body.addView(primary(R.string.save,()->{String n=name.getText().toString().trim();if(!CommunityData.text(n,24)||!agree.isChecked()){toast(R.string.community_profile_required);return;}JsonObject p=new JsonObject();p.put("p_nickname",n);p.put("p_rules",CommunityData.RULES_VERSION);request(()->client.rpc("community_profile",p,true),v->{nickname=n;if(dialog!=null)dialog.dismiss();next.run();});}));show(s(R.string.community_profile),body);}
 void account(){LinearLayout body=column();if(client==null||!client.signedIn()){label(body,R.string.community_login_help);Button kakao=button(R.string.community_kakao,()->login("kakao"));kakao.setTextColor(0xff191919);kakao.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xfffee500));body.addView(kakao);body.addView(button(R.string.community_google,()->login("google")));}
  else{label(body,R.string.community_signed_in);body.addView(button(R.string.community_profile,()->request(()->CommunityClient.parse(client.rpc("community_profile",new JsonObject(),true)),p->{nickname=p.getString("nickname","");profile(this::account); })));body.addView(button(R.string.community_mine,()->withMember(()->browse(true,0,new ArrayList<>()))));body.addView(button(R.string.community_blocked,()->blockedAccounts()));body.addView(button(R.string.community_logout,()->request(()->{client.logout();return true;},v->{nickname="";if(dialog!=null)dialog.dismiss();refresh();})));
   body.addView(quiet(R.string.community_delete_account,()->confirm(R.string.community_delete_confirm,()->{JsonObject p=new JsonObject();p.put("p_confirmation","DELETE");request(()->{client.rpc("community_delete_account",p,true);client.clear();return true;},v->{nickname="";if(dialog!=null)dialog.dismiss();toast(R.string.community_deleted);refresh();});})));}
  if(!prefs.getStringSet("blocked",Collections.emptySet()).isEmpty())body.addView(button(R.string.community_clear_local_blocks,()->{prefs.edit().remove("blocked").apply();renderHome();account();}));
  body.addView(quiet(R.string.privacy,privacy));if(draft!=null)body.addView(button(R.string.community_resume_draft,this::preview));show(s(R.string.community_account),body);
 }
 private void login(String provider){if(!ready())return;request(()->client.begin(provider,a.getPackageName()),url->{try{a.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE));}catch(ActivityNotFoundException e){error(e);}});}
 boolean intent(Intent intent){if(intent==null||intent.getData()==null)return false;Uri uri=intent.getData();boolean auth=(a.getPackageName()+".auth").equals(uri.getScheme())&&"callback".equals(uri.getHost());boolean list=(a.getPackageName()+".lists").equals(uri.getScheme())&&"playlist".equals(uri.getHost());if(!auth&&!list)return false;
  // A home refresh may still be running when the browser returns. Never discard its one-time code.
  if(busy){if(pendingIntent==null||auth)pendingIntent=new Intent(intent);return true;}
  if(auth){if(!ready())return true;request(()->{client.finish(uri.toString(),a.getPackageName());return true;},v->{toast(R.string.community_login_done);if(draft!=null)preview();else account();refresh();});return true;}
  open(uri.getLastPathSegment());return true;}
 private void report(CommunityData.ListItem item){withMember(()->{String[] reasons={s(R.string.community_report_spam),s(R.string.community_report_inappropriate),s(R.string.community_report_rights),s(R.string.community_report_other)};String[] values={"spam","inappropriate","rights","other"};new AppDialog(a).setTitle(R.string.community_report).setItems(reasons,(d,w)->{JsonObject p=new JsonObject();p.put("p_id",item.id);p.put("p_reason",values[w]);request(()->client.rpc("community_report",p,true),v->toast(R.string.community_reported));}).setNegativeButton(R.string.cancel,null).show();});}
 private void block(CommunityData.ListItem item){if(client!=null&&client.signedIn()){withMember(()->{JsonObject p=new JsonObject();p.put("p_owner",item.owner);p.put("p_blocked",true);request(()->client.rpc("community_block",p,true),v->{if(dialog!=null)dialog.dismiss();refresh();});});}else{Set<String> ids=new HashSet<>(prefs.getStringSet("blocked",Collections.emptySet()));ids.add(item.owner);if(!prefs.edit().putStringSet("blocked",ids).commit()){toast(R.string.save_failed);return;}if(dialog!=null)dialog.dismiss();renderHome();}}
 private void blockedAccounts(){withMember(()->request(()->JsonParser.array().from(client.rpc("community_blocks",new JsonObject(),true)),items->{LinearLayout body=column();if(items.isEmpty())label(body,R.string.community_no_blocks);for(Object value:items){JsonObject item=(JsonObject)value;body.addView(SingKeyUi.button(a,item.getString("nickname")+" · "+s(R.string.community_unblock),v->{JsonObject p=new JsonObject();p.put("p_owner",item.getString("id"));p.put("p_blocked",false);request(()->client.rpc("community_block",p,true),x->{blockedAccounts();refresh();});},false));}show(s(R.string.community_blocked),body);}));}
 private void confirm(int message,Runnable next){new AppDialog(a).destructive(AlertDialog.BUTTON_POSITIVE).setMessage(message).setPositiveButton(R.string.community_confirm,(d,w)->next.run()).setNegativeButton(R.string.cancel,null).show();}
 @Override public void close(){closed=true;if(dialog!=null)dialog.dismiss();io.shutdownNow();if(client!=null)client.close();}
}
