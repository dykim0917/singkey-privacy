package kr.keymate.app;

import android.app.Activity;
import android.app.AlertDialog;
import java.util.ArrayList;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Build;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.graphics.Color;
import android.net.Uri;
import android.view.View;
import android.widget.*;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
 private PlaybackPlayer player;
 private UsageAnalytics usage;
 private AdvertisingConsent advertisingConsent;
 private BannerSlot homeAd,portraitAd;
 private boolean analyticsTrackStarted,settingPlaybackKey;
 private final ThumbnailLoader thumbnails = new ThumbnailLoader();
 private SearchInput link;
 private SearchSuggestions suggestionSource;
 private AppLanguage language;
 private boolean preferBacking=true, syncingSearchOptions, recordHistory=true;
 private boolean allowQueryRecord=true;
 private boolean recordSearches=true,searchHistoryReadable=true,practiceReady,resumePending;
 private RecentQueries recentQueries=new RecentQueries();
 private final SearchPages searchPages=new SearchPages();
 private EmbedAvailability embedAvailability;
 private String currentSearchQuery="";
 private Runnable refreshSearchResults;
 private PlaybackFeedback searchPlaybackFeedback;
 private boolean findingAlternative;
 private long resumePosition;
 private Button resumeButton,landscapeResumeButton;
 private boolean showRecommendations=true;
 private final PracticeRecommendations recommendations=new PracticeRecommendations();
 private LinearLayout recommendationView;
 private static final String PROCESS_ID=java.util.UUID.randomUUID().toString();
 private String lastPracticeSnapshot="";
 private final Runnable persistPractice=()->savePractice(false);
 private final Runnable practiceClock=new Runnable(){public void run(){if(foreground){if(player.isPlaying())savePractice(false);historyHandler.postDelayed(this,5000);}}};
 private SongNotesUi songNotes;
 private CommunityUi community;
 private TextView songNoteSummary;
 private Button previousNoteKey;
 private final ArrayList<Button> noteButtons=new ArrayList<>();
 private String helpReturnPage="home";
 private boolean resumeAfterRecreation;
 private CheckBox homeSearchOption, portraitSearchOption, splitSearchOption;
 private String lastSubmittedQuery="";
 private boolean cachedBacking=true;
 private TextView status, keyLabel;
 private Button open;
 private LinearLayout queueView;
 private TextView queueLabel;
 private final ArrayList<SavedSongs.Entry> queue = new ArrayList<>();
 private Song currentSong;
 private boolean loading;
 private boolean loadFailed;
 private PlaybackFeedback playbackFeedback;
 private Playlists playlists;
 private boolean savedSongsReadable = true;
 private final ArrayList<Button> saveButtons = new ArrayList<>();
 private AlertDialog savedSongsDialog;
 private PlayerRefreshLayout videoSlot;
 private boolean portraitPlayerSearch,compactPlayerHeader;
 private Button portraitSearchButton,portraitFullscreenButton;
 private final ExecutorService searchWorker = Executors.newSingleThreadExecutor();
 private int key = 0, generation = 0;
 private boolean foreground = false;
 private final ExecutorService worker = Executors.newSingleThreadExecutor();
 private final int ink = SingKeyUi.INK;
 private LinearLayout column, homePage, searchPage, playerPage, libraryPage, helpPage, settingsPage, contactPage, infoPage, chrome, miniBar, navBar, recentView;
 private TextView miniTitle;
 private LinearLayout featuredView;
 private final FeaturedSongs chartSource=new FeaturedSongs();
 private final ExecutorService chartWorker=Executors.newFixedThreadPool(2);
 private HomeFeed homeFeed;
 private TextView miniKey, trackChannel;
 private ImageView miniArt;
 private LinearLayout landscapeTop;
 private final ArrayList<Button> iconSaveButtons = new ArrayList<>();
 private Button miniToggle, nextButton;
 private String activePage = "home", returnPage = "home";
 private Playlists.ListEntry selectedList;
 private RecentSongs recent = new RecentSongs();
 private boolean recordedCurrent;
 private final android.os.Handler historyHandler = new android.os.Handler(android.os.Looper.getMainLooper());
 private final Runnable persistRecent = () -> { try { getPreferences(MODE_PRIVATE).edit().putString("recent",recent.encode()).apply(); } catch (java.io.IOException ignored) {} };
 private FrameLayout root, fullScreenLayer;
 private ScrollView scroll;
 private PlaybackPlayer videoView;
 private TextView fullKeyLabel;
 private TextView nextQueueMarquee;
 private int landscapeInsetLeft, landscapeInsetRight, landscapeInsetTop;
 private LinearLayout sideControls;
 private ScrollView sideScroll;
 private LinearLayout sidePanel, splitQueue;
 private LinearLayout landscapeLibrary;
 private ScrollView libraryScroll;
 private Playlists.ListEntry landscapeList;
 private int libraryFolderScroll;
 private Runnable closeLibrary;
 private LinearLayout splitSearchContent;
 private ScrollView splitQueueScroll;
 private Button splitSearchTab, splitQueueTab;
 private TextView splitKeyLabel;
 private Runnable closeSearch;
 private SearchInput activeSearchInput;
 private Button activeSearchButton;
 private String cachedQuery = "";
 private java.util.List<Song> cachedResults = null;
 private int splitWidth;
 private void handleFullScreenBack() {
  if (closeLibrary != null) {
   if (landscapeList != null) { landscapeList=null;renderLandscapeLibrary();ScrollView folders=libraryScroll;folders.post(()->folders.scrollTo(0,libraryFolderScroll)); }
   else closeLibrary.run();
  } else if (closeSearch != null) closeSearch.run(); else leaveFullScreen();
 }
 private boolean fullScreen = false;
 private OnBackInvokedCallback fullScreenBack;
 @Override protected void attachBaseContext(android.content.Context base) {
  // Override only language; copying the entire configuration would freeze screen
  // dimensions and interfere with landscape/keyboard layout changes.
  Configuration config=new Configuration();
  // Resource locales may already be reordered to the best supported match.
  // Use the user's actual first preference, so e.g. fr,ko still falls back to English.
  AppLanguage selected=LanguagePreferences.resolve(base);
  config.setLocales(new android.os.LocaleList(selected.locale()));
  super.attachBaseContext(base.createConfigurationContext(config));
 }
 @Override public void onCreate(Bundle saved) {
  // The OS owns the launch screen; restore the normal theme without a second splash or delay.
  setTheme(R.style.SingKeyTheme);
  super.onCreate(saved);
  songNotes=new SongNotesUi(this,this::onSongNotesChanged);
  usage=new UsageAnalytics(this);
  advertisingConsent=new AdvertisingConsent(this,this::updateAdvertising);
  language=AppLanguage.from(getResources().getConfiguration().getLocales().get(0));
  embedAvailability=new EmbedAvailability(new YouTubeEmbedStatus(BuildConfig.YOUTUBE_DATA_API_KEY,getPackageName(),AndroidApiIdentity.certificate(this)),System::currentTimeMillis,getPreferences(MODE_PRIVATE).getString("embedBlocked",null),value->getPreferences(MODE_PRIVATE).edit().putString("embedBlocked",value).apply());
  suggestionSource=new SearchSuggestions(language);
  preferBacking=getPreferences(MODE_PRIVATE).getBoolean("preferBacking",true);
  recordHistory=getPreferences(MODE_PRIVATE).getBoolean("recordHistory",true);
  recordSearches=getPreferences(MODE_PRIVATE).getBoolean("recordSearches",true);
  showRecommendations=getPreferences(MODE_PRIVATE).getBoolean("showRecommendations",true);
  if(saved!=null)recommendations.restore(saved.getStringArrayList("recommendationSelection"),saved.getStringArrayList("recommendationSeen"));
  try{recentQueries=RecentQueries.decode(getPreferences(MODE_PRIVATE).getString("recentQueries",null));}catch(java.io.IOException ignored){searchHistoryReadable=false;}
  boolean sameProcess=saved!=null&&PROCESS_ID.equals(saved.getString("processId"));
  PracticeSession recovered=null;if(!sameProcess)try{recovered=PracticeSession.decode(getPreferences(MODE_PRIVATE).getString("practiceSession",null));}catch(java.io.IOException ignored){/* Preserve other local data and the unreadable snapshot. */}
  if (Build.VERSION.SDK_INT >= 33) fullScreenBack = () -> navigateBack();
  try { recent = RecentSongs.decode(getPreferences(MODE_PRIVATE).getString("recent", "")); } catch (java.io.IOException ignored) {}
  try { playlists = Playlists.restore(getPreferences(MODE_PRIVATE).getString("playlists", null), getPreferences(MODE_PRIVATE).getString("savedSongs", "")); }
  catch (java.io.IOException e) { playlists = new Playlists(); savedSongsReadable = false; }
  getWindow().setStatusBarColor(SingKeyUi.NAVY);
  getWindow().setNavigationBarColor(SingKeyUi.NAVY);
  root = new FrameLayout(this); setContentView(root);
  chrome = new LinearLayout(this); chrome.setOrientation(LinearLayout.VERTICAL); chrome.setBackgroundColor(SingKeyUi.NAVY);
  chrome.setOnApplyWindowInsetsListener((v,i) -> {
   v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());
   boolean keyboard=Build.VERSION.SDK_INT>=30?i.isVisible(WindowInsets.Type.ime()):i.getSystemWindowInsetBottom()>dp(100);
   if(navBar!=null)navBar.setVisibility(portraitPlayerSearch&&keyboard?View.GONE:View.VISIBLE);
   compactPlayerHeader(portraitPlayerSearch&&keyboard);return i;
  });
  root.addView(chrome,new FrameLayout.LayoutParams(-1,-1));
  scroll = new ScrollView(this); scroll.setFillViewport(true); chrome.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  searchPage=page();searchPage.setVisibility(View.GONE);chrome.addView(searchPage,new LinearLayout.LayoutParams(-1,0,1));
  column = new LinearLayout(this); column.setOrientation(LinearLayout.VERTICAL); scroll.addView(column);
  homePage = page(); playerPage = page(); libraryPage = page(); helpPage = page();settingsPage=page();contactPage=page();infoPage=page();
  column.addView(homePage); column.addView(playerPage); column.addView(libraryPage); column.addView(helpPage);column.addView(settingsPage);column.addView(contactPage);column.addView(infoPage);
  LinearLayout brand = row(); brand.setPadding(0,dp(4),0,dp(20));
  ImageView mark = new ImageView(this); mark.setImageResource(R.drawable.naekiro_mark);mark.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
  LinearLayout.LayoutParams markSize=new LinearLayout.LayoutParams(dp(30),dp(30));markSize.rightMargin=dp(8);brand.addView(mark,markSize);
  TextView logo=SingKeyUi.heading(this,getString(R.string.app_name),23);
  mark.setOnClickListener(v->showHome());logo.setOnClickListener(v->showHome());logo.setContentDescription(getString(R.string.back_to_home));SingKeyUi.feedback(logo,8);
  brand.addView(logo,new LinearLayout.LayoutParams(0,-2,1));brand.addView(icon(R.drawable.ic_sk_help,getString(R.string.help_title),v -> showHelp()));homePage.addView(brand);
  LinearLayout discovery = row(); discovery.setPadding(dp(8),dp(4),dp(4),dp(4));discovery.setBackground(SingKeyUi.outline(this,SingKeyUi.SURFACE,16,0xff29313e));
  link = new SearchInput(this,suggestionSource);link.onSuggestion(()->showSearch());link.anchorTo(discovery);link.setHint(getString(R.string.search_hint));link.setSingleLine(true);link.setContentDescription(getString(R.string.search_hint));SingKeyUi.field(link);link.setBackgroundColor(0);link.setPadding(dp(6),0,dp(6),0);
  link.setFocusable(false);link.setCursorVisible(false);link.setOnClickListener(v->openPortraitSearch());
  discovery.addView(link,new LinearLayout.LayoutParams(0,dp(48),1));
  open=icon(R.drawable.ic_sk_search,getString(R.string.search_tracks),v -> openPortraitSearch());open.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x330b0e14),SingKeyUi.shape(this,SingKeyUi.MINT,12),null));open.setPadding(dp(12),dp(12),dp(12),dp(12));open.setCompoundDrawables(SingKeyUi.icon(this,R.drawable.ic_sk_search,SingKeyUi.NAVY,24),null,null,null);discovery.addView(open);homePage.addView(discovery);
  homeSearchOption=searchOption();homePage.addView(homeSearchOption);
  // Anchor suggestions below both controls so they never hide the search preference.
  link.anchorTo(homeSearchOption);
  community=new CommunityUi(this,()->savedSongsReadable?playlists:null,this::playSong,this::importPublicPlaylist,()->showLegalText(getString(R.string.privacy),"privacy.txt"));homePage.addView(community.home());
  recommendationView=new LinearLayout(this);recommendationView.setOrientation(LinearLayout.VERTICAL);recommendationView.setPadding(0,dp(16),0,0);homePage.addView(recommendationView);renderRecommendations();
  recentView = page(); recentView.setPadding(0,dp(20),0,dp(16)); homePage.addView(recentView); renderRecent();
  homeAd=new BannerSlot(this,getString(R.string.admob_home_banner),"home",usage,()->{});homePage.addView(homeAd,new LinearLayout.LayoutParams(-1,-2));
  addFeaturedSongs();

  link.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
  link.setOnEditorActionListener((v,a,e) -> { showSearch(); return true; });
  player = BuildConfig.YOUTUBE_IFRAME ? new YouTubeIframePlayer(this) : new BrowserPlayer(this); videoView=player;
  playbackFeedback=new PlaybackFeedback(this,this::resumeCurrent,this::findAlternative);
  if(!BuildConfig.YOUTUBE_IFRAME)videoView.getOverlayFrameLayout().addView(playbackFeedback,new FrameLayout.LayoutParams(-1,-1));
  playerPage.setPadding(0,0,0,0);
  videoSlot = new PlayerRefreshLayout(this,()->currentSong!=null&&!fullScreen&&(portraitPlayerSearch||activePage.equals("player")&&scroll.getScrollY()==0),this::reloadCurrent);videoSlot.setBackgroundColor(Color.BLACK);
  videoSlot.addView(videoView,0,new FrameLayout.LayoutParams(-1,-1));playerPage.addView(videoSlot,new LinearLayout.LayoutParams(-1,dp(220)));
  portraitSearchButton=addPortraitVideoButton(R.drawable.ic_sk_search,getString(R.string.search_while_playing),Gravity.START,v -> {if(portraitPlayerSearch)showPage("player");else openPortraitSearch();});
  portraitFullscreenButton=addPortraitVideoButton(R.drawable.ic_sk_expand,getString(R.string.landscape_mode),Gravity.END,v -> enterFullScreen());
  videoSlot.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob) -> { int h=portraitPlayerSearch?dp(BuildConfig.YOUTUBE_IFRAME?(compactPlayerHeader?200:264):304):BuildConfig.YOUTUBE_IFRAME?Math.max(dp(200),Math.round((r-l)*9f/16f))+dp(64):Math.round((r-l)*9f/16f)+dp(104);if(h>0&&v.getLayoutParams().height!=h){v.getLayoutParams().height=h;v.requestLayout();} });
  if(BuildConfig.YOUTUBE_IFRAME){playbackFeedback.setPadding(dp(24),dp(12),dp(24),dp(12));playerPage.addView(playbackFeedback,new LinearLayout.LayoutParams(-1,-2));}
  LinearLayout metadata=page();
  status=SingKeyUi.heading(this,getString(R.string.choose_song),20);status.setPadding(0,dp(4),0,dp(6));metadata.addView(status);
  trackChannel=SingKeyUi.label(this,getString(R.string.original_video_pitch),12,true);metadata.addView(trackChannel);
  resumeButton=primaryButton(getString(R.string.resume_practice),v->resumeCurrent());resumeButton.setVisibility(View.GONE);metadata.addView(resumeButton);
  playerPage.addView(metadata);
  createFullScreenLayer();
  LinearLayout tuning=SingKeyUi.card(this);
  tuning.addView(SingKeyUi.label(this,getString(R.string.pitch_heading),11,true));
  keyLabel=SingKeyUi.label(this,"0",36,false);keyLabel.setTextColor(SingKeyUi.MINT);keyLabel.setGravity(Gravity.CENTER);keyLabel.setPadding(0,dp(8),0,dp(8));
  LinearLayout controls = new LinearLayout(this);controls.setGravity(Gravity.CENTER_VERTICAL);
  Button lower=button(getString(R.string.lower_semitone),v -> setKey(key-1));lower.setMinHeight(dp(56));lower.setMinimumHeight(dp(56));lower.setContentDescription(getString(R.string.lower_accessibility));
  controls.addView(lower,new LinearLayout.LayoutParams(0,-2,1));
  controls.addView(keyLabel,new LinearLayout.LayoutParams(0,-2,1));
  Button higher=button(getString(R.string.higher_semitone),v -> setKey(key+1));higher.setMinHeight(dp(56));higher.setMinimumHeight(dp(56));higher.setContentDescription(getString(R.string.higher_accessibility));
  controls.addView(higher,new LinearLayout.LayoutParams(0,-2,1));tuning.addView(controls);
  TextView range=SingKeyUi.label(this,getString(R.string.pitch_range),12,true);range.setGravity(Gravity.CENTER);range.setPadding(0,dp(8),0,dp(12));tuning.addView(range);
  LinearLayout library=new LinearLayout(this);library.setGravity(Gravity.CENTER_VERTICAL);
  Button resetKey=button(getString(R.string.original_zero),v -> setKey(0));resetKey.setContentDescription(getString(R.string.reset_original));
  library.addView(resetKey,new LinearLayout.LayoutParams(0,-2,1));library.addView(saveButton(),new LinearLayout.LayoutParams(0,-2,1));tuning.addView(library);insetBlock(playerPage,tuning);
  LinearLayout notebook=SingKeyUi.card(this);notebook.addView(SingKeyUi.heading(this,getString(R.string.notes_title),16));
  songNoteSummary=SingKeyUi.label(this,"",13,true);songNoteSummary.setMaxLines(3);songNoteSummary.setEllipsize(android.text.TextUtils.TruncateAt.END);songNoteSummary.setPadding(0,dp(8),0,dp(8));notebook.addView(songNoteSummary);
  Button noteButton=button(getString(R.string.notes_edit),v->editCurrentNotes());noteButtons.add(noteButton);notebook.addView(noteButton);
  previousNoteKey=flatText("",v->{});notebook.addView(previousNoteKey);insetBlock(playerPage,notebook);refreshSongNotes();
  portraitAd=new BannerSlot(this,getString(R.string.admob_player_banner),"player",usage,()->{});playerPage.addView(portraitAd,new LinearLayout.LayoutParams(-1,-2));
  LinearLayout upcoming=page();queueLabel=SingKeyUi.heading(this,getString(R.string.up_next),16);
  nextButton=nextQueueButton();upcoming.addView(queueHeader(queueLabel,nextButton));
  queueView=new LinearLayout(this);queueView.setOrientation(LinearLayout.VERTICAL);upcoming.addView(queueView);playerPage.addView(upcoming);

  buildNavigation();
  player.addListener(new PlaybackPlayer.Listener() {
   @Override public void onIsPlayingChanged(boolean playing) {
    if(playing&&currentSong!=null)embedAvailability.played(currentSong.url);
    usage.playing(playing&&foreground);
    recordPracticeStarted();
    if (playing && recordHistory && currentSong != null && !recordedCurrent) { recordedCurrent = true; recent.record(currentSong,key); scheduleHistory(); renderRecent(); }
    updateMini();
    schedulePractice();
   }
   @Override public void onPlaybackStateChanged(int state) {
    if(state==PlaybackPlayer.STATE_READY){loading=false;loadFailed=false;if(currentSong!=null)trackChannel.setText(songChannel(currentSong));updateSaveButtons();}
    if (state == PlaybackPlayer.STATE_ENDED && !loading && foreground && !queue.isEmpty()) playNext(false);
    updateMini();
   }
   @Override public void onPitchUnavailable() {
    new AppDialog(MainActivity.this).setTitle(R.string.browser_pitch_unavailable).setMessage(R.string.browser_pitch_unavailable_help)
     .setPositiveButton(R.string.original_key,(dialog,which)->{if(currentSong!=null)playSong(currentSong,0,false,player.getCurrentPosition(),true,recordedCurrent);})
     .setNegativeButton(R.string.cancel,null).show();
   }
   @Override public void onPlayerError(Exception e) {
    loading=false;loadFailed=true;usage.record(UsageEvent.failure(false));
    if(currentSong!=null){status.setText(songTitle(currentSong));embedAvailability.failed(currentSong.url,e);}
    if(refreshSearchResults!=null)refreshSearchResults.run();
    if(YouTubePlaybackException.embedBlocked(e)&&fullScreen&&foreground&&closeSearch==null&&closeLibrary==null){link.setText("");showSearch(false);}
    updateSaveButtons();updateMini();
   }
  });
  if (saved != null) { link.setText(saved.getString("link", "")); setKey(saved.getInt("key",0)); }
  else if (Intent.ACTION_SEND.equals(getIntent().getAction())) link.setText(getIntent().getStringExtra(Intent.EXTRA_TEXT));
  if (sameProcess) {
   ArrayList<String> urls = saved.getStringArrayList("queueUrls"), titles = saved.getStringArrayList("queueTitles");
   if (urls != null && titles != null) for (int i = 0; i < Math.min(urls.size(), titles.size()); i++) queue.add(new SavedSongs.Entry(new Song(urls.get(i), titles.get(i)), saved.getIntArray("queueKeys") != null && i < saved.getIntArray("queueKeys").length ? saved.getIntArray("queueKeys")[i] : 0));
  }
  else if(recovered!=null)queue.addAll(recovered.queue);
  SettingsPage.contact(contactPage,()->showPage("settings"));
  SettingsPage.information(infoPage,()->showPage("settings"),this::showLegalText);
  renderQueue(); updateSaveButtons(); showPage("home");
  if(saved!=null){
   helpReturnPage=saved.getString("helpReturnPage","home");
   String page=saved.getString("activePage","home");
   if(page.equals("library"))renderPlaylists(libraryPage);
   if(java.util.Arrays.asList("home","settings","help","contact","info","library","player").contains(page))showPage(page);
   returnPage=saved.getString("returnPage","home");
   if(sameProcess&&saved.getString("currentUrl")!=null&&!saved.getBoolean("resumePending",false))playSong(new Song(saved.getString("currentUrl"),saved.getString("currentTitle",""),saved.getString("currentThumbnail","")),key,false,saved.getLong("position",0),saved.getBoolean("resumePlayback",false),saved.getBoolean("recordedCurrent",false));
   analyticsTrackStarted=saved.getBoolean("analyticsTrackStarted",false);
  }
  if(sameProcess&&saved.getBoolean("resumePending",false)&&saved.getString("currentUrl")!=null)recovered=new PracticeSession(new SavedSongs.Entry(new Song(saved.getString("currentUrl"),saved.getString("currentTitle",""),saved.getString("currentThumbnail","")),key),saved.getLong("position",0),queue);
  if(recovered!=null&&recovered.current!=null){currentSong=recovered.current.song;resumePosition=recovered.position;resumePending=true;settingPlaybackKey=true;setKey(recovered.current.key);settingPlaybackKey=false;status.setText(songTitle(currentSong));trackChannel.setText(getString(R.string.resume_practice_hint));updateNextQueueMarquee();updateMini();}
  practiceReady=recovered!=null||sameProcess;
  if(sameProcess)currentSearchQuery=saved.getString("currentSearchQuery","");
  if(saved!=null&&saved.getBoolean("portraitSearch",false))showSearch(false);
  else if(Intent.ACTION_SEND.equals(getIntent().getAction())&&!link.getText().toString().trim().isEmpty())showSearch();
  if (Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, fullScreenBack);
  if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) showFullScreen(true);
  if(community.intent(getIntent()))setIntent(new Intent(this,MainActivity.class));
  root.post(()->{if(!isDestroyed())usage.askIfNeeded(this,()->{usage.screen(activePage,fullScreen);advertisingConsent.start();});});
 }
 private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
 private CheckBox searchOption() {
  CheckBox check=new CheckBox(this);check.setText(getString(R.string.prefer_backing));check.setTextSize(14);
  check.setTextColor(SingKeyUi.MUTED);check.setMinHeight(dp(48));check.setMinimumHeight(dp(48));
  check.setPadding(dp(4),dp(4),dp(8),dp(4));check.setButtonTintList(new android.content.res.ColorStateList(
   new int[][]{{android.R.attr.state_checked},{}},new int[]{SingKeyUi.MINT,SingKeyUi.MUTED}));
  check.setChecked(preferBacking);check.setOnCheckedChangeListener((button,checked)->changeSearchOption(checked));return check;
 }
 private void changeSearchOption(boolean checked) {
  if(syncingSearchOptions||preferBacking==checked)return;
  preferBacking=checked;getPreferences(MODE_PRIVATE).edit().putBoolean("preferBacking",checked).apply();
  syncingSearchOptions=true;
  if(homeSearchOption!=null)homeSearchOption.setChecked(checked);
  if(portraitSearchOption!=null)portraitSearchOption.setChecked(checked);
  if(splitSearchOption!=null)splitSearchOption.setChecked(checked);
  syncingSearchOptions=false;cachedResults=null;
  if(activeSearchButton!=null&&!lastSubmittedQuery.isEmpty()) {
   activeSearchInput.setText(lastSubmittedQuery);link.setText(lastSubmittedQuery);showSearch(false);
  }
 }
 private Button icon(int res,String label,View.OnClickListener action){return SingKeyUi.iconButton(this,res,label,action);}
 private Button addPortraitVideoButton(int res,String label,int gravity,View.OnClickListener action) {
  Button button=icon(res,label,action);button.setTooltipText(label);
  button.setBackground(SingKeyUi.shape(this,0xcc0b0e14,10));SingKeyUi.feedback(button,10);
  button.setPadding(dp(12),dp(12),dp(12),dp(12));
  button.setCompoundDrawables(SingKeyUi.icon(this,res,SingKeyUi.INK,24),null,null,null);
  FrameLayout.LayoutParams placement=new FrameLayout.LayoutParams(dp(48),dp(48),Gravity.TOP|gravity);
  placement.setMargins(dp(12),dp(12),dp(12),0);videoSlot.addView(button,placement);return button;
 }
 private Button flatText(String text,View.OnClickListener action){Button b=button(text,action);b.setTextSize(12);b.setTextColor(SingKeyUi.MUTED);b.setBackgroundColor(0);SingKeyUi.feedback(b,8);b.setPadding(dp(12),dp(8),dp(12),dp(8));return b;}
 private void insetBlock(LinearLayout parent,View v){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(16),0,dp(16),dp(12));parent.addView(v,p);}
 private void divider(LinearLayout parent){View line=new View(this);line.setBackgroundColor(0xff1b212c);parent.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));}
 private String songTitle(Song s){int at=s.title.lastIndexOf(" · ");return at<0?s.title:s.title.substring(0,at);}
 private String songChannel(Song s){int at=s.title.lastIndexOf(" · ");return at<0?getString(R.string.youtube_track):s.title.substring(at+3);}
 private TextView keyBadge(int key){TextView t=SingKeyUi.label(this,keyText(key),11,false);t.setTextColor(SingKeyUi.MINT);t.setPadding(dp(5),dp(2),dp(5),dp(2));t.setBackground(SingKeyUi.outline(this,0xff1c2510,4,0xff424e1b));return t;}
 private FrameLayout artwork(Song song,int width,int height){
  FrameLayout f=new FrameLayout(this);f.setLayoutParams(new LinearLayout.LayoutParams(width,height));f.setBackground(SingKeyUi.shape(this,SingKeyUi.RAISED,10));f.setClipToOutline(true);
  ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER);img.setImageDrawable(SingKeyUi.icon(this,R.drawable.ic_sk_play,SingKeyUi.MINT,20));f.addView(img,new FrameLayout.LayoutParams(-1,-1));
  if(song!=null&&!song.thumbnailUrl.isEmpty()){img.setScaleType(ImageView.ScaleType.CENTER_CROP);thumbnails.load(song.thumbnailUrl,img,()->!isDestroyed()&&img.isAttachedToWindow());}return f;
 }
 private LinearLayout songInfo(Song song,Integer key){
  LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(10),0,dp(4),0);
  TextView title=SingKeyUi.heading(this,songTitle(song),14);title.setMaxLines(2);title.setEllipsize(android.text.TextUtils.TruncateAt.END);info.addView(title);
  LinearLayout meta=row();meta.setPadding(0,dp(4),0,0);if(key!=null)meta.addView(keyBadge(key));TextView channel=SingKeyUi.label(this," "+songChannel(song),11,true);channel.setMaxLines(1);channel.setEllipsize(android.text.TextUtils.TruncateAt.END);meta.addView(channel,new LinearLayout.LayoutParams(0,-2,1));info.addView(meta);
  if(key!=null&&songNotes.find(song.url)!=null){TextView note=SingKeyUi.label(this,songNotes.summary(song.url),12,true);note.setMaxLines(2);note.setEllipsize(android.text.TextUtils.TruncateAt.END);info.addView(note);}return info;
 }
 private LinearLayout songRow(Song song,Integer key,Runnable play,int actionIcon,String actionLabel,Runnable action,boolean boxed){
  LinearLayout r=boxed?SingKeyUi.card(this):row();r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(boxed?10:0),dp(10),dp(4),dp(10));
  if(boxed||!fullScreen)r.addView(artwork(song,dp(80),dp(48)));r.addView(songInfo(song,key),new LinearLayout.LayoutParams(0,-2,1));
  if(play!=null)r.setOnClickListener(v -> play.run());r.addView(icon(actionIcon,actionLabel,v -> action.run()));if(!boxed)r.setBackground(SingKeyUi.outline(this,SingKeyUi.NAVY,0,0xff151a23));if(play!=null)SingKeyUi.feedback(r,boxed?14:0);return r;
 }
 private String playlistName(Playlists.ListEntry list) {
  return !playlists.entries().isEmpty() && list==playlists.entries().get(0) && "내 곡".equals(list.name)
    ? getString(R.string.default_playlist) : list.name;
 }
 private LinearLayout playlistRow(Playlists.ListEntry list,Runnable click,boolean save){
  LinearLayout r=SingKeyUi.card(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(14),dp(14),dp(8),dp(14));
  ImageView symbol=new ImageView(this);symbol.setImageDrawable(SingKeyUi.icon(this,save?R.drawable.ic_sk_music:R.drawable.ic_sk_list,SingKeyUi.MINT,23));symbol.setBackground(SingKeyUi.shape(this,SingKeyUi.RAISED,10));symbol.setPadding(dp(12),dp(12),dp(12),dp(12));r.addView(symbol,new LinearLayout.LayoutParams(dp(48),dp(48)));
  LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(16),0,0,0);info.addView(SingKeyUi.heading(this,playlistName(list),16));TextView count=SingKeyUi.label(this,getString(save?R.string.saved_count:R.string.saved_count_auto,list.songs.entries().size()),12,true);count.setPadding(0,dp(5),0,0);info.addView(count);r.addView(info,new LinearLayout.LayoutParams(0,-2,1));
  Button next=icon(R.drawable.ic_sk_forward,save?getString(R.string.save_here):getString(R.string.open_playlist),v -> click.run());r.addView(next);r.setOnClickListener(v -> click.run());SingKeyUi.feedback(r,14);return r;
 }
 private void buildHelpPage(){
  SettingsPage.header(helpPage,R.string.help_title,()->showPage(helpReturnPage));
  HelpPage.populate(helpPage, () -> {
   openPortraitSearch();
  });
 }

 private void showLegalText(String title,String asset) {
  try(java.io.InputStream input=getAssets().open(language==AppLanguage.KO?asset:language.language+"/"+asset)) {
   java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();
   byte[] buffer=new byte[4096];int count;
   while((count=input.read(buffer))!=-1)bytes.write(buffer,0,count);
   TextView body=SingKeyUi.label(this,bytes.toString("UTF-8"),14,false);
   body.setPadding(dp(20),dp(12),dp(20),dp(20));body.setTextIsSelectable(true);
   android.text.util.Linkify.addLinks(body,android.text.util.Linkify.WEB_URLS|android.text.util.Linkify.EMAIL_ADDRESSES);
   body.setLinkTextColor(SingKeyUi.MINT);
   ScrollView content=AppDialog.scroll(this,body);
   AlertDialog dialog=new AppDialog(this).setTitle(title).setView(content).setPositiveButton(getString(R.string.close),null).create();
   showManagedDialog(dialog);
  } catch(java.io.IOException error) { Toast.makeText(this,getString(R.string.document_error),Toast.LENGTH_SHORT).show(); }
 }

 private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
 private LinearLayout page() {
  LinearLayout v = new LinearLayout(this); v.setOrientation(LinearLayout.VERTICAL);
  v.setPadding(dp(16),dp(12),dp(16),dp(12)); return v;
 }
 private final java.util.Map<String,Integer> pageScrolls = new java.util.HashMap<>();
 private void showHome() { pageScrolls.put("home",0);showPage("home"); }
 private void showPage(String page) {
  if(page.equals("home"))renderRecommendations();
  if(!fullScreen&&activePage.equals("search")&&!page.equals("search")&&closeSearch!=null)closeSearch.run();
  if(activePage.equals("contact")&&!page.equals("contact"))((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(root.getWindowToken(),0);
  if(page.equals("settings"))populateSettings();
  if(!page.equals("home"))link.finishInput();
  if (!page.equals(activePage)) {
   if(!activePage.equals("search"))pageScrolls.put(activePage,scroll.getScrollY());
   if (page.equals("player")) returnPage = activePage.equals("search")?"home":activePage;
  }
  activePage = page;
  if(!fullScreen)mountPortraitVideo(page.equals("search")&&currentSong!=null&&!resumePending&&player.getMediaItemCount()>0);
  usage.screen(page,fullScreen);
  scroll.setVisibility(page.equals("search")?View.GONE:View.VISIBLE);
  searchPage.setVisibility(page.equals("search")?View.VISIBLE:View.GONE);
  homePage.setVisibility(page.equals("home") ? View.VISIBLE : View.GONE);
  playerPage.setVisibility(page.equals("player") ? View.VISIBLE : View.GONE);
  libraryPage.setVisibility(page.equals("library") ? View.VISIBLE : View.GONE);
  helpPage.setVisibility(page.equals("help") ? View.VISIBLE : View.GONE);
  settingsPage.setVisibility(page.equals("settings")?View.VISIBLE:View.GONE);
  contactPage.setVisibility(page.equals("contact")?View.VISIBLE:View.GONE);
  infoPage.setVisibility(page.equals("info")?View.VISIBLE:View.GONE);
  if (navBar != null) for (int i=0;i<navBar.getChildCount();i++) {
   Button tab = (Button)navBar.getChildAt(i);
   String navPage=page.equals("contact")||page.equals("info")?"settings":page.equals("help")?helpReturnPage:page;
   boolean chosen=navPage.equals(tab.getTag()) || ((page.equals("player")||page.equals("search")) && "home".equals(tab.getTag()));
   tab.setSelected(chosen);tab.setTextColor(chosen ? SingKeyUi.MINT : SingKeyUi.MUTED);
   for(android.graphics.drawable.Drawable d:tab.getCompoundDrawables()) if(d!=null)d.setTint(chosen?SingKeyUi.MINT:SingKeyUi.MUTED);
  }
  updateMini();
  scroll.post(() -> { if (activePage.equals(page)) scroll.scrollTo(0,pageScrolls.getOrDefault(page,0)); });
  updateAdvertising();
 }
 // Reparent the existing visible player; opening search must not load a new song.
 private void mountPortraitVideo(boolean inSearch){
  if(videoSlot==null)return;
  LinearLayout target=inSearch?searchPage:playerPage;
  portraitPlayerSearch=inSearch;
  if(!inSearch)compactPlayerHeader(false);
  if(videoSlot.getParent()!=target){
   player.layoutChanged();((ViewGroup)videoSlot.getParent()).removeView(videoSlot);
   target.addView(videoSlot,0,new LinearLayout.LayoutParams(-1,dp(BuildConfig.YOUTUBE_IFRAME?264:304)));
  }
  searchPage.setPadding(inSearch?0:dp(16),inSearch?0:dp(12),inSearch?0:dp(16),0);
  if(portraitSearchButton!=null){int label=inSearch?R.string.back_to_player:R.string.search_while_playing;portraitSearchButton.setContentDescription(getString(label));portraitSearchButton.setTooltipText(getString(label));portraitSearchButton.setCompoundDrawables(SingKeyUi.icon(this,inSearch?R.drawable.ic_sk_up:R.drawable.ic_sk_search,SingKeyUi.INK,24),null,null,null);}
  videoSlot.requestLayout();
 }
 private void compactPlayerHeader(boolean compact){
  compact=compact&&BuildConfig.YOUTUBE_IFRAME&&!fullScreen;
  if(videoSlot==null||compactPlayerHeader==compact)return;
  compactPlayerHeader=compact;videoSlot.compactHeader(compact);player.compactHeader(compact);
  portraitSearchButton.setVisibility(compact?View.GONE:View.VISIBLE);portraitFullscreenButton.setVisibility(compact?View.GONE:View.VISIBLE);
  if(portraitPlayerSearch)videoSlot.getLayoutParams().height=dp(compact?200:264);
  videoSlot.requestLayout();
 }
 private void buildNavigation() {
  miniBar = new LinearLayout(this); miniBar.setGravity(Gravity.CENTER_VERTICAL);
  miniBar.setPadding(dp(12),dp(4),dp(8),dp(4)); miniBar.setBackground(SingKeyUi.outline(this,0xff161d27,0,0xff232a36));
  miniArt=new ImageView(this);miniArt.setImageDrawable(SingKeyUi.icon(this,R.drawable.ic_sk_music,SingKeyUi.MINT,24));miniArt.setBackground(SingKeyUi.shape(this,SingKeyUi.RAISED,8));miniArt.setPadding(dp(8),dp(8),dp(8),dp(8));miniBar.addView(miniArt,new LinearLayout.LayoutParams(dp(44),dp(40)));
  miniTitle = SingKeyUi.label(this,"",14,false); miniTitle.setMaxLines(1);
  miniTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
  miniTitle.setOnClickListener(v -> showPage("player"));
  LinearLayout miniInfo=new LinearLayout(this);miniInfo.setOrientation(LinearLayout.VERTICAL);miniInfo.setPadding(dp(10),0,0,0);miniInfo.addView(miniTitle);
  miniKey=SingKeyUi.label(this,"",11,true);miniInfo.addView(miniKey);miniInfo.setOnClickListener(v -> showPage("player"));miniBar.addView(miniInfo,new LinearLayout.LayoutParams(0,-2,1));
  miniToggle = icon(R.drawable.ic_sk_play,getString(R.string.play_pause),v -> {
   if(resumePending)resumeCurrent();
   else if (player.isPlaying()) player.pause();
   else if (currentSong != null && (player.getPlayerError() != null || player.getMediaItemCount() == 0)) resumeCurrent();
   else { if(BuildConfig.YOUTUBE_IFRAME)showPage("player");if (player.getPlaybackState() == PlaybackPlayer.STATE_ENDED) player.seekTo(0); player.play(); }
  }); miniBar.addView(miniToggle);
  miniBar.addView(icon(R.drawable.ic_sk_up,getString(R.string.expand_player),v -> showPage("player"))); chrome.addView(miniBar);
  navBar = new LinearLayout(this);navBar.setBackgroundResource(R.drawable.singkey_nav_background);navBar.setPadding(0,dp(1),0,0);
  String[] labels = {getString(R.string.nav_home),getString(R.string.nav_library),getString(R.string.settings)}, pages = {"home","library","settings"};
  for (int i=0;i<labels.length;i++) {
   String page = pages[i]; int[] navIcons={R.drawable.ic_sk_home,R.drawable.ic_sk_list,R.drawable.ic_sk_settings}; Button tab = SingKeyUi.action(this,navIcons[i],labels[i],v -> { if (page.equals("library")) showSavedSongs(); else if(page.equals("home"))showHome();else showPage(page); });
   tab.setTag(page); navBar.addView(tab,new LinearLayout.LayoutParams(0,-2,1));
  }
  chrome.addView(navBar);
  buildHelpPage();
 }
 private void updateMini() {
  if(videoSlot!=null)videoSlot.refreshing(loading);
  updatePlaybackFeedback();
  if(resumeButton!=null)resumeButton.setVisibility(resumePending?View.VISIBLE:View.GONE);
  if(landscapeResumeButton!=null)landscapeResumeButton.setVisibility(resumePending?View.VISIBLE:View.GONE);
  if (miniBar == null) return;
  miniBar.setVisibility(currentSong != null && !activePage.equals("player") && !portraitPlayerSearch ? View.VISIBLE : View.GONE);
  if (currentSong == null) return;
  boolean failed = !resumePending&&!loading && (player.getPlayerError() != null || player.getMediaItemCount() == 0);
  boolean waiting=loading||player.getPlaybackState()==PlaybackPlayer.STATE_BUFFERING;
  miniTitle.setText(currentSong.title);miniKey.setText(getString(R.string.mini_status,keyText(key),resumePending?getString(R.string.resume_practice):waiting?getString(R.string.loading_short):failed?getString(R.string.playback_failed):player.isPlaying()?getString(R.string.playing_expand):getString(R.string.pause)));miniKey.setTextColor(SingKeyUi.MINT);
  miniToggle.setEnabled(!loading||resumePending);
  miniToggle.setContentDescription(failed?getString(R.string.retry):player.isPlaying()?getString(R.string.pause):getString(R.string.play));miniToggle.setCompoundDrawables(SingKeyUi.icon(this,player.isPlaying()?R.drawable.ic_sk_pause:R.drawable.ic_sk_play,SingKeyUi.INK,24),null,null,null);
 }
 private void scheduleHistory() { historyHandler.removeCallbacks(persistRecent); historyHandler.postDelayed(persistRecent,500); }
 private void schedulePractice(){if(practiceReady){historyHandler.removeCallbacks(persistPractice);historyHandler.postDelayed(persistPractice,200);}}
 private long practicePosition(){return resumePending?resumePosition:player.getResumePosition();}
 private void savePractice(boolean durable){
  if(!practiceReady||player==null)return;
  try{String snapshot=new PracticeSession(currentSong==null?null:new SavedSongs.Entry(currentSong,key),practicePosition(),queue).encode();if(snapshot.equals(lastPracticeSnapshot))return;android.content.SharedPreferences.Editor edit=getPreferences(MODE_PRIVATE).edit().putString("practiceSession",snapshot);if(durable){if(!edit.commit())return;}else edit.apply();lastPracticeSnapshot=snapshot;}catch(java.io.IOException ignored){/* Never clear unrelated data when a snapshot cannot be written. */}
 }
 private void resumeCurrent(){if(currentSong!=null)playSong(currentSong,key,true,practicePosition(),true,false);}
 private void reloadCurrent(){
  if(currentSong==null||loading)return;
  boolean autoplay=player.isPlaying()||(player.getPlaybackState()==PlaybackPlayer.STATE_BUFFERING&&player.getPlayWhenReady())||loadFailed||resumePending;
  playSong(currentSong,key,false,practicePosition(),autoplay,recordedCurrent);
 }
 private void persistQueries(){if(!searchHistoryReadable)return;try{getPreferences(MODE_PRIVATE).edit().putString("recentQueries",recentQueries.encode()).apply();}catch(java.io.IOException ignored){}}
 private void clearQueries(){new AppDialog(this).destructive(AlertDialog.BUTTON_POSITIVE).setTitle(R.string.search_history_clear).setMessage(R.string.search_history_clear_help).setNegativeButton(R.string.cancel,null).setPositiveButton(R.string.delete,(d,w)->{recentQueries.clear();searchHistoryReadable=true;persistQueries();populateSettings();}).show();}
 private void renderRecent() {
  renderRecommendations();
  if(recentView==null)return;recentView.removeAllViews();
  LinearLayout header=row();header.addView(SingKeyUi.heading(this,getString(R.string.recent_songs),17),new LinearLayout.LayoutParams(0,-2,1));
  Button lists=flatText(getString(R.string.playlists_link),v -> showSavedSongs());header.addView(lists);recentView.addView(header);
  if(recent.entries().isEmpty()){recentView.addView(SingKeyUi.label(this,getString(recordHistory?R.string.recent_empty:R.string.recent_recording_off),13,true));return;}
  HorizontalScrollView rail=new HorizontalScrollView(this);rail.setHorizontalScrollBarEnabled(false);LinearLayout cards=row();rail.addView(cards);recentView.addView(rail);
  for(SavedSongs.Entry entry:recent.entries()){
   LinearLayout tile=new LinearLayout(this);tile.setOrientation(LinearLayout.VERTICAL);
   FrameLayout cover=artwork(entry.song,dp(144),dp(80));TextView badge=keyBadge(entry.key);
   FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.END);bp.setMargins(0,0,dp(6),dp(6));cover.addView(badge,bp);tile.addView(cover);
   TextView title=SingKeyUi.heading(this,songTitle(entry.song),14);title.setMaxLines(1);title.setEllipsize(android.text.TextUtils.TruncateAt.END);title.setPadding(0,dp(8),0,dp(5));tile.addView(title);
   TextView channel=SingKeyUi.label(this,songChannel(entry.song),12,true);channel.setMaxLines(1);tile.addView(channel);
   tile.setOnClickListener(v -> playSong(entry.song,entry.key));SingKeyUi.feedback(tile,10);tile.setContentDescription(getString(R.string.recent_accessibility,entry.song.title,keyText(entry.key)));
   tile.setOnLongClickListener(v -> {new AppDialog(this).setMessage(getString(R.string.remove_recent_question)).setPositiveButton(getString(R.string.delete),(d,w)->{recent.remove(entry.song.url);scheduleHistory();renderRecent();}).setNegativeButton(getString(R.string.cancel),null).show();return true;});
   LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(dp(144),-2);tp.rightMargin=dp(12);cards.addView(tile,tp);
  }
 }
 private void navigateBack() {
  View focus = getCurrentFocus();
  if (Build.VERSION.SDK_INT >= 30 && getWindow().getDecorView().getRootWindowInsets() != null
    && getWindow().getDecorView().getRootWindowInsets().isVisible(WindowInsets.Type.ime())) {
   ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(focus == null ? root.getWindowToken() : focus.getWindowToken(),0); return;
  }
  if (savedSongsDialog != null) { savedSongsDialog.cancel(); return; }
  if (fullScreen) { handleFullScreenBack(); return; }
  if(portraitPlayerSearch){showPage("player");return;}
  if (activePage.equals("player")) { showPage(returnPage); return; }
  if (activePage.equals("library") && selectedList != null) { renderPlaylists(libraryPage); return; }
  if(activePage.equals("help")){showPage(helpReturnPage);return;}
  if(activePage.equals("contact")||activePage.equals("info")){showPage("settings");return;}
  if (!activePage.equals("home")) { showPage("home"); return; }
  if (closeSearch != null) { closeSearch.run(); return; }
  finish();
 }
 private void addFeaturedSongs() {
  featuredView=new LinearLayout(this);featuredView.setOrientation(LinearLayout.VERTICAL);featuredView.setPadding(0,dp(12),0,dp(12));
  homePage.addView(featuredView);
  homeFeed=new HomeFeed(HomeCategory.restore(getPreferences(MODE_PRIVATE).getString("homeCategory",null),language));
  for(HomeCategory category:HomeCategory.values())if(category.isChart()) {
   try {homeFeed.restore(category,FeaturedSongs.decode(getPreferences(MODE_PRIVATE).getString(chartCacheKey(category),null)));}
   catch(java.io.IOException|IllegalArgumentException ignored) { /* Fetch again if this chart cache is invalid. */ }
  }
  renderFeaturedSongs();
 }
 private void updatePlaybackFeedback(){
  if(playbackFeedback==null)return;
  PlaybackFeedback.State state=currentSong==null?PlaybackFeedback.State.HIDDEN:loading?PlaybackFeedback.State.LOADING:
   YouTubePlaybackException.embedBlocked(player.getPlayerError())?PlaybackFeedback.State.BLOCKED:loadFailed||player.getPlayerError()!=null?PlaybackFeedback.State.FAILED:
   player.getPlaybackState()==PlaybackPlayer.STATE_BUFFERING?PlaybackFeedback.State.BUFFERING:PlaybackFeedback.State.HIDDEN;
  playbackFeedback.show(state);
  if(searchPlaybackFeedback!=null)searchPlaybackFeedback.show(state==PlaybackFeedback.State.BLOCKED&&!findingAlternative?state:PlaybackFeedback.State.HIDDEN);
 }
 private void findAlternative(){
  String query=AlternativeSearch.query(currentSong,currentSearchQuery);
  findingAlternative=true;link.setText(query);cachedResults=null;showSearch(false);updatePlaybackFeedback();
  if(query.isEmpty()&&activeSearchInput!=null){activeSearchInput.requestFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(activeSearchInput,InputMethodManager.SHOW_IMPLICIT);}
 }
 private String chartCacheKey(HomeCategory category) { return category==HomeCategory.KOREAN?"karaokeChart":"karaokeChartJp"; }
 private int categoryLabel(HomeCategory category) { return category==HomeCategory.KOREAN?R.string.category_korean:category==HomeCategory.JAPANESE?R.string.category_japanese:R.string.category_pop; }
 private void renderFeaturedSongs() {
  HomeCategory category=homeFeed.selected();HomeFeed.State state=homeFeed.state(category);
  FeaturedSongs.Chart featuredChart=state.chart;
  featuredView.removeAllViews();
  featuredView.addView(SingKeyUi.heading(this,getString(category.isChart()?R.string.home_karaoke_top:R.string.home_pop_picks),17));
  LinearLayout categories=row();categories.setPadding(0,dp(8),0,dp(8));
  for(HomeCategory choice:HomeCategory.values()) {
   Button tab=SingKeyUi.tab(this,getString(categoryLabel(choice)),v->{
    if(homeFeed.selected()==choice)return;
    homeFeed.select(choice);getPreferences(MODE_PRIVATE).edit().putString("homeCategory",choice.id).apply();renderFeaturedSongs();refreshFeaturedSongs(false);
   });
   tab.setTextSize(14);tab.setMaxLines(2);tab.setSelected(choice==category);
   tab.setContentDescription(getString(categoryLabel(choice))+(choice==category?getString(R.string.selected_suffix):""));
   categories.addView(tab,new LinearLayout.LayoutParams(0,-1,1));
  }
  featuredView.addView(categories);
  LinearLayout meta=row();LinearLayout sourceInfo=new LinearLayout(this);sourceInfo.setOrientation(LinearLayout.VERTICAL);
  sourceInfo.addView(SingKeyUi.label(this,getString(category==HomeCategory.KOREAN?R.string.chart_source:category==HomeCategory.JAPANESE?R.string.chart_source_japan:R.string.pop_source),12,true));
  if(featuredChart!=null)sourceInfo.addView(SingKeyUi.label(this,getString(R.string.chart_period,featuredChart.periodLabel()),11,true));
  if(!category.isChart())sourceInfo.addView(SingKeyUi.label(this,getString(R.string.pop_editorial_note),11,true));
  meta.addView(sourceInfo,new LinearLayout.LayoutParams(0,-2,1));
  if(category.isChart()) {
   Button refresh=icon(R.drawable.ic_sk_refresh,state.loading?getString(R.string.chart_loading_accessibility):getString(R.string.chart_refresh),v -> refreshFeaturedSongs(true));
   refresh.setEnabled(!state.loading);meta.addView(refresh);
  }
  featuredView.addView(meta);
  String notice=state.loading?getString(R.string.chart_loading):state.failed?
   (featuredChart==null?getString(R.string.chart_error):getString(R.string.chart_stale_error)):
   featuredChart!=null&&!featuredChart.isFresh(System.currentTimeMillis())?getString(R.string.chart_stale):"";
  if(!notice.isEmpty()) {
   TextView message=SingKeyUi.label(this,notice,12,true);message.setPadding(0,dp(4),0,dp(12));featuredView.addView(message);
  }
  java.util.List<FeaturedSongs.Entry> entries=category.isChart()?(featuredChart==null?java.util.Collections.emptyList():featuredChart.entries):FeaturedSongs.popRecommendations();
  for(FeaturedSongs.Entry entry:entries){
   LinearLayout r=row();r.setPadding(0,dp(12),0,dp(12));r.setMinimumHeight(dp(72));
   boolean largeText=getResources().getConfiguration().fontScale>1.3f;
   boolean explicitSearch=getResources().getBoolean(R.bool.singkey_search_cta_variant)&&!largeText&&getResources().getConfiguration().screenWidthDp>=360;
   if(category.isChart()) {
    TextView rank=SingKeyUi.heading(this,""+entry.rank,14);rank.setTextColor(SingKeyUi.MUTED);
    r.addView(rank,new LinearLayout.LayoutParams(dp(largeText?44:32),-2));
   }
   LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(0,0,dp(8),0);
   TextView title=SingKeyUi.heading(this,entry.title,14);title.setMaxLines(2);title.setEllipsize(android.text.TextUtils.TruncateAt.END);info.addView(title);
   TextView artist=SingKeyUi.label(this,entry.artist,12,true);artist.setMaxLines(2);artist.setEllipsize(android.text.TextUtils.TruncateAt.END);info.addView(artist);
   r.addView(info,new LinearLayout.LayoutParams(0,-2,1));
   View.OnClickListener find=v -> {link.setText(entry.query);showSearch();};r.setOnClickListener(find);SingKeyUi.feedback(r,0);
   r.setContentDescription(category.isChart()?getString(R.string.chart_accessibility,entry.rank,entry.title,entry.artist):getString(R.string.recommendation_accessibility,entry.title,entry.artist));
   if(explicitSearch){Button findButton=flatText(getString(R.string.find_track),find);findButton.setContentDescription(getString(R.string.find_song,entry.title));findButton.setCompoundDrawables(SingKeyUi.icon(this,R.drawable.ic_sk_search,SingKeyUi.MUTED,18),null,null,null);findButton.setCompoundDrawablePadding(dp(6));r.addView(findButton);}
   else r.addView(icon(R.drawable.ic_sk_search,getString(R.string.find_song,entry.title),find));
   featuredView.addView(r);divider(featuredView);
  }
  featuredView.addView(flatText(getString(category==HomeCategory.KOREAN?R.string.chart_full:category==HomeCategory.JAPANESE?R.string.chart_full_japan:R.string.pop_catalog),v -> {
   try {startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(FeaturedSongs.sourceUrl(category))));}
   catch(android.content.ActivityNotFoundException ignored) {Toast.makeText(this,getString(R.string.no_browser),Toast.LENGTH_SHORT).show();}
  }));
 }
 private void refreshFeaturedSongs(boolean force) {
  HomeCategory category=homeFeed.selected();
  if(!homeFeed.begin(category,System.currentTimeMillis(),force))return;
  renderFeaturedSongs();
  chartWorker.execute(() -> {
   FeaturedSongs.Chart result=null;
   try {result=chartSource.fetch(category);}catch(java.io.IOException e) {android.util.Log.w("SingKeyChart","Chart refresh failed: "+category.id,e);}
   FeaturedSongs.Chart loaded=result;
   runOnUiThread(() -> {
    if(isDestroyed())return;
    homeFeed.complete(category,loaded);
    if(loaded!=null)getPreferences(MODE_PRIVATE).edit().putString(chartCacheKey(category),loaded.encode()).apply();
    if(homeFeed.selected()==category)renderFeaturedSongs();
   });
  });
 }
 private TextView text(String value, int size) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(ink); t.setPadding(0,12,0,12); column.addView(t); return t; }
 private Button button(String label, View.OnClickListener action) { return SingKeyUi.button(this,label,action,false); }
 private Button primaryButton(String label, View.OnClickListener action) { return SingKeyUi.button(this,label,action,true); }
 private void setKey(int value) { schedulePractice();int previous=key;key = KeyMath.clamp(value);if(previous!=key&&!settingPlaybackKey&&currentSong!=null)usage.record(UsageEvent.key(previous,key));player.setKey(key); String label = key == 0 ? "0" : (key > 0 ? "+" : "") + key;
  keyLabel.setText(label); if (fullKeyLabel != null) fullKeyLabel.setText(label); if (splitKeyLabel != null) {splitKeyLabel.setText(keyText(key));splitKeyLabel.setContentDescription(getString(R.string.current_key_reset,keyText(key)));} updateSaveButtons(); updateMini();refreshSongNotes(); if (recordHistory && recordedCurrent && currentSong != null) { recent.updateKey(currentSong,key); scheduleHistory(); renderRecent(); } }
 private void editCurrentNotes(){if(currentSong!=null&&!loading)songNotes.edit(currentSong,key);}
 private void onSongNotesChanged(){refreshSongNotes();renderRecommendations();if(selectedList!=null&&libraryPage!=null)renderPlaylist(libraryPage,selectedList);if(landscapeLibrary!=null)renderLandscapeLibrary();}
 private void renderRecommendations(){
  if(recommendationView==null)return;recommendationView.setVisibility(showRecommendations&&savedSongsReadable?View.VISIBLE:View.GONE);if(!showRecommendations||!savedSongsReadable)return;
  java.util.List<PracticeRecommendations.Pick> picks=recommendations.update(playlists,songNotes.snapshot(),recent,recordHistory,System.currentTimeMillis());
  PracticeRecommendationsUi.render(recommendationView,picks,recommendations.hasOther(),()->{recommendations.other();renderRecommendations();},this::playRecommendation,this::enqueue,this::keyText);
 }
 private void playRecommendation(Song song,int chosenKey){
  if(currentSong!=null&&(player.isPlaying()||loading)&&!currentSong.url.equals(song.url))new AppDialog(this).setTitle(R.string.recommendations_play_question).setMessage(getString(R.string.recommendations_play,song.title,keyText(chosenKey))).setNegativeButton(R.string.cancel,null).setNeutralButton(R.string.recommendations_add_queue,(d,w)->enqueue(song,chosenKey)).setPositiveButton(R.string.recommendations_play_now,(d,w)->playSong(song,chosenKey)).show();
  else playSong(song,chosenKey);
 }
 private void refreshSongNotes(){
  if(songNotes==null)return;
  for(Button button:noteButtons)button.setEnabled(currentSong!=null&&!loading);
  if(songNoteSummary!=null)songNoteSummary.setText(currentSong==null?getString(R.string.notes_empty_song):songNotes.summary(currentSong.url));
  if(previousNoteKey!=null){
   SongNotes.Entry entry=currentSong==null?null:songNotes.find(currentSong.url);
   boolean available=entry!=null&&entry.rating!=SongNotes.Rating.NONE&&entry.ratingKey!=key&&!loading;
   previousNoteKey.setVisibility(available?View.VISIBLE:View.GONE);
   if(available){previousNoteKey.setText(getString(R.string.notes_apply_key,keyText(entry.ratingKey)));previousNoteKey.setOnClickListener(v->setKey(entry.ratingKey));}
  }
 }
 private void showHelp() { if (fullScreen) leaveFullScreen();helpReturnPage=activePage.equals("settings")?"settings":"home";pageScrolls.put("help",0);showPage("help"); }
 private void recordPracticeStarted(){if(player.isPlaying()&&usage.enabled()&&!analyticsTrackStarted&&currentSong!=null){analyticsTrackStarted=true;usage.record(UsageEvent.started(savedSongsReadable&&playlists.contains(currentSong.url,key),key));}}
 private void populateSettings(){
  String tag=LanguagePreferences.tag(this),label=tag.equals("ko")?"한국어":tag.equals("ja")?"日本語":tag.equals("en")?"English":getString(R.string.language_system);
  SettingsPage.populate(settingsPage,label,this::chooseLanguage);
  SettingsPage.recommendations(settingsPage,showRecommendations,enabled->{showRecommendations=enabled;getPreferences(MODE_PRIVATE).edit().putBoolean("showRecommendations",enabled).apply();renderRecommendations();});
  SettingsPage.history(settingsPage,recordHistory,this::changeRecordHistory,this::clearHistory,songNotes::showAll);
  SettingsPage.searchHistory(settingsPage,recordSearches,enabled->{recordSearches=enabled;getPreferences(MODE_PRIVATE).edit().putBoolean("recordSearches",enabled).apply();},this::clearQueries);
  SettingsPage.privacy(settingsPage,usage.configured(),usage.enabled(),enabled->{if(enabled)usage.prompt(this,()->{populateSettings();usage.screen(activePage,fullScreen);recordPracticeStarted();});else{usage.setEnabled(false);analyticsTrackStarted=false;populateSettings();}},advertisingConsent::showOptions);
  SettingsPage.account(settingsPage,community::account);
  SettingsPage.support(settingsPage,this::showHelp,()->showPage("contact"),()->showPage("info"));
 }
 private void chooseLanguage(){
  String[] tags={"","ko","en","ja"},labels={getString(R.string.language_system),"한국어","English","日本語"};
  int selected=java.util.Arrays.asList(tags).indexOf(LanguagePreferences.tag(this));
  new AppDialog(this).setTitle(R.string.app_language).setSingleChoiceItems(labels,Math.max(0,selected),(dialog,which)->{dialog.dismiss();if(!tags[which].equals(LanguagePreferences.tag(this))){resumeAfterRecreation=player.getPlayWhenReady();LanguagePreferences.apply(this,tags[which]);}}).setNegativeButton(R.string.cancel,null).show();
 }
 private void changeRecordHistory(boolean enabled){
  recordHistory=enabled;getPreferences(MODE_PRIVATE).edit().putBoolean("recordHistory",enabled).apply();
  recordedCurrent=!enabled;
  if(enabled&&currentSong!=null&&player.isPlaying()){recordedCurrent=true;recent.record(currentSong,key);scheduleHistory();}
  renderRecent();
 }
 private void clearHistory(){
  new AppDialog(this).setTitle(R.string.history_clear).setMessage(R.string.history_clear_confirm).setNegativeButton(R.string.cancel,null)
   .setPositiveButton(R.string.delete,(dialog,which)->{historyHandler.removeCallbacks(persistRecent);recent=new RecentSongs();recordedCurrent=true;persistRecent.run();renderRecent();Toast.makeText(this,R.string.history_cleared,Toast.LENGTH_SHORT).show();}).show();
 }
 private void createFullScreenLayer() {
  fullScreenLayer = new FrameLayout(this);
  fullScreenLayer.setBackgroundColor(Color.BLACK);
  fullScreenLayer.setVisibility(View.GONE);
  root.addView(fullScreenLayer, new FrameLayout.LayoutParams(-1,-1));
  landscapeResumeButton=primaryButton(getString(R.string.resume_practice),v->resumeCurrent());
  landscapeResumeButton.setVisibility(resumePending?View.VISIBLE:View.GONE);
  fullScreenLayer.addView(landscapeResumeButton,new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER));
  sideControls = new LinearLayout(this); sideControls.setOrientation(LinearLayout.VERTICAL);
  sideControls.setPadding(dp(12),dp(12),dp(12),dp(12));sideControls.setGravity(Gravity.CENTER_HORIZONTAL);
  sideControls.addView(icon(R.drawable.ic_sk_search,getString(R.string.open_search_panel),v -> showSearch()));
  Button library=icon(R.drawable.ic_sk_list,getString(R.string.open_library_panel),v -> showLandscapeLibrary());
  library.setTooltipText(getString(R.string.library));sideControls.addView(library);
  sideControls.addView(new View(this),new LinearLayout.LayoutParams(1,0,1));
  sideControls.addView(icon(R.drawable.ic_sk_plus,getString(R.string.higher_accessibility),v -> setKey(key+1)));
  fullKeyLabel=SingKeyUi.heading(this,"0",30);fullKeyLabel.setTextColor(SingKeyUi.MINT);fullKeyLabel.setGravity(Gravity.CENTER);fullKeyLabel.setMinHeight(dp(64));
  fullKeyLabel.setPadding(0,dp(8),0,dp(8));sideControls.addView(fullKeyLabel,new LinearLayout.LayoutParams(-1,-2));
  sideControls.addView(icon(R.drawable.ic_sk_minus,getString(R.string.lower_accessibility),v -> setKey(key-1)));
  sideControls.addView(new View(this),new LinearLayout.LayoutParams(1,0,1));
  Button reset;
  if(getResources().getConfiguration().fontScale>1.3f) {
   reset=icon(R.drawable.ic_sk_refresh,getString(R.string.reset_original),v->setKey(0));reset.setTooltipText(getString(R.string.original_key));
  } else {
   reset=SingKeyUi.tab(this,getString(R.string.original_key),v->setKey(0));reset.setContentDescription(getString(R.string.reset_original));reset.setTextSize(13);reset.setMaxLines(2);reset.setPadding(0,dp(12),0,dp(12));
  }
  sideControls.addView(reset,new LinearLayout.LayoutParams(-1,-2));
  FrameLayout.LayoutParams side = new FrameLayout.LayoutParams(dp(88),-1,Gravity.END);
  sideScroll = new ScrollView(this);sideScroll.setFillViewport(true);sideScroll.setBackgroundColor(SingKeyUi.SURFACE);sideScroll.addView(sideControls);
  fullScreenLayer.addView(sideScroll,side);
  nextQueueMarquee = SingKeyUi.label(this,getString(R.string.no_next_song),13,true);
  nextQueueMarquee.setSingleLine(true);
  nextQueueMarquee.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
  nextQueueMarquee.setMarqueeRepeatLimit(-1);
  nextQueueMarquee.setSelected(true);
  nextQueueMarquee.setGravity(Gravity.CENTER_VERTICAL);
  nextQueueMarquee.setPadding(dp(12),0,dp(12),0);
  nextQueueMarquee.setBackground(SingKeyUi.shape(this,0xcc0b0e14,8));
  fullScreenLayer.addView(nextQueueMarquee,new FrameLayout.LayoutParams(-1,dp(36),Gravity.TOP));
  landscapeTop=row();Button record=SingKeyUi.videoIcon(this,R.drawable.ic_sk_note,getString(R.string.notes_edit),v->editCurrentNotes());noteButtons.add(record);landscapeTop.addView(record,new LinearLayout.LayoutParams(dp(48),dp(48)));Button bookmark=saveAction();iconSaveButtons.add(bookmark);landscapeTop.addView(bookmark,new LinearLayout.LayoutParams(dp(48),dp(48)));Button exit=SingKeyUi.videoIcon(this,R.drawable.ic_sk_collapse,getString(R.string.portrait_mode),v -> leaveFullScreen());landscapeTop.addView(exit,new LinearLayout.LayoutParams(dp(48),dp(48)));updateSaveButtons();
  fullScreenLayer.addView(landscapeTop,new FrameLayout.LayoutParams(dp(160),-2,Gravity.TOP|Gravity.RIGHT));
  layoutNextQueueMarquee();
  fullScreenLayer.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob) -> {
   if (sidePanel != null && r-l != or-ol) layoutSplit();
  });
  fullScreenLayer.setOnApplyWindowInsetsListener((view, insets) -> {
   int left = insets.getSystemWindowInsetLeft(), right = insets.getSystemWindowInsetRight();
   if (Build.VERSION.SDK_INT >= 28 && insets.getDisplayCutout() != null) {
    left = Math.max(left, insets.getDisplayCutout().getSafeInsetLeft()); right = Math.max(right, insets.getDisplayCutout().getSafeInsetRight());
   }
   landscapeInsetLeft = left; landscapeInsetRight = right;
   landscapeInsetTop = insets.getSystemWindowInsetTop();
   if (Build.VERSION.SDK_INT >= 28 && insets.getDisplayCutout() != null)
    landscapeInsetTop = Math.max(landscapeInsetTop,insets.getDisplayCutout().getSafeInsetTop());
   layoutNextQueueMarquee();
   FrameLayout.LayoutParams layout = (FrameLayout.LayoutParams)sideScroll.getLayoutParams();
   layout.width=dp(88)+right;layout.leftMargin=0;layout.rightMargin=0;layout.topMargin=0;layout.bottomMargin=0;sideScroll.setLayoutParams(layout);
   sideControls.setPadding(dp(12),landscapeInsetTop+dp(12),right+dp(12),insets.getSystemWindowInsetBottom()+dp(12));
   int bottom=insets.getSystemWindowInsetBottom();
   if(Build.VERSION.SDK_INT>=30)bottom=Math.max(bottom,insets.getInsets(WindowInsets.Type.ime()).bottom);
   if (sidePanel != null) sidePanel.setPadding(dp(12), landscapeInsetTop, right + dp(12), bottom + dp(8));
   layoutLandscape();
   return insets;
  });
 }
 private void layoutNextQueueMarquee() {
  if (nextQueueMarquee == null) return;
  int playerRight = sidePanel == null ? landscapeInsetRight + dp(88) : splitWidth;
  if(landscapeResumeButton!=null){FrameLayout.LayoutParams resume=new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER);resume.leftMargin=landscapeInsetLeft+dp(24);resume.rightMargin=playerRight+dp(24);landscapeResumeButton.setLayoutParams(resume);}
  FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-1,dp(36),Gravity.TOP);
  p.leftMargin = landscapeInsetLeft + dp(8);
  p.topMargin = landscapeInsetTop + dp(8);
  p.rightMargin = playerRight + dp(160);
  nextQueueMarquee.setLayoutParams(p);
  if(landscapeTop!=null){FrameLayout.LayoutParams a=new FrameLayout.LayoutParams(dp(160),-2,Gravity.TOP|Gravity.RIGHT);a.rightMargin=playerRight;a.topMargin=landscapeInsetTop;landscapeTop.setLayoutParams(a);}
  if(fullScreen&&sidePanel==null){FrameLayout.LayoutParams video=new FrameLayout.LayoutParams(-1,-1);video.rightMargin=playerRight;video.topMargin=landscapeInsetTop;videoView.setLayoutParams(video);}
 }
 private void layoutLandscape(){
  if(sideScroll==null)return;
  FrameLayout.LayoutParams side=(FrameLayout.LayoutParams)sideScroll.getLayoutParams();side.topMargin=0;sideScroll.setLayoutParams(side);
  if(sidePanel!=null)layoutSplit();else layoutNextQueueMarquee();
 }
 private void updateAdvertising(){
  boolean allowed=BuildConfig.ADS_ENABLED&&foreground&&advertisingConsent!=null&&advertisingConsent.canRequest();
  if(homeAd!=null)homeAd.active(allowed&&!fullScreen&&activePage.equals("home"));
  if(portraitAd!=null)portraitAd.active(allowed&&!fullScreen&&activePage.equals("player"));
 }
 private void updateNextQueueMarquee() {
  if (nextQueueMarquee == null) return;
  String value = (currentSong==null?getString(R.string.app_name):songTitle(currentSong))+getString(R.string.no_next_suffix);
  if (!queue.isEmpty()) {
   SavedSongs.Entry next = queue.get(0);
   value = (currentSong==null?"":songTitle(currentSong)+"  |  ")+getString(R.string.next_prefix) + next.song.title.replace('\n',' ').replace('\r',' ') + " · " + keyText(next.key);
  }
  if (!value.contentEquals(nextQueueMarquee.getText())) nextQueueMarquee.setText(value);
  nextQueueMarquee.setTextColor(queue.isEmpty() ? SingKeyUi.MUTED : SingKeyUi.MINT);
 }
 private void layoutSplit() {
  if (sidePanel == null || !fullScreen) return;
  splitWidth = Math.min(Math.round(fullScreenLayer.getWidth()*0.5f),Math.max(dp(300),Math.round(fullScreenLayer.getWidth()*0.44f)));
  FrameLayout.LayoutParams panelLayout = new FrameLayout.LayoutParams(splitWidth, -1, Gravity.RIGHT);
  sidePanel.setLayoutParams(panelLayout);
  FrameLayout.LayoutParams videoLayout = new FrameLayout.LayoutParams(-1,-1);
  videoLayout.rightMargin = splitWidth;videoLayout.topMargin=landscapeInsetTop;videoView.setLayoutParams(videoLayout);
  layoutNextQueueMarquee();
 }
 private void enterFullScreen() {
  ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(link.getWindowToken(),0);
  link.clearFocus(); showFullScreen(true);
  setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
 }
 private void leaveFullScreen() {
  showFullScreen(false);
  setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
 }
 private void showFullScreen(boolean enabled) {
  if (fullScreen == enabled) return;
  if (closeSearch != null) closeSearch.run();
  if (closeLibrary != null) closeLibrary.run();
  fullScreen = enabled;
  usage.screen(activePage,enabled);
  // Preserve the document and audio graph across layout changes.
  player.layoutChanged();
  ((ViewGroup)videoView.getParent()).removeView(videoView);
  if (enabled) {
   fullScreenLayer.addView(videoView,0,new FrameLayout.LayoutParams(-1,-1));
   chrome.setVisibility(View.GONE); fullScreenLayer.setVisibility(View.VISIBLE);

  } else {
   fullScreenLayer.setVisibility(View.GONE); chrome.setVisibility(View.VISIBLE); showPage("player");
   // Keep the portrait buttons above the video after returning from landscape.
   videoSlot.addView(videoView,0,new FrameLayout.LayoutParams(-1,-1));

  }
  updateAdvertising();layoutLandscape();layoutNextQueueMarquee();updateSystemBars(); fullScreenLayer.requestApplyInsets();
 }
 private void updateSystemBars() {
  if (Build.VERSION.SDK_INT >= 30) {
   WindowInsetsController controller = getWindow().getInsetsController();
   if (controller != null) {
    if (fullScreen) { controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE); controller.hide(WindowInsets.Type.systemBars()); }
    else controller.show(WindowInsets.Type.systemBars());
   }
  } else {
   getWindow().getDecorView().setSystemUiVisibility(fullScreen ? View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE : View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
  }
 }
 @Override public void onConfigurationChanged(Configuration config) {
  super.onConfigurationChanged(config);
  if (savedSongsDialog != null) savedSongsDialog.dismiss();
  showFullScreen(config.orientation == Configuration.ORIENTATION_LANDSCAPE);
  songNotes.layoutChanged();
 }
 @Override public void onWindowFocusChanged(boolean focused) { super.onWindowFocusChanged(focused); if (focused) updateSystemBars(); }
 // API 33+ uses the OnBackInvokedCallback registered in onCreate. Keep this only for older phones.
 @android.annotation.SuppressLint("GestureBackNavigation")
 @Override public void onBackPressed() { navigateBack(); }
 private void renderQueue() {
  schedulePractice();
  updateNextQueueMarquee();
  if (nextButton != null) updateNextQueueButton(nextButton);
  if (splitQueue != null) renderSplitQueue();
  queueLabel.setText(getString(R.string.queue_count,queue.size())); queueView.removeAllViews();
  if (queue.isEmpty()) { TextView empty = new TextView(this); empty.setText(getString(R.string.queue_empty_help)); empty.setTextColor(ink); queueView.addView(empty); }
  for(int i=0;i<queue.size();i++)queueView.addView(queueRow(i));
 }
 private LinearLayout queueHeader(TextView title,Button next){
  LinearLayout header=row();header.setPadding(0,dp(8),0,dp(16));
  LinearLayout.LayoutParams text=new LinearLayout.LayoutParams(0,-2,1);text.rightMargin=dp(12);header.addView(title,text);header.addView(next);return header;
 }
 private Button nextQueueButton(){
  Button next=icon(R.drawable.ic_sk_next,getString(R.string.next_queued_song),v->playNext());
  next.setTooltipText(getString(R.string.next_queued_song));
  next.setBackground(SingKeyUi.shape(this,SingKeyUi.RAISED,24));SingKeyUi.feedback(next,24);
  next.setPadding(dp(12),dp(12),dp(12),dp(12));
  next.setCompoundDrawables(SingKeyUi.icon(this,R.drawable.ic_sk_next,SingKeyUi.MINT,24),null,null,null);
  updateNextQueueButton(next);return next;
 }
 private void updateNextQueueButton(Button next){next.setEnabled(!queue.isEmpty());next.setAlpha(queue.isEmpty()?0.35f:1f);}
 private LinearLayout queueRow(int index){
  SavedSongs.Entry entry=queue.get(index);LinearLayout card=SingKeyUi.card(this);card.addView(songInfo(entry.song,entry.key));LinearLayout controls=row();controls.setPadding(0,dp(8),0,0);TextView order=SingKeyUi.label(this,""+(index+1),13,true);controls.addView(order,new LinearLayout.LayoutParams(0,-2,1));
  for(int direction:new int[]{-1,1}){Button move=icon(direction<0?R.drawable.ic_sk_up:R.drawable.ic_sk_down,getString(direction<0?R.string.queue_move_up:R.string.queue_move_down,songTitle(entry.song)),v->{if(PracticeSession.move(queue,index,direction)){practiceReady=true;renderQueue();}});boolean enabled=index+direction>=0&&index+direction<queue.size();move.setEnabled(enabled);move.setAlpha(enabled?1f:.3f);controls.addView(move);}
  controls.addView(icon(R.drawable.ic_sk_play,getString(R.string.play)+" · "+songTitle(entry.song),v->{queue.remove(index);renderQueue();playSong(entry.song,entry.key);}));controls.addView(icon(R.drawable.ic_sk_close,getString(R.string.remove_queued_song,songTitle(entry.song)),v->{queue.remove(index);practiceReady=true;renderQueue();}));card.addView(controls);return card;
 }
 private void enqueue(Song song,int songKey){if(queue.size()>=PracticeSession.MAX_QUEUE){Toast.makeText(this,R.string.queue_limit,Toast.LENGTH_LONG).show();return;}queue.add(new SavedSongs.Entry(song,songKey));practiceReady=true;usage.record(UsageEvent.queued(queue.size()));renderQueue();Toast.makeText(this,R.string.queue_added,Toast.LENGTH_SHORT).show();}
 private void playNext() { playNext(true); }
 private void playNext(boolean navigate) {
  if (queue.isEmpty()) { Toast.makeText(this, getString(R.string.queue_empty_toast), Toast.LENGTH_SHORT).show(); return; }
  SavedSongs.Entry next = queue.remove(0); renderQueue(); playSong(next.song, next.key, navigate);
 }
 private void selectSplitTab(boolean queued) {
  if(splitSearchTab==null)return;
  splitSearchTab.setSelected(!queued);splitQueueTab.setSelected(queued);
  splitSearchTab.setContentDescription(getString(R.string.search_tab_accessibility)+(!queued?getString(R.string.selected_suffix):""));
  splitQueueTab.setContentDescription(getString(R.string.queue_tab_accessibility)+(queued?getString(R.string.selected_suffix):""));
  splitSearchContent.setVisibility(queued?View.GONE:View.VISIBLE);
  splitQueueScroll.setVisibility(queued?View.VISIBLE:View.GONE);
  if(queued) {
   if(activeSearchInput!=null){activeSearchInput.clearFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(activeSearchInput.getWindowToken(),0);}
   renderSplitQueue();
  }
 }
 private void renderSplitQueue() {
  if(splitQueue==null)return;
  splitQueueTab.setText(queue.isEmpty()?getString(R.string.queue):getString(R.string.queue_tab_count,queue.size()));
  splitQueue.removeAllViews();
  splitQueue.addView(queueHeader(SingKeyUi.heading(this,getString(R.string.next_playback),16),nextQueueButton()));
  if(queue.isEmpty()) {
   TextView empty=SingKeyUi.label(this,getString(R.string.queue_empty_split),14,true);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(8),dp(24),dp(8),dp(24));splitQueue.addView(empty);
  }
  for(int i=0;i<queue.size();i++)splitQueue.addView(queueRow(i));
 }
 private void openPortraitSearch() {
  showSearch();
  SearchInput input=activeSearchInput;
  if(input!=null)input.post(()->{
   if(activeSearchInput!=input||!activePage.equals("search"))return;
   input.requestFocus();input.setSelection(input.length());
   ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(input,InputMethodManager.SHOW_IMPLICIT);
  });
 }
 private void showSearch(boolean remember){boolean previous=allowQueryRecord;allowQueryRecord=remember;try{showSearch();}finally{allowQueryRecord=previous;}}
 private void showSearch() {
  if(closeLibrary!=null)closeLibrary.run();
  link.finishInput();
  if(!fullScreen)showPage("search");
  if(closeSearch!=null) {
   if(fullScreen||portraitPlayerSearch)selectSplitTab(false);
   if(activeSearchInput!=null&&!link.getText().toString().equals(activeSearchInput.getText().toString()))activeSearchInput.setText(link.getText());
   if(activeSearchButton!=null)activeSearchButton.performClick();return;
  }
  final boolean split=fullScreen,inline=portraitPlayerSearch,panel=split||inline;
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
  SearchInput query=new SearchInput(this,suggestionSource);
  query.setSingleLine(true);query.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH|android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI);
  query.setHint(panel?getString(R.string.search_hint_short):getString(R.string.search_hint));query.setText(link.getText());
  SingKeyUi.field(query);query.setBackgroundColor(Color.TRANSPARENT);query.setPadding(dp(12),dp(12),dp(8),dp(12));query.setContentDescription(getString(split?R.string.landscape_search_input:R.string.search_hint));
  TextView message=SingKeyUi.label(this,getString(R.string.search_prompt),12,true);message.setPadding(0,dp(8),0,dp(8));message.setMaxLines(2);
  LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);
  LinearLayout history=AppDialog.body(this);history.setPadding(0,dp(8),0,dp(8));
  LinearLayout pager=AppDialog.body(this);pager.setPadding(0,dp(8),0,dp(12));
  LinearLayout scrolled=new LinearLayout(this);scrolled.setOrientation(LinearLayout.VERTICAL);scrolled.addView(history);scrolled.addView(results);scrolled.addView(pager);
  ScrollView list=new ScrollView(this);list.addView(scrolled);
  if(panel){searchPlaybackFeedback=new PlaybackFeedback(this,this::resumeCurrent,this::findAlternative);searchPlaybackFeedback.setPadding(dp(8),dp(8),dp(8),dp(16));scrolled.addView(searchPlaybackFeedback,0,new LinearLayout.LayoutParams(-1,-2));updatePlaybackFeedback();}
  final boolean[] active={true};
  final Future<?>[] pendingSearch={null};
  Runnable close=()->{
   active[0]=false;refreshSearchResults=null;searchPlaybackFeedback=null;searchPages.invalidate();thumbnails.cancelPending();query.finishInput();
   if(pendingSearch[0]!=null)pendingSearch[0].cancel(true);
   ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(query.getWindowToken(),0);
   if(split){
    fullScreenLayer.removeView(box);sidePanel=null;splitQueue=null;splitKeyLabel=null;
    splitSearchContent=null;splitQueueScroll=null;splitSearchTab=null;splitQueueTab=null;
    sideScroll.setVisibility(View.VISIBLE);layoutNextQueueMarquee();
   }else{mountPortraitVideo(false);searchPage.removeView(box);portraitSearchOption=null;link.setText("");cachedQuery="";cachedResults=null;searchPages.clear();navBar.setVisibility(View.VISIBLE);}
   splitQueue=null;splitKeyLabel=null;splitSearchContent=null;splitQueueScroll=null;splitSearchTab=null;splitQueueTab=null;
   closeSearch=null;activeSearchInput=null;activeSearchButton=null;splitSearchOption=null;lastSubmittedQuery="";
   link.onSuggestion(()->showSearch());
   link.setOnEditorActionListener((v,a,e)->{showSearch();return true;});
  };
  closeSearch=close;
  LinearLayout searchBody=box;
  LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.VERTICAL);
  if(panel){
   LinearLayout header=row();
   splitSearchTab=SingKeyUi.tab(this,getString(R.string.search),v->selectSplitTab(false));
   splitQueueTab=SingKeyUi.tab(this,getString(R.string.queue),v->selectSplitTab(true));
   header.addView(splitSearchTab,new LinearLayout.LayoutParams(0,-2,1));
   header.addView(splitQueueTab,new LinearLayout.LayoutParams(0,-2,1));
   header.addView(icon(R.drawable.ic_sk_close,getString(R.string.close_search_panel),v->{if(inline)showPage("player");else close.run();}));tabs.addView(header);divider(tabs);box.addView(tabs);
   searchBody=new LinearLayout(this);searchBody.setOrientation(LinearLayout.VERTICAL);searchBody.setPadding(0,dp(12),0,0);
   splitSearchContent=searchBody;
   box.addView(searchBody,new LinearLayout.LayoutParams(-1,0,1));
  }
  Runnable showHistory=()->{
   boolean empty=RecentQueries.normalize(query.getText().toString()).isEmpty();history.removeAllViews();history.setVisibility(empty&&recordSearches&&!recentQueries.entries().isEmpty()?View.VISIBLE:View.GONE);results.setVisibility(empty?View.GONE:View.VISIBLE);pager.setVisibility(!empty&&query.getText().toString().trim().equals(cachedQuery)?View.VISIBLE:View.GONE);
   if(empty)message.setText(R.string.search_prompt);
   if(!empty||!recordSearches)return;
   LinearLayout header=row();boolean stacked=getResources().getConfiguration().fontScale>1.3f;if(stacked)header.setOrientation(LinearLayout.VERTICAL);header.addView(SingKeyUi.heading(this,getString(R.string.search_history_title),15),stacked?new LinearLayout.LayoutParams(-1,-2):new LinearLayout.LayoutParams(0,-2,1));header.addView(AppDialog.quiet(this,getString(R.string.search_history_clear_short),v->new AppDialog(this).destructive(AlertDialog.BUTTON_POSITIVE).setTitle(R.string.search_history_clear).setMessage(R.string.search_history_clear_help).setNegativeButton(R.string.cancel,null).setPositiveButton(R.string.delete,(d,w)->{recentQueries.clear();searchHistoryReadable=true;persistQueries();query.setText("");}).show()));history.addView(header);
   for(String value:recentQueries.entries()){LinearLayout item=row();Button repeat=AppDialog.quiet(this,value,v->{query.setText(value);if(activeSearchButton!=null)activeSearchButton.performClick();});repeat.setTextColor(SingKeyUi.INK);repeat.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);repeat.setContentDescription(getString(R.string.search_history_repeat,value));item.addView(repeat,new LinearLayout.LayoutParams(0,-2,1));item.addView(icon(R.drawable.ic_sk_close,getString(R.string.search_history_remove,value),v->{recentQueries.remove(value);persistQueries();query.setText("");}));history.addView(item);}
  };
  final Runnable[] loadMore={null};
  Runnable renderPager=()->{pager.removeAllViews();if(cachedResults==null)return;if(searchPages.busy){TextView loadingLabel=SingKeyUi.label(this,getString(R.string.search_more_loading),14,true);loadingLabel.setMinHeight(dp(48));loadingLabel.setGravity(Gravity.CENTER_VERTICAL);pager.addView(loadingLabel);}else if(searchPages.hasMore()){Button more=button(getString(searchPages.failed?R.string.search_more_retry:R.string.search_more),v->loadMore[0].run());pager.addView(more);if(searchPages.failed)pager.addView(SingKeyUi.label(this,getString(R.string.search_more_error),13,true));}else if(!cachedResults.isEmpty())pager.addView(SingKeyUi.label(this,getString(cachedResults.size()>=SearchPages.LIMIT?R.string.search_more_limit:R.string.search_more_end),13,true));};
  Runnable renderResults=()->{
   results.removeAllViews();if(cachedResults==null)return;
   searchPages.retain(song->!embedAvailability.blocked(song.url));cachedResults=embedAvailability.visible(cachedResults);
   message.setText(cachedResults.isEmpty()?getString(searchPages.excluded>0?R.string.search_blocked_empty:R.string.search_empty):getString(R.string.search_results,cachedQuery,cachedResults.size()));
   for(Song song:cachedResults)results.addView(songRow(song,panel?null:0,()->playSearchResult(song),R.drawable.ic_sk_plus,getString(R.string.add_queued_song,songTitle(song)),()->enqueue(song,0),!panel));renderPager.run();showHistory.run();
  };
  refreshSearchResults=renderResults;
  loadMore[0]=()->{
   if(!active[0]||!RecentQueries.normalize(query.getText().toString()).equals(cachedQuery)||cachedBacking!=preferBacking)return;
   SearchPages.Ticket request=searchPages.more();if(request==null)return;renderPager.run();
   pendingSearch[0]=searchWorker.submit(()->{try{YouTubeSearchPage.Page page=PlayableSearch.filter(SongSearch.more(request.cursor),embedAvailability,SongSearch::more);runOnUiThread(()->{if(isDestroyed()||!active[0]||!searchPages.complete(request,page))return;int offset=list.getScrollY();cachedResults=new ArrayList<>(searchPages.songs());renderResults.run();list.post(()->list.scrollTo(0,offset));});}catch(Exception e){runOnUiThread(()->{if(!isDestroyed()&&active[0]&&searchPages.fail(request))renderPager.run();});}});
  };
  View.OnClickListener find=v->{
   query.finishInput();
   String value=RecentQueries.normalize(query.getText().toString());
   if(!SearchSafety.validInput(value)){
    searchPages.clear();pager.removeAllViews();if(pendingSearch[0]!=null)pendingSearch[0].cancel(true);
    thumbnails.cancelPending();results.removeAllViews();cachedResults=null;cachedQuery="";lastSubmittedQuery="";
    message.setMaxLines(4);message.setText(getString(value.isEmpty()?R.string.search_required:R.string.search_invalid_input));return;
   }
   if(panel)selectSplitTab(false);
   if(allowQueryRecord&&recordSearches&&searchHistoryReadable&&recentQueries.record(value))persistQueries();
   link.setText(value);query.setText(value);lastSubmittedQuery=value;cachedResults=null;cachedQuery="";SearchPages.Ticket request=searchPages.first();pager.removeAllViews();
   final boolean backing=preferBacking;
   usage.record(UsageEvent.search(backing,split));
   thumbnails.cancelPending();results.removeAllViews();message.setMaxLines(2);message.setText(getString(R.string.search_loading));list.scrollTo(0,0);
   ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(query.getWindowToken(),0);
   if(pendingSearch[0]!=null)pendingSearch[0].cancel(true);
   pendingSearch[0]=searchWorker.submit(()->{
    try{
     YouTubeSearchPage.Page page=PlayableSearch.filter(SongSearch.first(value,language,backing),embedAvailability,SongSearch::more);
     runOnUiThread(()->{if(isDestroyed()||!active[0]||!searchPages.complete(request,page))return;usage.record(UsageEvent.results(page.songs.size(),false));cachedQuery=value;cachedBacking=backing;cachedResults=new ArrayList<>(searchPages.songs());renderResults.run();});
    }catch(Exception e){runOnUiThread(()->{if(!isDestroyed()&&active[0]&&searchPages.fail(request)){usage.record(UsageEvent.results(0,true));message.setText(getString(R.string.search_error));}});}
   });
  };
  Button search=SingKeyUi.primaryIcon(this,R.drawable.ic_sk_search,getString(R.string.run_search),find);
  if(panel){
   LinearLayout inputRow=row();inputRow.setBackground(SingKeyUi.shape(this,SingKeyUi.RAISED,10));query.anchorTo(inputRow);
   inputRow.addView(query,new LinearLayout.LayoutParams(0,-2,1));
   inputRow.addView(search,new LinearLayout.LayoutParams(dp(48),-1));searchBody.addView(inputRow);
   splitSearchOption=searchOption();searchBody.addView(splitSearchOption);query.anchorTo(splitSearchOption);
  }else{
   LinearLayout header=row();
   header.addView(icon(R.drawable.ic_sk_back,getString(R.string.back_to_home),v->showPage("home")));
   LinearLayout inputRow=row();inputRow.setBackground(SingKeyUi.shape(this,SingKeyUi.RAISED,10));
   inputRow.addView(query,new LinearLayout.LayoutParams(0,-2,1));
   inputRow.addView(search,new LinearLayout.LayoutParams(dp(48),-1));
   header.addView(inputRow,new LinearLayout.LayoutParams(0,-2,1));searchBody.addView(header);
   portraitSearchOption=searchOption();searchBody.addView(portraitSearchOption);query.anchorTo(portraitSearchOption);
  }
  searchBody.addView(message);
  if(panel){
   searchBody.addView(list,new LinearLayout.LayoutParams(-1,0,1));
   splitQueue=new LinearLayout(this);splitQueue.setOrientation(LinearLayout.VERTICAL);
   splitQueueScroll=new ScrollView(this);splitQueueScroll.addView(splitQueue);box.addView(splitQueueScroll,new LinearLayout.LayoutParams(-1,0,1));
   LinearLayout footer=splitPitchControls();box.addView(footer);
   final CheckBox panelSearchOption=splitSearchOption;
   box.setOnApplyWindowInsetsListener((v,i)->{
    boolean keyboard=Build.VERSION.SDK_INT>=30?i.isVisible(WindowInsets.Type.ime()):i.getSystemWindowInsetBottom()>dp(100);
    int bottom=Build.VERSION.SDK_INT>=30?Math.max(i.getSystemWindowInsetBottom(),i.getInsets(WindowInsets.Type.ime()).bottom):i.getSystemWindowInsetBottom();
    int viewportHeight=fullScreenLayer.getHeight()>0?fullScreenLayer.getHeight():getResources().getDisplayMetrics().heightPixels;
    int available=viewportHeight-i.getSystemWindowInsetTop()-bottom;
    // Reserve the short landscape IME viewport for input and suggestions.
    tabs.setVisibility(keyboard?View.GONE:View.VISIBLE);
    footer.setVisibility(keyboard||available<dp(220)?View.GONE:View.VISIBLE);message.setVisibility(keyboard?View.GONE:View.VISIBLE);
    panelSearchOption.setVisibility(keyboard&&available<dp(260)?View.GONE:View.VISIBLE);
    query.anchorTo(panelSearchOption.getVisibility()==View.VISIBLE?panelSearchOption:query);
    box.post(()->{box.forceLayout();box.requestLayout();});return i;
   });
   box.setBackgroundColor(SingKeyUi.NAVY);box.setPadding(dp(12),0,dp(12),dp(8));
   if(split){
    sidePanel=box;fullScreenLayer.addView(box);sideScroll.setVisibility(View.GONE);
    layoutSplit();fullScreenLayer.requestApplyInsets();
   }else{
    // Keep at least 200 dp of actual video above input, including with the IME.
    searchPage.addView(box,new LinearLayout.LayoutParams(-1,0,1));
    box.setOnApplyWindowInsetsListener((v,i)->{
     boolean keyboard=Build.VERSION.SDK_INT>=30?i.isVisible(WindowInsets.Type.ime()):i.getSystemWindowInsetBottom()>dp(100);
     tabs.setVisibility(keyboard?View.GONE:View.VISIBLE);footer.setVisibility(keyboard?View.GONE:View.VISIBLE);
     message.setVisibility(keyboard?View.GONE:View.VISIBLE);panelSearchOption.setVisibility(keyboard?View.GONE:View.VISIBLE);
     query.anchorTo(keyboard?query:panelSearchOption);return i;
    });
    chrome.requestApplyInsets();
   }
   selectSplitTab(false);renderSplitQueue();
  }else{searchBody.addView(list,new LinearLayout.LayoutParams(-1,0,1));searchPage.addView(box,new LinearLayout.LayoutParams(-1,0,1));}
  activeSearchInput=query;activeSearchButton=search;
  query.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){}public void afterTextChanged(android.text.Editable value){showHistory.run();}});
  query.onSuggestion(()->search.performClick());
  query.setOnEditorActionListener((v,a,e)->{search.performClick();return true;});
  if(cachedResults!=null&&cachedBacking==preferBacking&&query.getText().toString().trim().equals(cachedQuery)){lastSubmittedQuery=cachedQuery;renderResults.run();}
  else if(!query.getText().toString().trim().isEmpty())search.performClick();
  else showHistory.run();
 }

 private LinearLayout splitPitchControls() {
  LinearLayout footer=new LinearLayout(this);footer.setOrientation(LinearLayout.VERTICAL);divider(footer);
  LinearLayout pitch=row();pitch.setPadding(0,dp(4),0,0);
  pitch.addView(icon(R.drawable.ic_sk_minus,getString(R.string.lower_accessibility),v->setKey(key-1)));
  Button reset=SingKeyUi.tab(this,keyText(key),v->setKey(0));reset.setTextSize(16);reset.setTextColor(SingKeyUi.MINT);reset.setContentDescription(getString(R.string.current_key_reset,keyText(key)));splitKeyLabel=reset;
  pitch.addView(reset,new LinearLayout.LayoutParams(0,-2,1));pitch.addView(icon(R.drawable.ic_sk_plus,getString(R.string.higher_accessibility),v->setKey(key+1)));footer.addView(pitch);
  return footer;
 }
 private void showLandscapeLibrary() {
  if(!fullScreen||closeLibrary!=null)return;
  if(closeSearch!=null)closeSearch.run();
  link.finishInput();landscapeList=null;libraryFolderScroll=0;
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
  box.setBackgroundColor(SingKeyUi.NAVY);box.setPadding(dp(12),0,dp(12),dp(8));
  landscapeLibrary=new LinearLayout(this);landscapeLibrary.setOrientation(LinearLayout.VERTICAL);
  box.addView(landscapeLibrary,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout footer=splitPitchControls();box.addView(footer);
  closeLibrary=()->{
   fullScreenLayer.removeView(box);sidePanel=null;landscapeLibrary=null;libraryScroll=null;landscapeList=null;splitKeyLabel=null;closeLibrary=null;
   sideScroll.setVisibility(View.VISIBLE);layoutNextQueueMarquee();
  };
  box.setOnApplyWindowInsetsListener((v,i)->{
   int height=fullScreenLayer.getHeight()-i.getSystemWindowInsetTop()-i.getSystemWindowInsetBottom();
   footer.setVisibility(height<dp(220)?View.GONE:View.VISIBLE);return i;
  });
  sidePanel=box;fullScreenLayer.addView(box);sideScroll.setVisibility(View.GONE);
  renderLandscapeLibrary();layoutSplit();fullScreenLayer.requestApplyInsets();
 }
 private void renderLandscapeLibrary() {
  if(landscapeLibrary==null)return;
  landscapeLibrary.removeAllViews();
  LinearLayout header=row();
  if(landscapeList!=null)header.addView(icon(R.drawable.ic_sk_back,getString(R.string.back_to_library),v->handleFullScreenBack()));
  TextView title=SingKeyUi.heading(this,landscapeList==null?getString(R.string.library):playlistName(landscapeList),18);
  title.setMaxLines(1);title.setEllipsize(android.text.TextUtils.TruncateAt.END);
  header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
  header.addView(icon(R.drawable.ic_sk_close,getString(R.string.close_library_panel),v->closeLibrary.run()));
  landscapeLibrary.addView(header);divider(landscapeLibrary);
  LinearLayout contents=new LinearLayout(this);contents.setOrientation(LinearLayout.VERTICAL);contents.setPadding(0,dp(12),0,dp(8));
  libraryScroll=new ScrollView(this);libraryScroll.addView(contents);landscapeLibrary.addView(libraryScroll,new LinearLayout.LayoutParams(-1,0,1));
  if(!savedSongsReadable){contents.addView(SingKeyUi.label(this,getString(R.string.library_unreadable),14,true));return;}
  if(landscapeList==null) {
   for(Playlists.ListEntry list:playlists.entries()) {
    LinearLayout item=row();item.setPadding(dp(8),dp(12),dp(4),dp(12));item.setMinimumHeight(dp(72));
    ImageView folder=new ImageView(this);folder.setImageDrawable(SingKeyUi.icon(this,R.drawable.ic_sk_list,SingKeyUi.MUTED,24));item.addView(folder,new LinearLayout.LayoutParams(dp(32),dp(32)));
    LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(12),0,dp(8),0);
    TextView name=SingKeyUi.heading(this,playlistName(list),16);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);info.addView(name);
    info.addView(SingKeyUi.label(this,getString(R.string.saved_count,list.songs.entries().size()),12,true));item.addView(info,new LinearLayout.LayoutParams(0,-2,1));
    ImageView arrow=new ImageView(this);arrow.setImageDrawable(SingKeyUi.icon(this,R.drawable.ic_sk_forward,SingKeyUi.MUTED,20));item.addView(arrow,new LinearLayout.LayoutParams(dp(24),dp(24)));
    item.setOnClickListener(v->{libraryFolderScroll=libraryScroll.getScrollY();landscapeList=list;renderLandscapeLibrary();});SingKeyUi.feedback(item,8);
    contents.addView(item);divider(contents);
   }
   if(playlists.entries().isEmpty())addLibraryEmpty(contents);
  } else {
   TextView hint=SingKeyUi.label(this,getString(R.string.library_play_hint),12,true);hint.setPadding(dp(8),0,dp(8),dp(12));contents.addView(hint);
   if(landscapeList.songs.entries().isEmpty())addLibraryEmpty(contents);
   for(SavedSongs.Entry entry:landscapeList.songs.entries()) {
    LinearLayout item=songRow(entry.song,entry.key,()->{closeLibrary.run();playSong(entry.song,entry.key);},R.drawable.ic_sk_plus,getString(R.string.queue_saved_song,songTitle(entry.song),keyText(entry.key)),()->{
     enqueue(entry.song,entry.key);
    },false);
    item.setContentDescription(getString(R.string.play_saved_song,songTitle(entry.song),keyText(entry.key)));contents.addView(item);
   }
  }
 }
 private void addLibraryEmpty(LinearLayout contents) {
  TextView empty=SingKeyUi.label(this,getString(R.string.library_empty),14,true);empty.setPadding(dp(8),dp(12),dp(8),dp(12));contents.addView(empty);
  contents.addView(flatText(getString(R.string.help_search_button),v->showSearch()));
 }
 private Button saveAction() {
  return SingKeyUi.videoIcon(this,R.drawable.ic_sk_bookmark,getString(R.string.save_current_key),v -> saveCurrentSong());
 }
 private Button saveButton() {
  Button button = button(getString(R.string.save), v -> saveCurrentSong());
  button.setContentDescription(getString(R.string.save_current_key));button.setCompoundDrawables(SingKeyUi.icon(this,R.drawable.ic_sk_bookmark,SingKeyUi.INK,20),null,null,null);button.setCompoundDrawablePadding(dp(6));
  saveButtons.add(button); updateSaveButtons(); return button;
 }
 private void updateSaveButtons() {
  refreshSongNotes();
  boolean enabled = savedSongsReadable && currentSong != null && !loading && player != null
    && player.getMediaItemCount() > 0 && player.getPlayerError() == null;
  boolean saved = savedSongsReadable && currentSong != null && playlists.contains(currentSong.url,key);
  String description=saved?getString(R.string.saved_choose_location):getString(R.string.save_current_key);
  int glyph=saved?R.drawable.ic_sk_bookmark_filled:R.drawable.ic_sk_bookmark;
  for(Button b:iconSaveButtons) {
   b.setEnabled(enabled);b.setSelected(saved);b.setAlpha(enabled?1f:0.4f);b.setContentDescription(description);
   b.setCompoundDrawables(SingKeyUi.icon(this,glyph,saved?SingKeyUi.MINT:SingKeyUi.INK,24),null,null,null);
  }
  for (Button button : saveButtons) {
   button.setEnabled(enabled);button.setSelected(saved);button.setText(saved?getString(R.string.saved):getString(R.string.save));button.setContentDescription(description);
   SingKeyUi.setButtonEmphasis(button,saved);
   button.setCompoundDrawables(SingKeyUi.icon(this,glyph,enabled?(saved?SingKeyUi.NAVY:SingKeyUi.INK):SingKeyUi.MUTED,20),null,null,null);
  }
 }
 private String keyText(int value) { return value == 0 ? getString(R.string.original_key) : getString(R.string.semitones,(value > 0 ? "+" : "") + value); }
 private boolean persistPlaylists() {
  try {
   getPreferences(MODE_PRIVATE).edit().putString("playlists", playlists.encode()).apply();
   renderRecommendations();
   if (selectedList != null) renderPlaylist(libraryPage,selectedList); else renderPlaylists(libraryPage);
   updateSaveButtons();
   if(landscapeLibrary!=null){int position=libraryScroll.getScrollY();renderLandscapeLibrary();libraryScroll.post(()->{if(libraryScroll!=null)libraryScroll.scrollTo(0,position);});}
   return true;
  } catch (java.io.IOException e) { Toast.makeText(this, getString(R.string.save_failed), Toast.LENGTH_SHORT).show(); return false; }
 }
 private void showManagedDialog(AlertDialog dialog) {
  if (savedSongsDialog != null) savedSongsDialog.dismiss();
  savedSongsDialog = dialog;
  dialog.setOnDismissListener(d -> { if (savedSongsDialog == dialog) savedSongsDialog = null; }); dialog.show();
 }
 private void saveInto(Playlists.ListEntry list, Song song, int savedKey) {
  list.songs.saveInOrder(song, savedKey);
  if (persistPlaylists()){usage.record(UsageEvent.saved(savedKey));Toast.makeText(this, getString(R.string.saved_to_playlist,playlistName(list),keyText(savedKey)), Toast.LENGTH_SHORT).show();}
 }
 private void saveCurrentSong() {
  if (!savedSongsReadable || currentSong == null || loading || player.getMediaItemCount() == 0 || player.getPlayerError() != null) return;
  showSaveChoices(currentSong,key);
 }
 private void showSaveChoices(Song song,int savedKey) {
  LinearLayout content=sheetBody(getString(R.string.save_my_key));TextView note=SingKeyUi.label(this,getString(R.string.save_song_at_key,songTitle(song),keyText(savedKey)),14,true);note.setPadding(0,0,0,dp(16));content.addView(note);
  content.addView(primaryButton(getString(R.string.new_playlist_save),v -> createPlaylist(song,savedKey)));
  TextView label=SingKeyUi.label(this,getString(R.string.choose_existing_playlist),13,true);label.setPadding(0,dp(20),0,dp(14));content.addView(label);
  for(Playlists.ListEntry list:new ArrayList<>(playlists.entries()))content.addView(playlistRow(list,()->{saveInto(list,song,savedKey);if(savedSongsDialog!=null)savedSongsDialog.dismiss();},true));
  showSheet(content,null);
 }
 private void createPlaylist(Song song,int savedKey) {
  LinearLayout content=sheetBody(getString(R.string.new_playlist));
  TextView nameLabel=SingKeyUi.label(this,getString(R.string.playlist_name),13,false);nameLabel.setPadding(0,0,0,dp(6));content.addView(nameLabel);
  EditText name=new EditText(this);name.setId(View.generateViewId());nameLabel.setLabelFor(name.getId());name.setSingleLine(true);name.setHint(getString(R.string.playlist_name_hint));SingKeyUi.field(name);name.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(40)});name.setImeOptions(android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI);content.addView(name);
  Runnable cancel=()->{if(savedSongsDialog!=null)savedSongsDialog.dismiss();if(song!=null)showSaveChoices(song,savedKey);};
  LinearLayout actions=row();actions.setPadding(0,dp(14),0,0);actions.addView(button(getString(R.string.cancel),v -> cancel.run()),new LinearLayout.LayoutParams(0,-2,1));
  actions.addView(primaryButton(song==null?getString(R.string.create):getString(R.string.create_save),v ->{try{String entered=name.getText().toString().trim();for(Playlists.ListEntry existing:playlists.entries())if(playlistName(existing).equals(entered))throw new IllegalArgumentException();Playlists.ListEntry list=playlists.create(entered);if(song!=null)saveInto(list,song,savedKey);else persistPlaylists();if(savedSongsDialog!=null)savedSongsDialog.dismiss();if(song==null)showSavedSongs();}catch(IllegalArgumentException e){name.setError(getString(name.getText().toString().trim().isEmpty()?R.string.invalid_playlist_name:R.string.duplicate_playlist_name));}}),new LinearLayout.LayoutParams(0,-2,1));content.addView(actions);
  showSheet(content,song==null?null:()->showSaveChoices(song,savedKey));
 }
 private LinearLayout sheetBody(String title) {
  LinearLayout body=page();body.setPadding(dp(20),dp(12),dp(20),dp(20));
  View handle=new View(this);handle.setBackground(SingKeyUi.shape(this,0xff303746,3));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(dp(36),dp(4));hp.gravity=Gravity.CENTER;hp.bottomMargin=dp(12);body.addView(handle,hp);
  LinearLayout header=row();header.addView(SingKeyUi.heading(this,title,20),new LinearLayout.LayoutParams(0,-2,1));header.addView(icon(R.drawable.ic_sk_close,getString(R.string.close),v ->{if(savedSongsDialog!=null)savedSongsDialog.cancel();}));body.addView(header);return body;
 }
 private void showSheet(LinearLayout body,Runnable cancel) {
  ScrollView sheet=AppDialog.scroll(this,body);
  AlertDialog dialog=new AppDialog(this).setView(sheet).create();if(cancel!=null)dialog.setOnCancelListener(d -> cancel.run());showManagedDialog(dialog);
  if(dialog.getWindow()!=null){dialog.getWindow().setGravity(Gravity.BOTTOM);android.view.WindowManager.LayoutParams p=dialog.getWindow().getAttributes();p.y=dp(16);dialog.getWindow().setAttributes(p);}
 }
 private void showSavedSongs() {
  if (fullScreen) leaveFullScreen();
  selectedList = null; renderPlaylists(libraryPage); showPage("library");
 }
 private void renderPlaylists(LinearLayout view) {
  selectedList=null;view.removeAllViews();LinearLayout head=row();boolean stacked=getResources().getConfiguration().fontScale>1.3f;
  if(stacked)head.setOrientation(LinearLayout.VERTICAL);
  head.addView(SingKeyUi.heading(this,getString(R.string.my_playlists),21),stacked?new LinearLayout.LayoutParams(-1,-2):new LinearLayout.LayoutParams(0,-2,1));
  Button create=primaryButton(getString(R.string.new_list),v -> createPlaylist(null,0));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(stacked?-1:-2,-2);cp.leftMargin=stacked?0:dp(12);cp.topMargin=stacked?dp(8):0;head.addView(create,cp);view.addView(head);
  TextView caption=SingKeyUi.label(this,getString(R.string.library_caption),13,true);caption.setPadding(0,0,0,dp(18));view.addView(caption);
  if(!savedSongsReadable){view.addView(SingKeyUi.label(this,getString(R.string.library_unreadable),14,true));return;}
  for(Playlists.ListEntry list:playlists.entries()) view.addView(playlistRow(list,()->renderPlaylist(view,list),false));
 }
 private void renderPlaylist(LinearLayout view,Playlists.ListEntry list) {
  selectedList=list;view.removeAllViews();LinearLayout back=row();back.addView(icon(R.drawable.ic_sk_back,getString(R.string.back_to_library),v -> renderPlaylists(view)));back.addView(SingKeyUi.heading(this,getString(R.string.library),13));view.addView(back);
  LinearLayout hero=SingKeyUi.card(this);TextView title=SingKeyUi.heading(this,playlistName(list),22);title.setPadding(0,dp(10),0,dp(8));hero.addView(title);
  TextView description=SingKeyUi.label(this,getString(R.string.playlist_description,list.songs.entries().size()),13,true);description.setPadding(0,0,0,dp(14));hero.addView(description);
  hero.addView(primaryButton(getString(R.string.community_publish),v->community.compose(list)));
  Button all=primaryButton(getString(R.string.play_all),v -> playPlaylist(list,0));all.setEnabled(!list.songs.entries().isEmpty());hero.addView(all);view.addView(hero);
  TextView heading=SingKeyUi.heading(this,getString(R.string.saved_songs),15);heading.setPadding(0,dp(8),0,dp(12));view.addView(heading);
  for(int i=0;i<list.songs.entries().size();i++){
   final int at=i;SavedSongs.Entry entry=list.songs.entries().get(i);
   LinearLayout card=SingKeyUi.card(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(10),dp(8),dp(6),dp(8));
   TextView number=SingKeyUi.label(this,""+(i+1),13,true);card.addView(number,new LinearLayout.LayoutParams(dp(26),-2));card.addView(songInfo(entry.song,entry.key),new LinearLayout.LayoutParams(0,-2,1));
   Button play=primaryButton(getString(R.string.play),v -> playPlaylist(list,at));play.setTextSize(12);card.addView(play,new LinearLayout.LayoutParams(dp(54),dp(48)));
   card.addView(icon(R.drawable.ic_sk_note,getString(R.string.notes_edit_song,songTitle(entry.song)),v->songNotes.edit(entry.song,entry.key)));
   card.addView(icon(R.drawable.ic_sk_close,getString(R.string.remove_from_playlist),v ->{list.songs.remove(entry.song.url);persistPlaylists();renderPlaylist(view,list);}));view.addView(card);
  }
 }
 private void playPlaylist(Playlists.ListEntry list, int start) {
  if (list.songs.entries().isEmpty()) return;
  java.util.List<SavedSongs.Entry> chosen=playlists.playback(list,start);if(chosen.size()>PracticeSession.MAX_QUEUE){Toast.makeText(this,R.string.queue_limit,Toast.LENGTH_LONG).show();return;}queue.clear(); queue.addAll(chosen);practiceReady=true;
  if (savedSongsDialog != null) savedSongsDialog.dismiss();
  playNext();
 }
 private void playSong(Song song) { playSong(song, 0); }
 private void playSearchResult(Song song) {
  String query=cachedQuery;
  // Finish only a search the user consumed; queue additions and automatic playback keep it.
  if (closeSearch != null) closeSearch.run();
  link.finishInput();link.setText("");cachedQuery="";cachedResults=null;
  playSong(song);
  currentSearchQuery=query;
 }
 private void playSong(Song song, int initialKey) { playSong(song,initialKey,true); }
 private void playSong(Song song, int initialKey, boolean navigate) {
  playSong(song,initialKey,navigate,0,true,false);
 }
 private void playSong(Song song,int initialKey,boolean navigate,long position,boolean autoplay,boolean alreadyRecorded) {
  String canonical=SearchSafety.canonicalVideo(song.url);
  if(canonical==null){Toast.makeText(this,R.string.search_invalid_input,Toast.LENGTH_LONG).show();return;}
  resumePending=false;practiceReady=true;
  usage.playing(false);usage.flushPractice();analyticsTrackStarted=false;
  if(currentSong==null||!currentSong.url.equals(song.url))currentSearchQuery="";
  recordedCurrent = alreadyRecorded; currentSong = song; loading = true;loadFailed=false;updateNextQueueMarquee();
  findingAlternative=false;
  if (!fullScreen && navigate) showPage("player");
  generation++;settingPlaybackKey=true;setKey(initialKey);settingPlaybackKey=false;
  status.setText(songTitle(song));trackChannel.setText(getString(R.string.channel_loading,songChannel(song)));
  player.load(canonical,key,Math.max(0,position),foreground&&autoplay);updateMini();schedulePractice();

 }
 @Override protected void onSaveInstanceState(Bundle state) { super.onSaveInstanceState(state); state.putString("link",activeSearchInput==null?link.getText().toString():activeSearchInput.getText().toString()); state.putBoolean("portraitSearch",!fullScreen&&activePage.equals("search"));state.putInt("key", key);
  state.putString("processId",PROCESS_ID);state.putBoolean("resumePending",resumePending);savePractice(false);
  state.putString("currentSearchQuery",currentSearchQuery);
  state.putStringArrayList("recommendationSelection",recommendations.selection());state.putStringArrayList("recommendationSeen",recommendations.seen());
  state.putString("activePage",activePage);state.putString("helpReturnPage",helpReturnPage);state.putString("returnPage",returnPage);state.putBoolean("analyticsTrackStarted",analyticsTrackStarted);
  if(currentSong!=null){state.putString("currentUrl",currentSong.url);state.putString("currentTitle",currentSong.title);state.putString("currentThumbnail",currentSong.thumbnailUrl);state.putLong("position",practicePosition());state.putBoolean("resumePlayback",resumeAfterRecreation||player.getPlayWhenReady());state.putBoolean("recordedCurrent",recordedCurrent);}
  ArrayList<String> urls = new ArrayList<>(), titles = new ArrayList<>();
  for (SavedSongs.Entry entry : queue) {
   Song song = entry.song; urls.add(song.url); titles.add(song.title); }
  int[] keys = new int[queue.size()]; for (int i=0;i<queue.size();i++) keys[i] = queue.get(i).key; state.putIntArray("queueKeys",keys);
  state.putStringArrayList("queueUrls", urls); state.putStringArrayList("queueTitles", titles); }
 private boolean importPublicPlaylist(CommunityData.ListItem item,boolean keys){
  if(!savedSongsReadable){Toast.makeText(this,R.string.library_unreadable,Toast.LENGTH_LONG).show();return false;}
  try{Playlists merged=CommunityData.importCopy(playlists,item,keys);if(!getPreferences(MODE_PRIVATE).edit().putString("playlists",merged.encode()).commit())throw new java.io.IOException("Save failed");playlists=merged;selectedList=null;renderPlaylists(libraryPage);updateSaveButtons();renderRecommendations();return true;}catch(java.io.IOException e){Toast.makeText(this,R.string.save_failed,Toast.LENGTH_LONG).show();return false;}
 }
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);if(!community.intent(intent))setIntent(intent);}
 @Override protected void onStart() { super.onStart();community.refresh(); foreground = true;historyHandler.removeCallbacks(practiceClock);historyHandler.postDelayed(practiceClock,5000);updateAdvertising();refreshFeaturedSongs(false); if (player.getPlaybackState() == PlaybackPlayer.STATE_ENDED && !queue.isEmpty()) playNext(false); }
 @Override protected void onStop() { historyHandler.removeCallbacks(practiceClock);historyHandler.removeCallbacks(persistPractice);savePractice(true);foreground = false;usage.playing(false);usage.flushPractice();updateAdvertising();link.stopSuggestions();if(activeSearchInput!=null)activeSearchInput.stopSuggestions();if(isChangingConfigurations())resumeAfterRecreation=player.getPlayWhenReady();super.onStop(); player.pause(); historyHandler.removeCallbacks(persistRecent); persistRecent.run(); }
 @Override protected void onDestroy() {practiceReady=false;historyHandler.removeCallbacks(practiceClock);historyHandler.removeCallbacks(persistPractice);usage.close();songNotes.close();community.close();homeAd.destroy();portraitAd.destroy();if (savedSongsDialog != null) savedSongsDialog.dismiss(); if (closeSearch != null) closeSearch.run();if(closeLibrary!=null)closeLibrary.run();suggestionSource.close(); chartSource.close();chartWorker.shutdownNow();historyHandler.removeCallbacks(persistRecent); generation++; thumbnails.close(); worker.shutdownNow(); searchWorker.shutdownNow(); player.release(); super.onDestroy(); }
}
