package kr.keymate.app;

import com.grack.nanojson.*;
import java.io.*;
import java.util.concurrent.TimeUnit;
import okhttp3.*;

/** Bounded HTTPS client; callers run on the community I/O worker. */
final class CommunityClient {
 interface Store {String read(String name)throws IOException;void write(String name,String value)throws IOException;}
 static final class Failure extends IOException {final int status;Failure(int status){super("Community request failed");this.status=status;}}
 private final String base,apiKey;private final Store store;private JsonObject session;
 private final OkHttpClient http;
 CommunityClient(String base,String apiKey,Store store)throws IOException {
  this(base,apiKey,store,new OkHttpClient.Builder().connectTimeout(10,TimeUnit.SECONDS).readTimeout(15,TimeUnit.SECONDS).callTimeout(25,TimeUnit.SECONDS).followRedirects(false).followSslRedirects(false).build());
 }
 CommunityClient(String base,String apiKey,Store store,OkHttpClient http)throws IOException {
  this.http=http;
  this.base=base.replaceAll("/+$","");this.apiKey=apiKey;this.store=store;
  if(!this.base.isEmpty()){HttpUrl u=HttpUrl.parse(this.base);if(u==null||!u.isHttps()||!u.encodedPath().equals("/")||u.query()!=null||u.fragment()!=null||!u.username().isEmpty()||!u.password().isEmpty())throw new IOException("Invalid service URL");}
  try{String raw=store.read("session");if(raw!=null){JsonObject saved=parse(raw);CommunityData.uuid(saved.getString("user_id"));if(!token(saved.getString("access_token"))||!token(saved.getString("refresh_token"))||saved.getLong("expires_at")<=0)throw new IOException("Invalid session");session=saved;}}
  catch(IOException|RuntimeException e){store.write("session",null);session=null;}
 }
 boolean configured(){return !base.isEmpty()&&!apiKey.isEmpty();}
 synchronized boolean signedIn(){return session!=null;}
 synchronized String userId(){return session==null?"":session.getString("user_id","");}
 String begin(String provider,String app)throws IOException {
  if(!configured())throw new IOException("Service unavailable");String nonce=CommunityOAuth.random(),verifier=CommunityOAuth.random();
  JsonObject pending=new JsonObject();pending.put("nonce",nonce);pending.put("verifier",verifier);pending.put("started",System.currentTimeMillis());store.write("pending",JsonWriter.string(pending));
  return CommunityOAuth.authorize(base,provider,app,nonce,verifier);
 }
 synchronized void finish(String callback,String app)throws IOException {
  String raw=store.read("pending");if(raw==null)throw new IOException("No pending login");JsonObject p=parse(raw);
  String code=CommunityOAuth.code(callback,app,p.getString("nonce"),p.getLong("started"),System.currentTimeMillis());
  store.write("pending",null);JsonObject data=new JsonObject();data.put("auth_code",code);data.put("code_verifier",p.getString("verifier"));
  saveSession(parse(request("/auth/v1/token?grant_type=pkce",data,null)));
 }
 synchronized String rpc(String function,JsonObject data,boolean authenticated)throws IOException {
  if(!configured())throw new IOException("Service unavailable");if(!function.matches("community_[a-z_]+"))throw new IOException("Invalid method");
  if(authenticated&&session==null)throw new Failure(401);
  String token=null;if(session!=null){
   if(session.getLong("expires_at")<System.currentTimeMillis()+60_000){JsonObject refresh=new JsonObject();refresh.put("refresh_token",session.getString("refresh_token"));try{saveSession(parse(request("/auth/v1/token?grant_type=refresh_token",refresh,null)));}catch(Failure e){if(e.status==400||e.status==401){clear();if(authenticated)throw new Failure(401);}else throw e;}}
   if(session!=null)token=session.getString("access_token");
  }
  try{return request("/rest/v1/rpc/"+function,data,token);}catch(Failure e){if(e.status==401)clear();throw e;}
 }
 synchronized void logout()throws IOException{String token=session==null?null:session.getString("access_token");clear();store.write("pending",null);if(token!=null){try{request("/auth/v1/logout?scope=local",new JsonObject(),token);}catch(IOException ignored){/* Local secrets are already gone. */}}}
 synchronized void clear()throws IOException{store.write("session",null);session=null;}
 private void saveSession(JsonObject response)throws IOException{
  String access=response.getString("access_token"),refresh=response.getString("refresh_token");JsonObject user=response.getObject("user");
  if(!token(access)||!token(refresh)||user==null)throw new IOException("Invalid session");
  String id=CommunityData.uuid(user.getString("id"));long seconds=response.getLong("expires_in");if(seconds<=0||seconds>86400)throw new IOException("Invalid expiry");
  JsonObject clean=new JsonObject();clean.put("access_token",access);clean.put("refresh_token",refresh);clean.put("user_id",id);clean.put("expires_at",System.currentTimeMillis()+seconds*1000);store.write("session",JsonWriter.string(clean));session=clean;
 }
 private String request(String path,JsonObject body,String token)throws IOException {
  Request.Builder request=new Request.Builder().url(base+path).header("apikey",apiKey).header("Accept","application/json").post(RequestBody.create(JsonWriter.string(body),MediaType.get("application/json; charset=utf-8")));
  if(token!=null)request.header("Authorization","Bearer "+token);
  try(Response response=http.newCall(request.build()).execute()){
   if(!response.isSuccessful())throw new Failure(response.code());ResponseBody data=response.body();if(data==null)return "null";
   if(data.contentLength()>2*1024*1024)throw new IOException("Response too large");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];try(InputStream in=data.byteStream()){int n;while((n=in.read(buffer))!=-1){if(out.size()+n>2*1024*1024)throw new IOException("Response too large");out.write(buffer,0,n);}}
   return out.toString("UTF-8");
  }
 }
 static JsonObject parse(String raw)throws IOException{try{return JsonParser.object().from(raw);}catch(JsonParserException|RuntimeException e){throw new IOException("Invalid response",e);}}
 private static boolean token(String value){return value!=null&&!value.isEmpty()&&value.length()<=16000&&!value.matches(".*\\s.*");}
 void close(){http.dispatcher().cancelAll();http.connectionPool().evictAll();}
}
