// Sonic/PitchDSP adapter. Packaged WASM only; no downloaded executable modules.
class SingKeyAndroidDSP {
 // Keep browser batching short; Sonic still has its own 80 ms FIFO.
 constructor(wasm,rate,frames=512) {
  this.dsp=new WebAssembly.Instance(new WebAssembly.Module(wasm),{}).exports;
  this.frames=frames;this.key=0;this.handle=this.dsp.SKPitchCreate(rate,2);
  this.pointers=this.dsp.malloc(8);this.left=this.dsp.malloc(frames*4);this.right=this.dsp.malloc(frames*4);
  if(!this.handle||!this.pointers||!this.left||!this.right)throw new Error('allocation');
  new Uint32Array(this.dsp.memory.buffer,this.pointers,2).set([this.left,this.right]);
  this.channels=[new Float32Array(this.dsp.memory.buffer,this.left,frames),new Float32Array(this.dsp.memory.buffer,this.right,frames)];
  this.inputEnergy=0;this.outputEnergy=0;this.samples=0;
 }
 process(left,right,outLeft,outRight,key) {
  if(left.length!==this.frames||outLeft.length!==this.frames)throw new Error('frames');
  key=Math.max(-12,Math.min(12,Math.round(key)));
  if(key!==this.key){this.dsp.SKPitchSetKey(this.handle,key);this.key=key;}
  this.channels[0].set(left);this.channels[1].set(right||left);
  for(let i=0;i<this.frames;i++)this.inputEnergy+=left[i]*left[i];
  this.dsp.SKPitchProcess(this.handle,this.pointers,this.frames,1);
  if(!this.healthy())throw new Error('processor');
  outLeft.set(this.channels[0]);if(outRight)outRight.set(this.channels[1]);
  for(let i=0;i<this.frames;i++)this.outputEnergy+=this.channels[0][i]**2;
  this.samples+=this.frames;
 }
 healthy(){return this.dsp.SKPitchIsHealthy(this.handle)===1;}
 reset(){this.dsp.SKPitchReset(this.handle);this.inputEnergy=this.outputEnergy=this.samples=0;}
 levels(){const result={input:Math.sqrt(this.inputEnergy/Math.max(1,this.samples)),output:Math.sqrt(this.outputEnergy/Math.max(1,this.samples)),healthy:this.healthy()};this.inputEnergy=this.outputEnergy=this.samples=0;return result;}
 destroy(){this.dsp.SKPitchDestroy(this.handle);this.dsp.free(this.left);this.dsp.free(this.right);this.dsp.free(this.pointers);}
}
