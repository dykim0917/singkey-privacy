function(config) {
 'use strict';
 // This is an experimental Web Audio adapter, not a YouTube API or OS output tap.
 // It reads the current media element; no media URLs, network interception or CSP changes.
 if(window===window.top||location.origin!=='https://www.youtube.com'||location.pathname!=='/embed/'+config.videoID)return;
 const bridge=window.singkeyPitchNative;
 if(!bridge)return;
 const send=(event,details={})=>bridge.postMessage(JSON.stringify({token:config.token,videoID:config.videoID,event,...details}));
 let video,graph,key=config.key,failed=false,lastReport=0,lastAd=null,pendingSince=0,status='',wasActive=false;
 const graphs=new WeakMap();
 const isAd=()=>!!document.querySelector('.ad-showing,.ad-interrupting');
 const emit=(name,details={})=>{if(status!==name+key){status=name+key;send(name,{key,...details});}};
 function route(g,ad){
  const processed=!failed&&key!==0&&!ad;
  g.dry.gain.value=processed?0:1;g.wet.gain.value=processed?1:0;
 }
 function fail(reason){
  if(failed)return;failed=true;
  if(graph){graph.wet.gain.value=0;graph.dry.gain.value=1;}
  // Native pauses using the official API and offers explicit original-key playback.
  send('pitch_unavailable',{reason});
 }
 function prepare(){
  if(!video||failed)return;
  if(graph){route(graph,isAd());if(!video.paused)graph.context.resume().catch(()=>fail('resume'));return;}
  if(!key)return;
  let context,processor,source;
  const target=video;
  try{
   context=new AudioContext({latencyHint:'interactive'});
   processor=new SingKeyAndroidDSP(Uint8Array.from(atob(config.wasm),c=>c.charCodeAt(0)),context.sampleRate);
   const node=context.createScriptProcessor(processor.frames,2,2),dry=context.createGain(),wet=context.createGain();
   const candidate={context,processor,node,dry,wet,lastCallback:performance.now(),maxGap:0,activeKey:null};
   node.onaudioprocess=event=>{
    const now=performance.now();candidate.maxGap=Math.max(candidate.maxGap,now-candidate.lastCallback);candidate.lastCallback=now;
    const outL=event.outputBuffer.getChannelData(0),outR=event.outputBuffer.getChannelData(1);
    if(target!==video||failed||target.paused){outL.fill(0);outR.fill(0);return;}
    const ad=isAd();route(candidate,ad);
    if(ad||key===0){
     if(candidate.activeKey!==0){processor.reset();candidate.activeKey=0;}
     outL.fill(0);outR.fill(0);return;
    }
    try{
     // Sonic flushes the previous key and preserves its queued timeline.
     // Reset only when entering DSP from a dry path, not at every key step.
     if(!candidate.activeKey)processor.reset();
     candidate.activeKey=key;
     processor.process(event.inputBuffer.getChannelData(0),event.inputBuffer.getChannelData(1),outL,outR,key);
    }catch{fail('processor');outL.fill(0);outR.fill(0);}
   };
   source=context.createMediaElementSource(target);
   source.connect(dry);dry.connect(context.destination);source.connect(node);node.connect(wet);wet.connect(context.destination);
   graph=candidate;graphs.set(target,candidate);route(graph,isAd());pendingSince=performance.now();
   if(!video.paused)context.resume().catch(()=>fail('resume'));
   emit('pitch_pending');
  }catch{
   if(source){source.disconnect();source.connect(context.destination);}
   else {context?.close();processor?.destroy();}
   fail('graph');
  }
 }
 function bind(){
  const next=document.querySelector('video');if(!next||next===video)return;
  graph?.context.suspend();video=next;graph=graphs.get(next);status='';wasActive=false;pendingSince=performance.now();
  const target=video;
  target.addEventListener('playing',()=>{if(video===target){wasActive=false;prepare();}});
  target.addEventListener('pause',()=>{if(video===target){wasActive=false;graph?.context.suspend();}});
  target.addEventListener('seeking',()=>{if(video===target){wasActive=false;graph?.processor.reset();status='';pendingSince=performance.now();emit('pitch_pending');}});
  if(key)prepare();else emit('original');
 }
 bridge.onmessage=event=>{
  try{
   const message=JSON.parse(event.data);
   if(message.token!==config.token||!Number.isInteger(message.key)||Math.abs(message.key)>12)return;
   const previousKey=key;key=message.key;status='';pendingSince=performance.now();
   // A command can switch 0 -> nonzero before the next audio callback.
   if(graph&&(previousKey===0||key===0)){graph.processor.reset();graph.activeKey=0;}
   bind();prepare();if(!key)emit('original');else emit('pitch_pending');
  }catch{fail('command');}
 };
 document.addEventListener('pointerdown',()=>{if(graph&&!failed)graph.context.resume().catch(()=>fail('resume'));},{capture:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){wasActive=false;graph?.context.suspend();}});
 setInterval(()=>{
  bind();if(!video||failed)return;
  const now=performance.now(),ad=isAd();
  if(ad!==lastAd){lastAd=ad;graph?.processor.reset();status='';pendingSince=now;send('ad',{active:ad});}
  if(graph)route(graph,ad);
  if(video.paused||video.readyState<3||video.muted||video.volume===0||document.hidden){wasActive=false;pendingSince=now;return;}
  if(!wasActive){
   wasActive=true;pendingSince=now;status='';
   // Suspended time is not a stalled callback. Allow the context to restart,
   // and require fresh signal before reporting the resumed pitch as active.
   if(graph){graph.lastCallback=now;graph.maxGap=0;graph.processor.levels();}
   if(key)emit('pitch_pending');
  }
  if(key)prepare();
  if(now-lastReport>=1000){
   lastReport=now;
   if(!key){emit('original');return;}
   if(!graph)return;
   const levels=graph.processor.levels();
   if(!levels.healthy){fail('processor');return;}
   if(ad){pendingSince=now;return;}
   if(levels.input>0.00001&&levels.output>0.00001){pendingSince=now;emit('pitch_active');}
   else if(now-pendingSince>10000){fail('audio_unavailable');return;}
   if(now-graph.lastCallback>3000){fail('audio_callback');return;}
   // Local debug diagnostics only. Hardware estimates are not measured A/V skew.
   const latencyMs=value=>Number.isFinite(value)&&value>=0?value*1000:null;
   send('metrics',{...levels,key,maxCallbackGapMs:graph.maxGap,sampleRate:graph.context.sampleRate,
    callbackFrames:graph.processor.frames,baseLatencyMs:latencyMs(graph.context.baseLatency),outputLatencyMs:latencyMs(graph.context.outputLatency)});graph.maxGap=0;
  }
 },250);
 send('frame_ready');
}
