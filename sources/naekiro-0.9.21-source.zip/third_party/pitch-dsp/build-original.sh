#!/bin/sh
set -eu

# Emscripten 4.0.15; compile the Apache-2.0 Sonic and SingKey-owned PitchDSP
# sources. The SDK lives outside tracked source; no global install is
# performed by this script. Set SINGKEY_EMCC or activate that emsdk in the shell.
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
repo_dir=$(CDPATH= cd -- "$script_dir/../.." && pwd)
compiler=${SINGKEY_EMCC:-emcc}
"$compiler" --version | head -n 1
"$compiler" "$script_dir/PitchDSP.c" \
  "$script_dir/vendor/sonic.c" \
  -I "$script_dir/include" -std=c11 -O3 \
  -sSTANDALONE_WASM=1 -sINITIAL_MEMORY=16777216 -sALLOW_MEMORY_GROWTH=0 \
  -sFILESYSTEM=0 \
  '-sEXPORTED_FUNCTIONS=["_SKPitchCreate","_SKPitchDestroy","_SKPitchSetKey","_SKPitchReset","_SKPitchProcess","_SKPitchIsHealthy","_SKPitchProcessedFrames","_SKPitchAudibleFrames","_malloc","_free"]' \
  -Wl,--no-entry -o "$repo_dir/app/src/main/assets/browser/BrowserPitchDSP.wasm"
