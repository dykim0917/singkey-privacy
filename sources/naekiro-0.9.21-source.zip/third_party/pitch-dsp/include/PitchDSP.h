#ifndef SINGKEY_PITCH_DSP_H
#define SINGKEY_PITCH_DSP_H
#include <stdint.h>
typedef struct SKPitch SKPitch;
SKPitch *SKPitchCreate(double sampleRate, uint32_t channels);
void SKPitchDestroy(SKPitch *processor);
void SKPitchSetKey(SKPitch *processor, int semitones);
double SKPitchLatencySeconds(void);
int SKPitchIsHealthy(SKPitch *processor);
void SKPitchReset(SKPitch *processor);
uint64_t SKPitchProcessedFrames(SKPitch *processor);
uint64_t SKPitchAudibleFrames(SKPitch *processor);
void SKPitchProcess(SKPitch *processor, float **channels, uint32_t frameCount, uint32_t stride);
#endif
