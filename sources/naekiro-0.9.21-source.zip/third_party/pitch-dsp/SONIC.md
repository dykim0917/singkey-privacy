# Sonic

Source: https://github.com/waywardgeek/sonic
Revision: b93885dcb70aae50c6f76b0fe4e0868f029a077e
Copyright Bill Cox, Apache-2.0. Full license in LICENSE-Sonic.

Vendored files: vendor/sonic.c and sonic.h, imported from the iOS branch
commit 8e8390b. PitchDSP.c is the SingKey-owned adapter and retains the
repository's GPL-3.0-or-later terms with the SingKey-owned-code exception in
../../LICENSE-GOOGLE-SDK-EXCEPTION.txt. That exception does not alter Sonic's license.
SingKey modifications are marked in those files:

- Allocate larger input/output/pitch buffers at creation; capacity checks replace
  realtime reallocations. Propagate processing failures to the caller.
- Expose a reset that discards queued samples after seeking without allocation.
- Account for flush padding in inputPlayTime as well as the input sample count.
- Preserve full sample rates in the sinc resampler with 64-bit phase, coefficient
  and accumulator arithmetic. The upstream 14-bit rate reduction truncated odd
  rates (including 44.1 kHz octaves), causing pitch and tempo to diverge.
- Use double precision for time bookkeeping, preventing exact octave speeds
  from crossing the algorithm boundary due to floating-point accumulation.
- Round the resampling rate to the nearest integer. The wrapper uses that same
  rational factor in the tempo stage to avoid cumulative duration error.

The app wrapper fixes speed/rate to 1, accepts pitch factors 0.5–2, and processes
up to 256 input frames per internal iteration. Its FIFO has an 80 ms startup
reserve. The Android browser experiment does not compensate video timing;
its additional Web Audio buffering and perceived sync remain unvalidated.
Capacity errors silence output and surface a playback error;
there is no unbounded buffer growth, audio callback allocation, or fallback to
unmodified pitch while showing a changed key. A key change flushes the preceding
factor, reconciles its frame count, then resets the resampler phase. Seeking
resets queued samples. Android uses 1024-frame ScriptProcessor callbacks to give
main-thread processing more scheduling margin than 512 frames. This trades
some latency for continuity; it does not compensate video timing. The inner C
processing chunk remains 256 frames and the 80 ms FIFO is unchanged.

Sonic internally quantizes its float API to signed 16-bit PCM. Synthetic tone,
duration, stereo isolation, rapid key change and allocation checks do not certify
the perceptual quality of polyphonic music or Bluetooth/hardware latency. See
../../docs/monetization/ANDROID_BROWSER_REVIEW.md for measured results and remaining device validation.

The WASM was imported unchanged from the same iOS commit. Rebuild using
`build-original.sh` with Emscripten 4.0.15, then run
`node scripts/test-android-browser.cjs` from the repository root. The copied
debug harness has its own historical WASM fixture; the product adapter uses
app/src/main/assets/browser/BrowserPitchDSP.wasm.
