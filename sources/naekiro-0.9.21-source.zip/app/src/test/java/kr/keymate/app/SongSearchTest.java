package kr.keymate.app;

import org.junit.Test;
import org.junit.Assume;
import static org.junit.Assert.*;

public class SongSearchTest {
 @Test public void appliesKeywordsForTheAppLanguage() {
  assertEquals("아이유 밤편지 노래방",SongSearch.searchQuery("아이유 밤편지",AppLanguage.KO,true));
  assertEquals("Adele Hello karaoke",SongSearch.searchQuery("Adele Hello",AppLanguage.EN,true));
  assertEquals("米津玄師 Lemon カラオケ",SongSearch.searchQuery("米津玄師 Lemon",AppLanguage.JA,true));
 }
 @Test public void uncheckedModeKeepsTheOriginalWordsAndSpacing() {
  for(AppLanguage lang:AppLanguage.values()) {
   assertEquals("Adele  Hello",SongSearch.searchQuery("  Adele  Hello  ",lang,false));
   assertEquals("米津玄師 Lemon",SongSearch.searchQuery("米津玄師 Lemon",lang,false));
   assertEquals("",SongSearch.searchQuery("  ",lang,true));
   assertEquals("https://www.youtube.com/watch?v=Upe2ewoz1PI",SongSearch.searchQuery("https://youtu.be/Upe2ewoz1PI",lang,true));
  }
 }
 @Test public void detectsBackingTermsAcrossLanguagesAndWidthVariants() {
  for(AppLanguage lang:AppLanguage.values())
   for(String query:new String[]{"Hello KARAOKE","Hello instrumental","Hello backing-track","Hello off vocal",
    "Hello no vocals","밤편지MR","밤편지 반주","Lemon カラオケ","Lemon からおけ","Lemon オフボーカル",
    "Lemon オフ・ヴォーカル","Lemon 伴奏","Lemon ボーカルなし","Lemon 歌なし","Lemon ｶﾗｵｹ","Hello ＭＲ"})
    assertEquals(query,SongSearch.searchQuery(query,lang,true));
 }
 @Test public void modeSwitchDoesNotAccumulateKeywordsOrMatchUnrelatedWords() {
  String original="Summer Paramore";
  assertEquals(original+" karaoke",SongSearch.searchQuery(original,AppLanguage.EN,true));
  assertEquals(original,SongSearch.searchQuery(original,AppLanguage.EN,false));
  String transformed=SongSearch.searchQuery(original,AppLanguage.EN,true);
  assertEquals(transformed,SongSearch.searchQuery(transformed,AppLanguage.JA,true));
 }
 @Test public void defaultsToKaraokeWithoutDuplicatingExplicitTerms() {
  assertEquals("아이유 밤편지 노래방", SongSearch.searchQuery("  아이유 밤편지  "));
  for (String query : new String[]{"내 길 더 잘 아시니 mr", "밤편지 MR", "밤편지(Mr)", "밤편지MR", "밤편지 노래방", "Adele KARAOKE", "Adele Instrumental", "밤편지 피아노반주"}) {
   assertEquals(query, SongSearch.searchQuery(query));
  }
  assertEquals("Summer 노래방", SongSearch.searchQuery("Summer"));
  assertEquals("", SongSearch.searchQuery("  "));
  assertEquals("https://www.youtube.com/watch?v=Upe2ewoz1PI", SongSearch.searchQuery("https://youtu.be/Upe2ewoz1PI"));
  assertEquals("https://www.youtube.com/watch?v=Upe2ewoz1PI", SongSearch.searchQuery("https://www.youtube.com/watch?v=Upe2ewoz1PI"));
  String query = SongSearch.searchQuery("밤편지");
  assertEquals(query, SongSearch.searchQuery(query));
 }

 @Test public void onlyAcceptsSecureYouTubeHosts() {
  assertTrue(SongSearch.isYouTubeUrl("https://youtu.be/Upe2ewoz1PI"));
  assertTrue(SongSearch.isYouTubeUrl("https://m.youtube.com/watch?v=Upe2ewoz1PI"));
  assertFalse(SongSearch.isYouTubeUrl("https://youtu.be/abc"));
  assertFalse(SongSearch.isYouTubeUrl("https://youtube.com.example.org/watch?v=abc"));
  assertFalse(SongSearch.isYouTubeUrl("https://notyoutube.com/watch?v=abc"));
  assertFalse(SongSearch.isYouTubeUrl("http://youtube.com/watch?v=abc"));
  assertFalse(SongSearch.isYouTubeUrl("아이유 밤편지 MR"));
 }
 @Test public void liveSearchReturnsCanonicalVideoLinks() throws Exception {
  Assume.assumeTrue("1".equals(System.getenv("KEYMATE_LIVE_TEST")));
  java.util.List<Song> songs = SongSearch.find("아이유 밤편지 MR");
  assertFalse("Expected YouTube search results", songs.isEmpty());
  for (Song song : songs) { assertTrue(SongSearch.isYouTubeUrl(song.url)); assertFalse(song.title.isEmpty()); }
  assertFalse("Expected a thumbnail URL", songs.get(0).thumbnailUrl.isEmpty());
  try (okhttp3.Response response = new okhttp3.OkHttpClient.Builder().callTimeout(15, java.util.concurrent.TimeUnit.SECONDS).build().newCall(new okhttp3.Request.Builder().url(songs.get(0).thumbnailUrl).build()).execute()) {
   assertTrue("Thumbnail HTTP status " + response.code(), response.isSuccessful());
   assertTrue(response.header("Content-Type", "").startsWith("image/"));
   assertTrue(response.body().byteStream().read(new byte[1024]) > 0);
  }
  System.out.println("Search results: " + songs.size() + "; first: " + songs.get(0).title);
 }
}
