package kr.keymate.app;
import org.junit.Test;
import static org.junit.Assert.*;
public class PracticeMeterTest {
 @Test public void excludesPauseAndBuffering(){PracticeMeter meter=new PracticeMeter();meter.playing(true,1000);meter.playing(false,3000);meter.playing(true,9000);meter.playing(false,14000);assertEquals(7000,meter.take(20000));assertEquals(0,meter.take(22000));}
 @Test public void flushDuringPlaybackDoesNotDoubleCount(){PracticeMeter meter=new PracticeMeter();meter.playing(true,0);assertEquals(5000,meter.take(5000));assertEquals(2000,meter.take(7000));meter.playing(false,8000);assertEquals(1000,meter.take(10000));}
 @Test public void resetDropsPreConsentTime(){PracticeMeter meter=new PracticeMeter();meter.playing(true,0);meter.reset();meter.playing(true,4000);assertEquals(1000,meter.take(5000));}
 @Test public void repeatedPlayingCallbacksDoNotRestartClock(){PracticeMeter meter=new PracticeMeter();meter.playing(true,1000);meter.playing(true,2000);meter.playing(false,4000);meter.playing(false,5000);assertEquals(3000,meter.take(9000));}
}
