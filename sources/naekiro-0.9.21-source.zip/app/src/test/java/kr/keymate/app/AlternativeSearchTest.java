package kr.keymate.app;
import org.junit.Test;
import static org.junit.Assert.*;
public class AlternativeSearchTest {
 private String query(String title,String previous){return AlternativeSearch.query(new Song("https://www.youtube.com/watch?v=QssOhIB5_g4",title,""),previous);}
 @Test public void preservesSubmittedSongAndArtist(){assertEquals("izi 응급실",query("[TJ노래방] 응급실 - izi / TJ Karaoke · TJ미디어","izi 응급실"));}
 @Test public void removesBrandingWhenPreviousWasUrlOrMissing(){assertEquals("응급실(쾌걸춘향OST) - izi",query("[TJ노래방] 응급실(쾌걸춘향OST) - izi / TJ Karaoke · TJ미디어","https://youtu.be/QssOhIB5_g4"));assertEquals("Drowning - WOODZ(조승연)",query("Drowning - WOODZ(조승연) (KY.80979) / KY KARAOKE · KY", ""));}
 @Test public void doesNotEraseSongBracketsOrSearchRawVideoId(){assertEquals("[Live] Song (Remix) - Artist",query("[Live] Song (Remix) - Artist · Channel",""));assertEquals("",query("QssOhIB5_g4",""));}
}
