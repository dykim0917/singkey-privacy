package kr.keymate.app;
import org.junit.Test;
import static org.junit.Assert.*;

public class RecentSongsTest {
 @Test public void limitsAndDeduplicatesHistory() {
  RecentSongs r = new RecentSongs();
  for (int i=0;i<25;i++) r.record(new Song("https://example.com/"+i,"Song "+i),0);
  assertEquals(20,r.entries().size());
  r.record(new Song("https://example.com/10","Ten"),-2);
  assertEquals(20,r.entries().size()); assertEquals("Ten",r.entries().get(0).song.title);
  assertEquals(-2,r.entries().get(0).key);
 }
 @Test public void aliasesAndKeyUpdatesPreservePositionAndTimestamp() throws Exception {
  RecentSongs r = new RecentSongs();
  Song s = new Song("https://youtu.be/abcdefghijk","First","https://example.com/thumb");
  r.record(s,-2); long time = r.playedAt(s.url);
  r.record(new Song("https://example.com/other","Other"),0);
  r.updateKey(new Song("https://www.youtube.com/watch?v=abcdefghijk","First"),3);
  assertEquals("Other",r.entries().get(0).song.title); assertEquals(3,r.entries().get(1).key);
  assertEquals(time,r.playedAt(s.url));
  RecentSongs restored = RecentSongs.decode(r.encode());
  assertEquals(2,restored.entries().size()); assertEquals(time,restored.playedAt(s.url));
  restored.remove(s.url); assertEquals(1,restored.entries().size());
 }
 @Test public void historyDoesNotModifyPlaylistKeys() throws Exception {
  Song song = new Song("https://youtu.be/abcdefghijk","Song");
  Playlists p = new Playlists(); Playlists.ListEntry list=p.create("Practice"); list.songs.saveInOrder(song,-5);
  RecentSongs r = new RecentSongs(); r.record(song,0); r.updateKey(song,4);
  assertEquals(-5,list.songs.find(song.url).key);
  assertEquals(4,RecentSongs.decode(r.encode()).entries().get(0).key);
 }
 @Test(expected=java.io.IOException.class) public void malformedHistoryIsRejected() throws Exception {
  RecentSongs.decode("historyVersion=99");
 }
}
