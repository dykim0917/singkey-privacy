package kr.keymate.app;

import org.junit.Test;
import java.io.*;
import java.util.*;
import static org.junit.Assert.*;

public class SongNotesTest {
 private Song song(String id){return new Song("https://youtu.be/"+id,"같은 제목 · 同じ歌 🎵");}
 private Song song(){return song("dQw4w9WgXcQ");}
 private SongNotes sample(){SongNotes n=new SongNotes();n.put(song(),-2,SongNotes.Rating.COMFORTABLE,"후렴 전에 숨\n日本語 🎵",SongNotes.Stage.PRACTICING,1000);return n;}
 @Test public void canonicalIdentitySeparatesDifferentVideos()throws Exception {
  SongNotes n=sample();assertNotNull(n.find("https://www.youtube.com/watch?v=dQw4w9WgXcQ"));assertNotNull(n.find("https://youtube.com/shorts/dQw4w9WgXcQ"));assertNull(n.find(song("9bZkp7q19f0").url));
  n.put(song("9bZkp7q19f0"),2,SongNotes.Rating.HIGH,"",SongNotes.Stage.NONE,2000);assertEquals(2,n.entries().size());
 }
 @Test public void metadataOnlyEditPreservesRatingKeyAndDate()throws Exception {
  SongNotes n=sample();n.put(song(),5,null,"新しいメモ",SongNotes.Stage.CONFIDENT,2000);SongNotes.Entry e=n.find(song().url);
  assertEquals(-2,e.ratingKey);assertEquals(1000,e.ratedAt);assertEquals(SongNotes.Rating.COMFORTABLE,e.rating);assertEquals(2000,e.updatedAt);assertEquals(SongNotes.Stage.CONFIDENT,e.stage);
 }
 @Test public void newRatingUsesCapturedKeyRatherThanPlaylistKey()throws Exception {
  Playlists lists=new Playlists();lists.create("練習").songs.save(song(),-2);
  SongNotes n=sample();n.put(song(),5,SongNotes.Rating.HIGH,"",SongNotes.Stage.NONE,2000);
  assertEquals(5,n.find(song().url).ratingKey);assertEquals(-2,lists.entries().get(0).songs.find(song().url).key);
 }
 @Test public void sameVideoUpdatesOneRecordAndSnapshotIsIndependent()throws Exception {
  SongNotes n=sample(),copy=n.copy();n.put(song(),0,SongNotes.Rating.LOW,"next",SongNotes.Stage.NONE,2000);
  assertEquals(1,n.entries().size());assertEquals(-2,copy.find(song().url).ratingKey);assertEquals(0,n.find(song().url).ratingKey);
 }
 @Test public void roundTripRetainsMultilingualTextAndTimestamps()throws Exception {
  SongNotes n=SongNotes.decode(sample().encode());SongNotes.Entry e=n.find(song().url);
  assertEquals("후렴 전에 숨\n日本語 🎵",e.note);assertEquals(song().title,e.song.title);assertEquals(-2,e.ratingKey);assertEquals(1000,e.ratedAt);assertEquals(1000,e.updatedAt);assertEquals(SongNotes.Stage.PRACTICING,e.stage);
 }
 @Test public void clearingRatingPreservesMemoAndStatus()throws Exception {
  SongNotes n=sample();n.put(song(),null,SongNotes.Rating.NONE,"keep",SongNotes.Stage.PRACTICING,2000);SongNotes.Entry e=n.find(song().url);
  assertEquals(SongNotes.Rating.NONE,e.rating);assertEquals(0,e.ratedAt);assertEquals(0,e.ratingKey);assertEquals("keep",e.note);
 }
 @Test public void emptyEntryIsRemovedAndHistoryIsIndependent()throws Exception {
  SongNotes n=sample();RecentSongs recent=new RecentSongs();recent.record(song(),-2);n.put(song(),null,SongNotes.Rating.NONE," ",SongNotes.Stage.NONE,2000);
  assertTrue(n.entries().isEmpty());assertEquals(1,recent.entries().size());
 }
 @Test public void clockMovingBackDoesNotCreateUnreadableNote()throws Exception {
  SongNotes n=sample();n.put(song(),null,null,"clock",SongNotes.Stage.NONE,1);assertEquals(1000,SongNotes.decode(n.encode()).find(song().url).ratedAt);
 }
 @Test public void invalidInputsLeaveOriginalUntouched()throws Exception {
  SongNotes n=sample();for(int key:new int[]{-13,13}){try{n.put(song(),key,SongNotes.Rating.HIGH,"bad",SongNotes.Stage.NONE,2000);fail();}catch(IllegalArgumentException expected){}}
  try{n.put(new Song("https://example.com/watch?v=dQw4w9WgXcQ","bad"),0,SongNotes.Rating.LOW,"",SongNotes.Stage.NONE,2000);fail();}catch(IllegalArgumentException expected){}
  try{n.put(song(),0,null,String.join("",Collections.nCopies(281,"a")),SongNotes.Stage.NONE,2000);fail();}catch(IllegalArgumentException expected){}
  assertEquals(-2,n.find(song().url).ratingKey);assertEquals(1,n.entries().size());
 }
 @Test public void limitDoesNotEvictExistingNotes()throws Exception {
  SongNotes n=new SongNotes();for(int i=0;i<SongNotes.MAX_ENTRIES;i++)n.put(song(String.format(Locale.ROOT,"%011d",i)),null,null,"note",SongNotes.Stage.NONE,i+1);
  try{n.put(song(),0,SongNotes.Rating.LOW,"",SongNotes.Stage.NONE,1000);fail();}catch(IllegalArgumentException expected){}
  assertEquals(500,n.entries().size());assertNotNull(n.find(song("00000000000").url));
  n.remove(song("00000000000").url);n.put(song(),0,SongNotes.Rating.LOW,"",SongNotes.Stage.NONE,1000);assertEquals(500,n.entries().size());
 }
 @Test public void corruptUnsupportedAndDuplicateDataFailClosed()throws Exception {
  String valid=sample().encode();
  for(String bad:new String[]{"bad",valid.replace("songNotesVersion=1","songNotesVersion=99"),valid.replace("0.key=-2","0.key=25"),valid.replace("0.rating=COMFORTABLE","0.rating=UNKNOWN"),valid.replace("count=1","count=2")}){try{SongNotes.decode(bad);fail(bad);}catch(IOException expected){}}
 }
 @Test public void importKeepsExistingRecordAndAddsOnlyMissingVideos()throws Exception {
  SongNotes existing=sample(),incoming=sample();incoming.put(song(),5,SongNotes.Rating.HIGH,"incoming",SongNotes.Stage.CONFIDENT,2000);incoming.put(song("9bZkp7q19f0"),null,null,"new",SongNotes.Stage.NONE,2000);
  SongNotes merged=SongNotes.merge(existing,incoming);assertEquals(2,merged.entries().size());assertEquals(-2,merged.find(song().url).ratingKey);assertEquals(1,existing.entries().size());assertEquals(2,SongNotes.merge(merged,incoming).entries().size());
 }
}
