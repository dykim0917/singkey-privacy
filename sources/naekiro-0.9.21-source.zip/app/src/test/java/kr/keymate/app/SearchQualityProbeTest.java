package kr.keymate.app;

import org.junit.Assume;
import org.junit.Test;

/** Opt-in observation, not a ranking regression assertion. */
public class SearchQualityProbeTest {
 @Test public void compareQuerySuffixes() throws Exception {
  Assume.assumeTrue("1".equals(System.getenv("KEYMATE_QUALITY_TEST")));
  String[] songs = {"아이유 밤편지", "윤하 사건의 지평선", "임영웅 사랑은 늘 도망가", "김광석 서른 즈음에", "천관웅 내 길 더 잘 아시니", "Adele Someone Like You"};
  for (String song : songs) for (String suffix : new String[]{"", " 노래방", " MR"}) {
   String query = song + suffix;
   try {
    java.util.List<Song> results = SongSearch.findExact(query);
    for (int i = 0; i < Math.min(5, results.size()); i++) {
     Song result = results.get(i);
     System.out.println("QUALITY\t" + query + "\t" + (i+1) + "\t" + result.title.replace('\t',' ').replace('\n',' ') + "\t" + result.url);
    }
   } catch (Exception e) { System.out.println("QUALITY_ERROR\t" + query + "\t" + e.getClass().getSimpleName()); }
  }
 }
}
