package kr.keymate.app;

import java.io.IOException;

/** Also runnable with Java 17 alone when the Android build environment is unavailable. */
public final class SavedSongsChecks {
 private static Song song(String id) { return new Song("https://www.youtube.com/watch?v=" + id, "제목\n한글 = : \\ 🎵", "https://example.com/thumb.jpg"); }
 private static void check(boolean condition) { if (!condition) throw new AssertionError(); }
 static void roundTrip() throws Exception {
  SavedSongs list = new SavedSongs(); Song song = song("abcdefghijk"); list.save(song, -2);
  SavedSongs restored = SavedSongs.decode(list.encode());
  check(restored.entries().size() == 1);
  check(restored.find(song.url).key == -2);
  check(restored.find(song.url).song.title.equals(song.title));
  check(restored.find(song.url).song.thumbnailUrl.equals(song.thumbnailUrl));
 }
 static void updateAndIdentity() {
  SavedSongs list = new SavedSongs(); list.save(song("abcdefghijk"), -2);
  for (String url : new String[]{"https://youtu.be/abcdefghijk?t=30", "https://m.youtube.com/watch?feature=share&v=abcdefghijk", "https://www.youtube.com/shorts/abcdefghijk", "https://www.youtube.com/embed/abcdefghijk"}) {
   list.save(new Song(url, "updated"), 3); check(list.entries().size() == 1); check(list.find(song("abcdefghijk").url).key == 3);
  }
  list.save(song("zyxwvutsrqp"), 0); check(list.entries().size() == 2);
  list.save(song("abcdefghijk"), -1); check(list.entries().get(0).key == -1);
 }
 static void deleteAndEmpty() throws Exception {
  SavedSongs list = SavedSongs.decode(""); check(list.entries().isEmpty());
  list.save(song("abcdefghijk"), 0); list.remove("https://youtu.be/abcdefghijk");
  check(SavedSongs.decode(list.encode()).entries().isEmpty());
  list.remove("missing"); check(list.entries().isEmpty());
 }
 static void snapshotsAndLimits() {
  SavedSongs list = new SavedSongs(); list.save(song("abcdefghijk"), -2);
  SavedSongs.Entry selected = list.entries().get(0); list.save(song("abcdefghijk"), 12);
  check(selected.key == -2); check(list.entries().get(0).key == 12);
  list.save(song("abcdefghijk"), -99); check(list.entries().get(0).key == -12);
  list.save(song("abcdefghijk"), 99); check(list.entries().get(0).key == 12);
 }
 static void corruptData() throws Exception {
  for (String value : new String[]{"broken", "version=2\ncount=0", "version=1\ncount=-1", "version=1\ncount=1", "version=1\ncount=10001", "version=1\ncount=no"}) {
   try { SavedSongs.decode(value); throw new AssertionError("Accepted corrupt data"); } catch (IOException expected) { }
  }
 }
 static void distinctSources() {
  SavedSongs list = new SavedSongs(); list.save(song("abcdefghijk"), -2);
  list.save(new Song("https://example.com/watch?v=abcdefghijk", "different"), 1);
  check(list.entries().size() == 2);
 }
 public static void main(String[] args) throws Exception {
  roundTrip(); updateAndIdentity(); deleteAndEmpty(); snapshotsAndLimits(); corruptData(); distinctSources();
  System.out.println("SavedSongs: 6 scenario groups passed");
 }
}
