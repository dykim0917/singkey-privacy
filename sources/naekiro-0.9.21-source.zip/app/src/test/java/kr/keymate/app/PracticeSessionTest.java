package kr.keymate.app;
import java.util.*;
import java.io.IOException;
import org.junit.Test;
import static org.junit.Assert.*;
public class PracticeSessionTest {
 private SavedSongs.Entry entry(int key){return new SavedSongs.Entry(new Song("https://youtu.be/M7lc1UVf-VE","곡"),key);}
 @Test public void restoresDuplicateVideosWithIndependentKeysAndPosition()throws Exception{PracticeSession saved=new PracticeSession(entry(2),45678,Arrays.asList(entry(-2),entry(5),entry(-2)));PracticeSession restored=PracticeSession.decode(saved.encode());assertEquals(45678,restored.position);assertEquals(2,restored.current.key);assertEquals(3,restored.queue.size());assertEquals(-2,restored.queue.get(0).key);assertEquals(5,restored.queue.get(1).key);assertFalse(saved.encode().contains("autoplay"));}
 @Test public void movesOnlySelectedOccurrenceAndKeepsBoundaries()throws Exception{List<SavedSongs.Entry> queue=new ArrayList<>(Arrays.asList(entry(1),entry(1),entry(3)));SavedSongs.Entry selected=queue.get(1);assertTrue(PracticeSession.move(queue,1,-1));assertSame(selected,queue.get(0));assertFalse(PracticeSession.move(queue,0,-1));assertFalse(PracticeSession.move(queue,2,1));queue.remove(1);PracticeSession restored=PracticeSession.decode(new PracticeSession(null,0,queue).encode());assertEquals(2,restored.queue.size());assertEquals(3,restored.queue.get(1).key);}
 @Test public void rejectsUnsafeCorruptOrUnsupportedData()throws Exception{String raw=new PracticeSession(entry(0),120,Collections.emptyList()).encode();for(String bad:new String[]{"broken",raw.replace("practiceVersion=1","practiceVersion=2"),raw.replace("count=0","count=501"),raw.replace("position=120","position=-1"),raw.replace("M7lc1UVf-VE","bad")})assertThrows(IOException.class,()->PracticeSession.decode(bad));}
}
