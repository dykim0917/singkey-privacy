package kr.keymate.app;
import org.junit.Test;
import static org.junit.Assert.*;
public class KeyMathTest {
 @Test public void octaveAndReset() {
  assertEquals(1f, KeyMath.ratio(0), 0.00001f);
  assertEquals(0.5f, KeyMath.ratio(-12), 0.00001f);
  assertEquals(2f, KeyMath.ratio(12), 0.00001f);
 }
 @Test public void semitoneAndBounds() {
  assertEquals(0.943874f, KeyMath.ratio(-1), 0.00001f);
  assertEquals(-12, KeyMath.clamp(-13));
  assertEquals(12, KeyMath.clamp(13));
 }
}
