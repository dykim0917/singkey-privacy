package kr.keymate.app;

import com.grack.nanojson.*;
import java.util.concurrent.TimeUnit;
import okhttp3.*;
import okhttp3.mockwebserver.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class AnalyticsTransportTest {
 private AnalyticsTransport transport(MockWebServer server){return new AnalyticsTransport("public-project-token",server.url("/batch/"),"random-installation","ko","0.9.17",true,new OkHttpClient.Builder().followRedirects(false).followSslRedirects(false).callTimeout(3,TimeUnit.SECONDS).build());}
 private JsonObject body(RecordedRequest request)throws Exception{assertNotNull(request);return JsonParser.object().from(request.getBody().readUtf8());}
 private void awaitQueue(AnalyticsTransport transport,int count)throws Exception{long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(3);while(transport.queuedEvents()!=count&&System.nanoTime()<end)Thread.sleep(10);assertEquals(count,transport.queuedEvents());}
 @Test public void sendsOnlyExplicitAnonymousEventFields()throws Exception{
  try(MockWebServer server=new MockWebServer()){server.enqueue(new MockResponse().setBody("{\"status\":1}"));try(AnalyticsTransport transport=transport(server)){
   transport.record(UsageEvent.screen("private song and URL",true));transport.record(UsageEvent.practice(32000));transport.flush();
   RecordedRequest request=server.takeRequest(3,TimeUnit.SECONDS);JsonArray events=body(request).getArray("batch");assertEquals("/batch/",request.getPath());assertEquals(2,events.size());
   JsonObject event=events.getObject(0),props=event.getObject("properties");assertEquals("random-installation",event.getString("distinct_id"));assertEquals("other",props.getString("screen_name"));assertFalse(props.getBoolean("$process_person_profile"));assertTrue(props.getBoolean("$geoip_disable"));assertEquals("debug",props.getString("build_type"));
   assertFalse(JsonWriter.string(events).contains("private song"));assertFalse(props.containsKey("$device_id"));assertFalse(props.containsKey("$set"));assertEquals(32,events.getObject(1).getObject("properties").getLong("seconds"));
  }}
 }
 @Test public void withdrawalDropsQueuedAndFutureEvents()throws Exception{
  try(MockWebServer server=new MockWebServer()){AnalyticsTransport transport=transport(server);transport.record(UsageEvent.saved(0));transport.close();transport.flush();transport.record(UsageEvent.saved(2));assertEquals(0,transport.queuedEvents());assertNull(server.takeRequest(250,TimeUnit.MILLISECONDS));}
 }
 @Test public void retriesTransientFailureOnceWithSameEventId()throws Exception{
  try(MockWebServer server=new MockWebServer()){server.enqueue(new MockResponse().setResponseCode(503));server.enqueue(new MockResponse().setResponseCode(503));try(AnalyticsTransport transport=transport(server)){
   transport.record(UsageEvent.search(true,false));transport.flush();JsonObject first=body(server.takeRequest(3,TimeUnit.SECONDS)).getArray("batch").getObject(0);awaitQueue(transport,1);
   transport.flush();JsonObject second=body(server.takeRequest(3,TimeUnit.SECONDS)).getArray("batch").getObject(0);assertEquals(first.getString("uuid"),second.getString("uuid"));awaitQueue(transport,0);transport.flush();assertNull(server.takeRequest(250,TimeUnit.MILLISECONDS));
  }}
 }
 @Test public void doesNotForwardEventsThroughRedirects()throws Exception{
  try(MockWebServer first=new MockWebServer();MockWebServer other=new MockWebServer()){
   first.enqueue(new MockResponse().setResponseCode(307).setHeader("Location",other.url("/collect")));try(AnalyticsTransport transport=transport(first)){
    transport.record(UsageEvent.saved(0));transport.flush();assertNotNull(first.takeRequest(3,TimeUnit.SECONDS));assertNull(other.takeRequest(300,TimeUnit.MILLISECONDS));awaitQueue(transport,0);
   }
  }
 }
 @Test public void queueStaysBoundedWhileNetworkStalls()throws Exception{
  try(MockWebServer server=new MockWebServer()){server.enqueue(new MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE));try(AnalyticsTransport transport=transport(server)){
   for(int i=0;i<20;i++)transport.record(UsageEvent.key(0,1));assertNotNull(server.takeRequest(3,TimeUnit.SECONDS));for(int i=0;i<1000;i++)transport.record(UsageEvent.key(1,2));assertTrue(transport.queuedEvents()<=AnalyticsTransport.MAX_EVENTS);
  }}
 }
 @Test public void productionEndpointCannotBeRedirectedToOtherHosts(){
  assertEquals("https://eu.i.posthog.com/batch/",AnalyticsTransport.ingestionEndpoint("https://eu.i.posthog.com").toString());
  for(String host:new String[]{"http://eu.i.posthog.com","https://eu.i.posthog.com.evil.example","https://evil.example","https://eu.i.posthog.com@evil.example","https://eu.i.posthog.com/path"}){
   try{AnalyticsTransport.ingestionEndpoint(host);fail("Accepted "+host);}catch(IllegalArgumentException expected){}
  }
 }
}
