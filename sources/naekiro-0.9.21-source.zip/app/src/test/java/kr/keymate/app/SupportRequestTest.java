package kr.keymate.app;

import com.grack.nanojson.JsonParser;
import com.grack.nanojson.JsonObject;
import org.junit.Test;
import static org.junit.Assert.*;

public class SupportRequestTest {
 @Test public void rejectsMalformedIdsAndNullCharacters(){assertFalse(SupportRequest.validMessage("A long enough inquiry\0"));try{SupportRequest.json("------------------------------------","idea","","A long enough inquiry","0.9.16","16","en");fail();}catch(IllegalArgumentException expected){}}
 @Test public void optionalReplyAndMessageBounds(){assertTrue(SupportRequest.validEmail(""));assertTrue(SupportRequest.validEmail("tester+singkey@example.com"));assertFalse(SupportRequest.validEmail("a@b"));assertFalse(SupportRequest.validEmail("x@example.com\r\nBcc: x@y.com"));assertFalse(SupportRequest.validMessage("         short    "));assertTrue(SupportRequest.validMessage("문의 내용입니다. 일본어 日本語"));assertFalse(SupportRequest.validMessage(String.join("",java.util.Collections.nCopies(3001,"x"))));}
 @Test public void payloadContainsOnlyDisclosedFieldsAndEscapesUserText()throws Exception{String text="A quoted \"message\"\n日本語와 한국어";JsonObject value=JsonParser.object().from(SupportRequest.json("01234567-1234-1234-1234-0123456789ab","idea","",text,"0.9.16","16","ko"));assertEquals(text,value.getString("message"));assertEquals(7,value.size());assertFalse(value.containsKey("playlists"));assertFalse(value.containsKey("history"));assertFalse(value.containsKey("to"));}
}
