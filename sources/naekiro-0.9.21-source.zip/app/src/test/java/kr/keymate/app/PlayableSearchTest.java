package kr.keymate.app;
import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;
public class PlayableSearchTest {
 private YouTubeSearchPage.Page blockedPage(String token){return new YouTubeSearchPage.Page(EmbedAvailabilityTest.page(EmbedAvailabilityTest.A).songs,new YouTubeSearchPage.Cursor(token,"1.0",AppLanguage.KO));}
 private EmbedAvailability cache(){return new EmbedAvailability(ids->Map.of(EmbedAvailabilityTest.A,false),()->1000,null,v->{});}
 @Test public void advancesPastBlockedPageWithoutLosingAllowedOrder()throws Exception{
  YouTubeSearchPage.Page result=PlayableSearch.filter(blockedPage("1"),cache(),cursor->EmbedAvailabilityTest.page(EmbedAvailabilityTest.C,EmbedAvailabilityTest.B));
  assertEquals(List.of(EmbedAvailabilityTest.C,EmbedAvailabilityTest.B),EmbedAvailabilityTest.ids(result));
 }
 @Test public void boundedEmptyPagesKeepCursorForUserToContinue()throws Exception{
  int[] calls={0};YouTubeSearchPage.Page result=PlayableSearch.filter(blockedPage("1"),cache(),cursor->{calls[0]++;return blockedPage(""+(Integer.parseInt(cursor.token)+1));});
  assertEquals(2,calls[0]);assertTrue(result.songs.isEmpty());assertEquals("3",result.next.token);assertEquals(3,result.excluded);
 }
 @Test public void repeatedCursorStopsWithoutInfiniteFetch()throws Exception{
  int[] calls={0};YouTubeSearchPage.Page result=PlayableSearch.filter(blockedPage("1"),cache(),cursor->{calls[0]++;return blockedPage("1");});assertEquals(1,calls[0]);assertNull(result.next);
 }
 @Test public void staleSearchCannotReplaceNewFilteredResults(){
  SearchPages pages=new SearchPages();SearchPages.Ticket old=pages.first(),current=pages.first();assertFalse(pages.complete(old,EmbedAvailabilityTest.page(EmbedAvailabilityTest.A)));assertTrue(pages.complete(current,EmbedAvailabilityTest.page(EmbedAvailabilityTest.B,EmbedAvailabilityTest.C)));pages.retain(song->!song.url.equals(EmbedAvailabilityTest.song(EmbedAvailabilityTest.B).url));assertEquals(1,pages.songs().size());
 }
}
