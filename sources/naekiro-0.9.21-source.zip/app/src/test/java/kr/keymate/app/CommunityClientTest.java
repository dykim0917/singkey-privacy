package kr.keymate.app;

import com.grack.nanojson.*;
import okhttp3.*;
import okhttp3.mockwebserver.*;
import okio.Buffer;
import org.junit.Test;
import java.io.IOException;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import javax.net.SocketFactory;
import static org.junit.Assert.*;

/** Exercise real request construction and session transitions without provider credentials. */
public class CommunityClientTest {
 private static final String UID="00000000-0000-4000-8000-000000000001", APP="kr.keymate.app.youtubeprobe";
 private static final class Memory implements CommunityClient.Store {
  final Map<String,String> values=new HashMap<>();
  public String read(String key){return values.get(key);}
  public void write(String key,String value){if(value==null)values.remove(key);else values.put(key,value);}
 }
 private static String session(long expires){return "{\"user_id\":\""+UID+"\",\"access_token\":\"old-access\",\"refresh_token\":\"old-refresh\",\"expires_at\":"+expires+"}";}
 private static String token(){return "{\"access_token\":\"new-access\",\"refresh_token\":\"new-refresh\",\"expires_in\":3600,\"provider_token\":\"must-not-persist\",\"user\":{\"id\":\""+UID+"\",\"email\":\"private@example.test\"}}";}
 private static Response response(Request r,int status,String body){return new Response.Builder().request(r).protocol(Protocol.HTTP_1_1).code(status).message("test").body(ResponseBody.create(body,MediaType.get("application/json"))).build();}
 private static CommunityClient client(Memory store,Interceptor handler)throws IOException{return new CommunityClient("https://example.supabase.co","sb_publishable_test",store,new OkHttpClient.Builder().addInterceptor(handler).build());}
 @Test public void pkceExchangeIsBoundToPendingLoginAndStoresOnlyAppSession()throws Exception{
  Memory store=new Memory();List<Request> sent=new ArrayList<>();List<String> bodies=new ArrayList<>();
  CommunityClient c=client(store,chain->{Request r=chain.request();sent.add(r);Buffer b=new Buffer();r.body().writeTo(b);bodies.add(b.readUtf8());return response(r,200,token());});
  String start=c.begin("google",APP);JsonObject pending=CommunityClient.parse(store.read("pending"));
  assertFalse(start.contains(pending.getString("verifier")));
  c.finish(APP+".auth://callback/"+pending.getString("nonce")+"?code=1234567890abcdef",APP);
  assertEquals("/auth/v1/token",sent.get(0).url().encodedPath());assertEquals("pkce",sent.get(0).url().queryParameter("grant_type"));
  assertEquals(pending.getString("verifier"),CommunityClient.parse(bodies.get(0)).getString("code_verifier"));
  assertNull(sent.get(0).header("Authorization"));assertEquals("sb_publishable_test",sent.get(0).header("apikey"));assertTrue(c.signedIn());assertEquals(UID,c.userId());
  assertNull(store.read("pending"));assertFalse(store.read("session").contains("private@example"));assertFalse(store.read("session").contains("must-not-persist"));
  assertThrows(IOException.class,()->c.finish(APP+".auth://callback/"+pending.getString("nonce")+"?code=1234567890abcdef",APP));assertEquals(1,sent.size());c.close();
 }
 @Test public void wrongCallbackDoesNotExchangeOrConsumeValidPendingLogin()throws Exception{
  Memory store=new Memory();CommunityClient c=client(store,chain->{fail("No request expected");return null;});c.begin("google",APP);
  String before=store.read("pending");assertThrows(IOException.class,()->c.finish(APP+".auth://callback/"+CommunityOAuth.random()+"?code=1234567890abcdef",APP));assertEquals(before,store.read("pending"));c.close();
 }
 @Test public void expiredSessionRefreshesBeforeAuthenticatedRpc()throws Exception{
  Memory store=new Memory();store.write("session",session(1));List<Request> calls=new ArrayList<>();
  CommunityClient c=client(store,chain->{Request r=chain.request();calls.add(r);return response(r,200,calls.size()==1?token():"{}");});
  assertEquals("{}",c.rpc("community_profile",new JsonObject(),true));assertEquals(2,calls.size());assertEquals("refresh_token",calls.get(0).url().queryParameter("grant_type"));assertEquals("Bearer new-access",calls.get(1).header("Authorization"));c.close();
 }
 @Test public void revokedRefreshAllowsAnonymousBrowseButRequiresNewLoginForWrites()throws Exception{
  Memory store=new Memory();store.write("session",session(1));List<Request> calls=new ArrayList<>();
  CommunityClient c=client(store,chain->{Request r=chain.request();calls.add(r);return response(r,calls.size()==1?400:200,calls.size()==1?"{}":"[]");});
  assertEquals("[]",c.rpc("community_feed",new JsonObject(),false));assertNull(calls.get(1).header("Authorization"));assertFalse(c.signedIn());assertNull(store.read("session"));assertThrows(CommunityClient.Failure.class,()->c.rpc("community_publish",new JsonObject(),true));assertEquals(2,calls.size());c.close();
 }
 @Test public void logoutClearsDeviceSessionEvenWhenServerUnavailable()throws Exception{
  Memory store=new Memory();store.write("session",session(System.currentTimeMillis()+300000));store.write("pending","unused");
  CommunityClient c=client(store,chain->{throw new IOException("offline");});c.logout();assertFalse(c.signedIn());assertTrue(store.values.isEmpty());c.close();
 }
 @Test public void damagedSessionRecoversToGuestWithoutChangingOtherLocalData()throws Exception{
  for(String invalid:Arrays.asList("bad json","{}",session(0),session(1).replace("old-refresh",""))){Memory store=new Memory();store.write("session",invalid);store.write("other","preserve");CommunityClient c=client(store,chain->{fail("No network for recovery");return null;});assertFalse(c.signedIn());assertNull(store.read("session"));assertEquals("preserve",store.read("other"));c.close();}
 }
 @Test public void redirectsAndOversizedResponsesAreNotAccepted()throws Exception{
  Memory store=new Memory();CommunityClient redirect=client(store,chain->response(chain.request(),302,""));assertThrows(CommunityClient.Failure.class,()->redirect.rpc("community_feed",new JsonObject(),false));redirect.close();
  CommunityClient huge=client(store,chain->response(chain.request(),200,"x".repeat(2*1024*1024+1)));assertThrows(IOException.class,()->huge.rpc("community_feed",new JsonObject(),false));huge.close();
 }
 @Test public void idleSocketCleanupRunsOffTheCallingThread()throws Exception{
  try(MockWebServer server=new MockWebServer()){
   server.enqueue(new MockResponse().setBody("[]"));
   CountDownLatch socketClosed=new CountDownLatch(1);AtomicReference<Thread> closingThread=new AtomicReference<>();
   SocketFactory sockets=new SocketFactory(){
    @Override public Socket createSocket(){return new Socket(){@Override public synchronized void close()throws IOException{closingThread.compareAndSet(null,Thread.currentThread());try{super.close();}finally{socketClosed.countDown();}}};}
    @Override public Socket createSocket(String h,int p)throws IOException{throw new IOException("Unused socket overload");}
    @Override public Socket createSocket(String h,int p,InetAddress l,int lp)throws IOException{throw new IOException("Unused socket overload");}
    @Override public Socket createSocket(InetAddress h,int p)throws IOException{throw new IOException("Unused socket overload");}
    @Override public Socket createSocket(InetAddress h,int p,InetAddress l,int lp)throws IOException{throw new IOException("Unused socket overload");}
   };
   OkHttpClient http=new OkHttpClient.Builder().socketFactory(sockets).addInterceptor(chain->chain.proceed(chain.request().newBuilder().url(server.url(chain.request().url().encodedPath())).build())).build();
   CommunityClient c=new CommunityClient("https://example.supabase.co","public-test",new Memory(),http);
   try{
    assertEquals("[]",c.rpc("community_feed",new JsonObject(),false));assertEquals(1,http.connectionPool().idleConnectionCount());
    Thread caller=Thread.currentThread();c.close();c.close();
    assertTrue("The pooled socket must be released",socketClosed.await(3,TimeUnit.SECONDS));assertNotSame(caller,closingThread.get());
   }finally{c.close();}
  }
 }
 @Test public void closeCancelsInFlightRequestWithoutWaitingForRpcLockAndRejectsNewCalls()throws Exception{
  try(MockWebServer server=new MockWebServer()){
   server.enqueue(new MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE));
   OkHttpClient http=new OkHttpClient.Builder().readTimeout(15,TimeUnit.SECONDS).addInterceptor(chain->chain.proceed(chain.request().newBuilder().url(server.url(chain.request().url().encodedPath())).build())).build();
   CommunityClient c=new CommunityClient("https://example.supabase.co","public-test",new Memory(),http);ExecutorService worker=Executors.newFixedThreadPool(2);
   try{
    Future<String> pending=worker.submit(()->c.rpc("community_feed",new JsonObject(),false));assertNotNull(server.takeRequest(3,TimeUnit.SECONDS));
    worker.submit(c::close).get(2,TimeUnit.SECONDS);
    ExecutionException stopped=assertThrows(ExecutionException.class,()->pending.get(3,TimeUnit.SECONDS));assertTrue(stopped.getCause() instanceof IOException);
    assertThrows(IOException.class,()->c.rpc("community_feed",new JsonObject(),false));assertThrows(IOException.class,()->c.begin("google",APP));assertEquals(1,server.getRequestCount());
   }finally{c.close();worker.shutdownNow();}
  }
 }
}
