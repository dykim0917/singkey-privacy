package kr.keymate.app;

import com.grack.nanojson.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.Collections;
import org.junit.Test;
import org.junit.Assume;
import static org.junit.Assert.*;

public class FeaturedSongsTest {
 private static final LocalDate START=LocalDate.of(2026,9,1), END=LocalDate.of(2026,9,13);
 private static final long FETCHED=Instant.parse("2026-09-13T03:00:00Z").toEpochMilli();
 private String fixture() throws IOException {
  try(java.io.InputStream input=getClass().getResourceAsStream("/tj-top10-2026-09-13.json")) {
   assertNotNull(input);return new String(input.readAllBytes(),StandardCharsets.UTF_8);
  }
 }
 @Test public void officialResponseKeepsRankAndSearchesTheActualSong() throws Exception {
  JsonObject root=JsonParser.object().from(fixture());JsonArray rows=root.getObject("resultData").getArray("items");
  // The provider's ordering must not become the displayed rank; omit ranks 11–100.
  Collections.reverse(rows);JsonObject extra=new JsonObject();extra.put("rank","11");rows.add(extra);
  FeaturedSongs.Chart chart=FeaturedSongs.parseResponse(JsonWriter.string(root),START,END,FETCHED);
  assertEquals(10,chart.entries.size());
  assertEquals(1,chart.entries.get(0).rank);assertEquals("행복하지 말아요",chart.entries.get(0).title);
  assertEquals("MC THE MAX 행복하지 말아요 노래방",SongSearch.searchQuery(chart.entries.get(0).query));
  assertEquals("Drowning",chart.entries.get(1).title);assertEquals("晩餐歌",chart.entries.get(9).title);
  assertEquals("2026.09.01 – 2026.09.13",chart.periodLabel());
 }
 @Test public void cacheRoundTripAndFreshnessUseKoreanCalendarDays() throws Exception {
  FeaturedSongs.Chart original=FeaturedSongs.parseResponse(fixture(),START,END,FETCHED);
  FeaturedSongs.Chart restored=FeaturedSongs.decode(original.encode());
  assertEquals(original.entries.get(8).query,restored.entries.get(8).query);
  assertEquals(original.periodLabel(),restored.periodLabel());assertEquals(FETCHED,restored.fetchedAt);
  assertTrue(restored.isFresh(Instant.parse("2026-09-13T14:59:59Z").toEpochMilli()));
  assertFalse(restored.isFresh(Instant.parse("2026-09-13T15:00:00Z").toEpochMilli()));
  assertFalse(restored.isFresh(FETCHED-1));assertNull(FeaturedSongs.decode(null));
  assertThrows(IOException.class,()->FeaturedSongs.decode("broken"));
 }
 @Test public void errorsAndPartialResponsesCannotReplaceAGoodChart() throws Exception {
  assertThrows(IOException.class,()->FeaturedSongs.parseResponse("{\"resultCode\":\"98\"}",START,END,FETCHED));
  assertThrows(IOException.class,()->FeaturedSongs.parseResponse("<html>unavailable</html>",START,END,FETCHED));
  JsonObject root=JsonParser.object().from(fixture());JsonArray rows=root.getObject("resultData").getArray("items");
  rows.remove(0);
  assertThrows(IOException.class,()->FeaturedSongs.parseResponse(JsonWriter.string(root),START,END,FETCHED));
  rows.add(rows.get(0));
  assertThrows(IOException.class,()->FeaturedSongs.parseResponse(JsonWriter.string(root),START,END,FETCHED));
  rows.getObject(0).put("rank","unknown");
  assertThrows(IOException.class,()->FeaturedSongs.parseResponse(JsonWriter.string(root),START,END,FETCHED));
 }
 @Test public void pagePeriodUsesValuesInsteadOfStalePlaceholders() throws Exception {
  String html="<input placeholder=\"2025-01-01\"> $(\"#searchStartDate\").val(\"2026-08-01\"); $(\"#searchEndDate\").val(\"2026-08-31\");";
  LocalDate[] dates=FeaturedSongs.periodFromPage(html);
  assertEquals(LocalDate.of(2026,8,1),dates[0]);assertEquals(LocalDate.of(2026,8,31),dates[1]);
  assertThrows(IOException.class,()->FeaturedSongs.periodFromPage("<input placeholder=\"2025-01-01\">"));
  assertThrows(IOException.class,()->FeaturedSongs.periodFromPage(html.replace("2026-08-31","2026-07-31")));
 }
 @Test public void liveOfficialChartReturnsTenCurrentEntries() throws Exception {
  Assume.assumeTrue("1".equals(System.getenv("SINGKEY_CHART_LIVE_TEST")));
  try(FeaturedSongs source=new FeaturedSongs()) {
   FeaturedSongs.Chart chart=source.fetch();assertEquals(10,chart.entries.size());
   assertTrue(chart.isFresh(System.currentTimeMillis()));
   System.out.println("TJ period: "+chart.periodLabel()+"; #1 "+chart.entries.get(0).query);
  }
 }
}
