package kr.keymate.app;
import java.io.IOException;
import org.junit.Test;
import static org.junit.Assert.*;
public class RecentQueriesTest {
 @Test public void normalizesDeduplicatesAndBounds()throws Exception{RecentQueries history=new RecentQueries();history.record("  아이유\t 밤편지　 ");assertEquals("아이유 밤편지",history.entries().get(0));for(int i=0;i<12;i++)history.record("song "+i);assertEquals(10,history.entries().size());history.record("song 4");assertEquals("song 4",history.entries().get(0));assertEquals(10,history.entries().size());assertEquals(history.entries(),RecentQueries.decode(history.encode()).entries());}
 @Test public void rejectsLinksInvalidAndUnsubmittedInputs(){RecentQueries history=new RecentQueries();for(String query:new String[]{""," ","https://youtu.be/M7lc1UVf-VE","https://example.com", "x".repeat(201),"a\u0000b"})assertFalse(history.record(query));assertTrue(history.entries().isEmpty());}
 @Test public void explicitRemovalAndClear()throws Exception{RecentQueries history=new RecentQueries();history.record("one");history.record("two");history.remove("one");assertEquals(1,RecentQueries.decode(history.encode()).entries().size());history.clear();assertTrue(RecentQueries.decode(history.encode()).entries().isEmpty());}
 @Test public void rejectsCorruptionAndUnknownVersions(){for(String raw:new String[]{"broken","version=2\ncount=0","version=1\ncount=11","version=1\ncount=1\nq.0=https://example.com"})assertThrows(IOException.class,()->RecentQueries.decode(raw));}
}
