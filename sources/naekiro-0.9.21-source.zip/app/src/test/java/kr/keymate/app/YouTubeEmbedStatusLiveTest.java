package kr.keymate.app;
import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;
public class YouTubeEmbedStatusLiveTest {
 @Test public void publicStatusWithConfiguredAndroidKey()throws Exception{
  Assume.assumeTrue("1".equals(System.getenv("KEYMATE_YOUTUBE_API_TEST")));
  assertFalse("Configure ignored youtube.properties first",BuildConfig.YOUTUBE_DATA_API_KEY.isEmpty());
  String cert=System.getenv("KEYMATE_YOUTUBE_CERT_SHA1");assertNotNull("Provide the registered debug certificate SHA-1",cert);
  List<String> ids=List.of("QssOhIB5_g4","BPr-NdAkmgY","M7lc1UVf-VE");
  Map<String,Boolean> statuses=new YouTubeEmbedStatus(BuildConfig.YOUTUBE_DATA_API_KEY,BuildConfig.APPLICATION_ID,cert).check(ids);
  assertEquals(new HashSet<>(ids),statuses.keySet());
  assertEquals(Boolean.FALSE,statuses.get("QssOhIB5_g4"));assertEquals(Boolean.FALSE,statuses.get("BPr-NdAkmgY"));
  // Search policy is distinct from the API's embeddable flag; rights can change.
  System.out.println("Search eligibility after official metadata and channel policy: "+statuses);
 }
}
