package kr.keymate.app;
import org.junit.Test;
import org.junit.Assume;
import static org.junit.Assert.*;
/** Public metadata only. Playback and pitch require WebView device checks. */
public class YouTubeProbeTest {
 @Test public void resolveRequestedVideoMetadata()throws Exception{
  Assume.assumeTrue("1".equals(System.getenv("KEYMATE_LIVE_TEST")));
  Song song=SongSearch.find("https://www.youtube.com/watch?v=Upe2ewoz1PI").get(0);
  assertEquals("https://www.youtube.com/watch?v=Upe2ewoz1PI",song.url);
  assertNotEquals("Expected public oEmbed metadata","Upe2ewoz1PI",song.title);
  assertTrue(SearchSafety.thumbnail(song.thumbnailUrl));
 }
}
