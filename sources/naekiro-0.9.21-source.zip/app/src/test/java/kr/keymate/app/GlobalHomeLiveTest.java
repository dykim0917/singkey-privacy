package kr.keymate.app;

import java.util.*;
import java.util.concurrent.TimeUnit;
import okhttp3.*;
import org.junit.Test;
import org.junit.Assume;
import static org.junit.Assert.*;

/** Opt-in source and search observations; no credentials or guessed provider APIs. */
public class GlobalHomeLiveTest {
 @Test public void compareJapaneseProvidersAndCrossLanguageSearches() throws Exception {
  Assume.assumeTrue("1".equals(System.getenv("SINGKEY_GLOBAL_LIVE_TEST")));
  LinkedHashSet<String> queries=new LinkedHashSet<>();
  try(FeaturedSongs source=new FeaturedSongs()) {
   FeaturedSongs.Chart chart=source.fetch(HomeCategory.JAPANESE);
   System.out.println("JOYSOUND monthly: "+chart.periodLabel());assertEquals(10,chart.entries.size());
   for(FeaturedSongs.Entry entry:chart.entries.subList(0,3))queries.add(entry.query);
  }
  OkHttpClient client=new OkHttpClient.Builder().callTimeout(30,TimeUnit.SECONDS).build();
  try(Response response=client.newCall(new Request.Builder().url("https://www.clubdam.com/ranking/").build()).execute()) {
   assertTrue(response.isSuccessful());assertNotNull(response.body());
   org.jsoup.nodes.Element monthly=org.jsoup.Jsoup.parse(response.body().string()).getElementById("ranking-monthly");
   assertNotNull(monthly);System.out.println("DAM monthly update: "+monthly.selectFirst(".p-section-header__date").text());
   org.jsoup.select.Elements rows=monthly.select(".p-song--song");assertTrue(rows.size()>=10);
   for(org.jsoup.nodes.Element row:rows.subList(0,3)) {
    String query=row.selectFirst(".p-song__artist").text()+" "+row.selectFirst(".p-song__title").text();
    queries.add(java.text.Normalizer.normalize(query,java.text.Normalizer.Form.NFKC));
   }
  } finally {client.dispatcher().cancelAll();client.connectionPool().evictAll();}
  for(String query:queries)observe(query,AppLanguage.JA,true);
  observe("あいみょん マリーゴールド",AppLanguage.KO,true);
  observe("ABBA Dancing Queen",AppLanguage.EN,true);
  observe("Adele Someone Like You",AppLanguage.JA,true);
  observe("Adele Someone Like You",AppLanguage.JA,false);
 }
 private void observe(String query,AppLanguage language,boolean backing) throws Exception {
  List<Song> songs=SongSearch.find(query,language,backing);assertFalse(query,songs.isEmpty());
  System.out.println("QUERY\t"+language+"\t"+backing+"\t"+SongSearch.searchQuery(query,language,backing));
  for(int i=0;i<Math.min(5,songs.size());i++)System.out.println("RESULT\t"+(i+1)+"\t"+songs.get(i).title);
 }
}
