package kr.keymate.app;

import org.junit.Test;
import static org.junit.Assert.*;

public final class PullToReloadGestureTest {
 @Test public void releaseAboveThresholdFiresOnlyOnce(){PullToReloadGesture g=new PullToReloadGesture(8,72);g.start(100,20,true);assertTrue(g.move(104,100));assertTrue(g.ready());assertTrue(g.finish());assertFalse(g.finish());}
 @Test public void shortPullAndTapDoNotReload(){PullToReloadGesture g=new PullToReloadGesture(8,72);g.start(100,20,true);assertFalse(g.move(101,24));assertFalse(g.finish());g.start(100,20,true);assertTrue(g.move(100,60));assertFalse(g.finish());}
 @Test public void scrollingVideoOrResultsNeverStartsRefresh(){PullToReloadGesture g=new PullToReloadGesture(8,72);g.start(100,200,false);assertFalse(g.move(100,400));assertFalse(g.finish());}
 @Test public void horizontalOrUpwardGestureCannotTurnIntoRefresh(){for(int[] point:new int[][]{{150,25},{100,0}}){PullToReloadGesture g=new PullToReloadGesture(8,72);g.start(100,20,true);assertFalse(g.move(point[0],point[1]));assertFalse(g.move(100,180));assertFalse(g.finish());}}
 @Test public void pullingBackOrCancellingDoesNotReload(){PullToReloadGesture g=new PullToReloadGesture(8,72);g.start(100,20,true);g.move(100,110);assertTrue(g.ready());g.move(100,50);assertFalse(g.finish());g.start(100,20,true);g.move(100,110);g.cancel();assertFalse(g.finish());}
}
