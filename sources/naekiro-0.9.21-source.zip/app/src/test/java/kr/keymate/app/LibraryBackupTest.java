package kr.keymate.app;

import org.junit.Test;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import static org.junit.Assert.*;

public class LibraryBackupTest {
 private Playlists sample(){Playlists value=new Playlists();Playlists.ListEntry list=value.create("내 연습 · 日本語");list.songs.saveInOrder(new Song("https://www.youtube.com/watch?v=dQw4w9WgXcQ","노래 · 歌 · Song","https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg"),-5);list.songs.saveInOrder(new Song("https://youtu.be/9bZkp7q19f0","Second"),3);value.create("빈 목록");return value;}
 @Test public void roundTripPreservesNamesOrderKeysAndEmptyLists()throws Exception{Playlists original=sample(),restored=LibraryBackup.read(new ByteArrayInputStream(LibraryBackup.encode(original)));assertEquals(2,restored.entries().size());assertEquals("내 연습 · 日本語",restored.entries().get(0).name);assertEquals(0,restored.entries().get(1).songs.entries().size());assertEquals("노래 · 歌 · Song",restored.entries().get(0).songs.entries().get(0).song.title);assertEquals(-5,restored.entries().get(0).songs.entries().get(0).key);assertEquals(3,restored.entries().get(0).songs.entries().get(1).key);assertEquals(2,LibraryBackup.songs(restored));}
 @Test public void mergeAddsRenamedListsWithoutOverwritingOriginal()throws Exception{Playlists original=sample(),merged=LibraryBackup.merge(original,sample(),"(복원)");assertEquals(2,original.entries().size());assertEquals(4,merged.entries().size());assertEquals("내 연습 · 日本語 (복원)",merged.entries().get(2).name);assertEquals(-5,merged.entries().get(0).songs.entries().get(0).key);assertEquals(4,LibraryBackup.songs(merged));}
 @Test public void repeatedImportAndLongNamesRemainUnique()throws Exception{Playlists original=new Playlists();original.create(String.join("",Collections.nCopies(40,"한")));Playlists merged=LibraryBackup.merge(LibraryBackup.merge(original,original,"(복원)"),original,"(복원)");assertEquals(3,merged.entries().size());assertTrue(merged.entries().get(2).name.endsWith("(복원) 2"));for(Playlists.ListEntry list:merged.entries())assertTrue(list.name.length()<=40);}
 @Test public void duplicateEmojiNamesRemainValidUnicode()throws Exception{Playlists original=new Playlists();original.create(String.join("",Collections.nCopies(20,"🎵")));Playlists merged=LibraryBackup.merge(original,original,"(복원)");String name=merged.entries().get(1).name;assertFalse(name.contains("\uFFFD"));assertEquals(name,new String(name.getBytes(StandardCharsets.UTF_8),StandardCharsets.UTF_8));assertTrue(name.length()<=40);}
 @Test public void detectsCorruptedAndTruncatedBackups()throws Exception{byte[] valid=LibraryBackup.encode(sample());String text=new String(valid,StandardCharsets.UTF_8);expectInvalid(text.replace("sha256=","sha256=bad").getBytes(StandardCharsets.UTF_8));expectInvalid(Arrays.copyOf(valid,valid.length/2));expectInvalid("not a backup".getBytes(StandardCharsets.UTF_8));}
 @Test public void rejectsFutureVersion()throws Exception{String text=new String(LibraryBackup.encode(sample()),StandardCharsets.UTF_8);expectInvalid(text.replace("singkeyBackupVersion=1","singkeyBackupVersion=2").getBytes(StandardCharsets.UTF_8));}
 @Test public void notebookRoundTripIsSeparateFromSavedKeys()throws Exception {
  SongNotes notes=new SongNotes();notes.put(new Song("https://youtu.be/dQw4w9WgXcQ","곡"),2,SongNotes.Rating.COMFORTABLE,"후렴 🎵",SongNotes.Stage.CONFIDENT,1000);
  LibraryBackup.Data restored=LibraryBackup.readData(new ByteArrayInputStream(LibraryBackup.encode(sample(),notes)));
  assertEquals(-5,restored.lists.entries().get(0).songs.entries().get(0).key);assertEquals(2,restored.notes.find("https://youtu.be/dQw4w9WgXcQ").ratingKey);assertEquals("후렴 🎵",restored.notes.entries().get(0).note);
 }
 @Test public void olderBackupContainsNoInventedNotes()throws Exception {
  LibraryBackup.Data restored=LibraryBackup.readData(new ByteArrayInputStream(LibraryBackup.encode(sample())));
  assertEquals(2,LibraryBackup.songs(restored.lists));assertTrue(restored.notes.entries().isEmpty());
  SongNotes notes=new SongNotes();notes.put(new Song("https://youtu.be/dQw4w9WgXcQ","곡"),null,null,"keep",SongNotes.Stage.NONE,1000);
  assertEquals("keep",SongNotes.merge(notes,restored.notes).entries().get(0).note);
 }
 @Test public void notesOnlyBackupCanBeRead()throws Exception {
  SongNotes notes=new SongNotes();notes.put(new Song("https://youtu.be/dQw4w9WgXcQ","곡"),null,null,"memo",SongNotes.Stage.PRACTICING,1000);
  LibraryBackup.Data restored=LibraryBackup.readData(new ByteArrayInputStream(LibraryBackup.encode(new Playlists(),notes)));
  assertTrue(restored.lists.entries().isEmpty());assertEquals(1,restored.notes.entries().size());
 }
 @Test public void checksumCoversNotebookToo()throws Exception {
  SongNotes notes=new SongNotes();notes.put(new Song("https://youtu.be/dQw4w9WgXcQ","song"),null,null,"ORIGINAL",SongNotes.Stage.NONE,1000);
  String encoded=new String(LibraryBackup.encode(sample(),notes),StandardCharsets.UTF_8);assertTrue(encoded.contains("ORIGINAL"));expectInvalid(encoded.replace("ORIGINAL","CHANGED").getBytes(StandardCharsets.UTF_8));
 }
 @Test public void boundsUnknownInputWithoutReadingEverything()throws Exception{InputStream huge=new InputStream(){int read;@Override public int read(){read++;return 'x';}@Override public int read(byte[] bytes,int off,int len){Arrays.fill(bytes,off,off+len,(byte)'x');read+=len;assertTrue(read<=LibraryBackup.MAX_BYTES+8192);return len;}};try{LibraryBackup.read(huge);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("large"));}}
 @Test public void exportRejectsUntrustedVideoAndThumbnailTargets()throws Exception{for(String url:new String[]{"https://example.com/watch?v=dQw4w9WgXcQ","http://youtube.com/watch?v=dQw4w9WgXcQ","https://youtube.com@localhost/watch?v=dQw4w9WgXcQ","https://youtube.com:8080/watch?v=dQw4w9WgXcQ"}){Playlists value=new Playlists();value.create("test").songs.save(new Song(url,"bad"),0);try{LibraryBackup.encode(value);fail(url);}catch(IOException expected){}}Playlists value=new Playlists();value.create("test").songs.save(new Song("https://youtu.be/dQw4w9WgXcQ","bad","https://localhost/private"),0);try{LibraryBackup.encode(value);fail();}catch(IOException expected){}}
 private void expectInvalid(byte[] bytes)throws Exception{try{LibraryBackup.read(new ByteArrayInputStream(bytes));fail("Accepted invalid backup");}catch(IOException expected){}}
}
