package kr.keymate.app;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;
import java.io.IOException;

public class PlaylistsTest {
 private Song song(String id) { return new Song("https://www.youtube.com/watch?v="+id,"한글 제목 🎵 "+id,"https://example.com/thumb.jpg"); }
 @Test public void migratesLegacySongsWithoutLosingKeysOrOrder() throws Exception {
  SavedSongs legacy = new SavedSongs(); legacy.save(song("abcdefghijk"),-2); legacy.save(song("zyxwvutsrqp"),1);
  Playlists migrated = Playlists.restore(null,legacy.encode());
  assertEquals("내 곡",migrated.entries().get(0).name);
  List<SavedSongs.Entry> entries = migrated.entries().get(0).songs.entries();
  assertEquals(2,entries.size()); assertEquals(1,entries.get(0).key); assertEquals(-2,entries.get(1).key);
  Playlists restored = Playlists.restore(migrated.encode(),"broken legacy ignored");
  assertEquals(entries.get(1).song.title,restored.entries().get(0).songs.entries().get(1).song.title);
 }
 @Test public void sameVideoCanHaveDifferentKeysInDifferentLists() throws Exception {
  Playlists lists = new Playlists();
  Playlists.ListEntry first=lists.create("연습"), second=lists.create("찬양");
  first.songs.saveInOrder(song("abcdefghijk"),-2); second.songs.saveInOrder(song("abcdefghijk"),1);
  Playlists restored=Playlists.restore(lists.encode(),null);
  assertEquals(-2,restored.entries().get(0).songs.entries().get(0).key);
  assertEquals(1,restored.entries().get(1).songs.entries().get(0).key);
 }
 @Test public void updatesPreserveOrderAndPlaybackUsesKeySnapshot() {
  Playlists lists=new Playlists(); Playlists.ListEntry list=lists.create("연습");
  list.songs.saveInOrder(song("abcdefghijk"),-2); list.songs.saveInOrder(song("zyxwvutsrqp"),1); list.songs.saveInOrder(song("12345678901"),0);
  List<SavedSongs.Entry> playing=lists.playback(list,0);
  list.songs.saveInOrder(new Song("https://youtu.be/abcdefghijk?t=30","updated"),3);
  assertEquals(3,list.songs.entries().size()); assertEquals(3,list.songs.entries().get(0).key);
  assertEquals(-2,playing.remove(0).key); assertEquals(1,playing.remove(0).key); assertEquals(0,playing.remove(0).key);
  assertEquals(1,lists.playback(list,1).get(0).key);
  list.songs.remove("https://youtu.be/zyxwvutsrqp"); assertEquals(2,list.songs.entries().size());
 }
 @Test public void validatesNamesAndPersistsEmptyLists() throws Exception {
  Playlists lists=new Playlists(); lists.create(" 연습 ");
  for (String name:new String[]{"", "  ", "연습", "x".repeat(41)}) {
   try { lists.create(name); fail("Accepted invalid name"); } catch (IllegalArgumentException expected) { }
  }
  assertTrue(Playlists.restore(lists.encode(),null).entries().get(0).songs.entries().isEmpty());
 }
 @Test public void savedStateTracksVideoAndCurrentKeyAcrossListsAndRestores() throws Exception {
  Playlists lists=new Playlists();
  Playlists.ListEntry first=lists.create("연습"), second=lists.create("다른 키");
  String url="https://youtu.be/abcdefghijk?t=30";
  assertFalse(lists.contains(url,0));
  first.songs.saveInOrder(song("abcdefghijk"),-2);
  second.songs.saveInOrder(song("abcdefghijk"),1);
  assertTrue(lists.contains(url,-2));assertTrue(lists.contains(url,1));assertFalse(lists.contains(url,0));
  assertFalse(lists.contains(song("zyxwvutsrqp").url,-2));
  Playlists restored=Playlists.restore(lists.encode(),null);
  assertTrue(restored.contains(url,-2));assertTrue(restored.contains(url,1));
  first.songs.saveInOrder(song("abcdefghijk"),0);
  assertFalse(lists.contains(url,-2));assertTrue(lists.contains(url,0));
  first.songs.remove(url);assertFalse(lists.contains(url,0));assertTrue(lists.contains(url,1));
 }
 @Test public void corruptNewFormatDoesNotSilentlyReimportLegacy() throws Exception {
  for (String data:new String[]{"", "version=9\ncount=0", "version=1\ncount=1", "version=1\ncount=-1"}) {
   try { Playlists.restore(data,""); fail("Accepted corrupt data"); } catch (IOException expected) { }
  }
 }
}
