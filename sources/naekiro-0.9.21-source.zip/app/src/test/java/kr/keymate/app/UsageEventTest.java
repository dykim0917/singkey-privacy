package kr.keymate.app;
import org.junit.Test;
import static org.junit.Assert.*;
public class UsageEventTest {
 @Test public void untrustedScreenCannotLeakSearchOrUrl(){UsageEvent event=UsageEvent.screen("https://youtube.com/watch?v=private-query",true);assertEquals("other",event.parameters.get("screen_name"));assertFalse(event.parameters.toString().contains("youtube"));}
 @Test public void clampsNumbersAndMapsFailures(){assertEquals(100L,UsageEvent.results(900,false).parameters.get("result_count"));assertEquals("error",UsageEvent.results(0,true).parameters.get("outcome"));assertEquals(-12L,UsageEvent.key(-99,99).parameters.get("from_semitones"));assertEquals(14400L,UsageEvent.practice(Long.MAX_VALUE).parameters.get("seconds"));}
 @Test public void fixedEventSchemasContainNoContentFields(){UsageEvent[] events={UsageEvent.search(true,false),UsageEvent.results(5,false),UsageEvent.saved(-2),UsageEvent.started(true,-2),UsageEvent.failure(true),UsageEvent.ad("secret-title",true)};for(UsageEvent event:events){assertFalse(event.parameters.containsKey("query"));assertFalse(event.parameters.containsKey("url"));assertFalse(event.parameters.containsKey("title"));assertFalse(event.parameters.toString().contains("secret-title"));}}
}
