package kr.keymate.app;

import java.util.Locale;
import org.junit.Test;
import static org.junit.Assert.*;

public class AppLanguageTest {
 @Test public void matchesLanguageAcrossRegions() {
  assertEquals(AppLanguage.KO,AppLanguage.from(Locale.KOREA));
  assertEquals(AppLanguage.KO,AppLanguage.from(Locale.forLanguageTag("ko-US")));
  assertEquals(AppLanguage.JA,AppLanguage.from(Locale.JAPAN));
  assertEquals(AppLanguage.EN,AppLanguage.from(Locale.UK));
 }
 @Test public void unsupportedAndMissingLanguagesFallBackToEnglish() {
  for(Locale locale:new Locale[]{Locale.FRANCE,Locale.CHINA,Locale.ROOT,null})
   assertEquals(AppLanguage.EN,AppLanguage.from(locale));
 }
}
