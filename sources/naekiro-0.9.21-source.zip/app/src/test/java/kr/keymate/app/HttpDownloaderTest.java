package kr.keymate.app;

import java.io.IOException;
import okhttp3.MediaType;
import okhttp3.ResponseBody;
import okio.Buffer;
import okio.BufferedSource;
import org.junit.Test;
import static org.junit.Assert.*;

public class HttpDownloaderTest {
 @Test public void decodesUtf8AndBomWithoutCorruptingSearchResults() throws Exception {
  try(ResponseBody body=ResponseBody.create("아이유 米津玄師 Adele",MediaType.get("text/plain; charset=utf-8"))){
   assertEquals("아이유 米津玄師 Adele",HttpDownloader.boundedBody(body));
  }
  Buffer data=new Buffer().write(new byte[]{(byte)0xff,(byte)0xfe}).write("아이유".getBytes(java.nio.charset.StandardCharsets.UTF_16LE));
  try(ResponseBody body=ResponseBody.create(data,MediaType.get("text/plain"),data.size())){
   assertEquals("아이유",HttpDownloader.boundedBody(body));
  }
 }
 @Test public void rejectsDeclaredOversizeBeforeReading() {
  try(ResponseBody body=new ResponseBody(){
   public MediaType contentType(){return null;}
   public long contentLength(){return HttpDownloader.MAX_BODY_BYTES+1L;}
   public BufferedSource source(){throw new AssertionError("Must not read oversized response");}
   public void close(){}
  }){assertThrows(IOException.class,()->HttpDownloader.boundedBody(body));}
 }
 @Test public void boundsUnknownLengthStreamsBeforeReadingToEnd() {
  final long[] count={0};
  okio.Source infinite=new okio.Source(){
   public long read(Buffer sink,long bytes){int length=(int)Math.min(bytes,8192);sink.write(new byte[length]);count[0]+=length;return length;}
   public okio.Timeout timeout(){return okio.Timeout.NONE;}
   public void close(){}
  };
  try(ResponseBody body=ResponseBody.create(okio.Okio.buffer(infinite),null,-1)){
   assertThrows(IOException.class,()->HttpDownloader.boundedBody(body));
   assertTrue(count[0]<=HttpDownloader.MAX_BODY_BYTES+8192L);
  }
 }
 @Test public void acceptsExactLimitAndRejectsOneByteOver() throws Exception {
  for(int extra:new int[]{0,1}){
   Buffer data=new Buffer().write(new byte[HttpDownloader.MAX_BODY_BYTES+extra]);
   try(ResponseBody body=ResponseBody.create(data,null,-1)){
    if(extra==0)assertEquals(HttpDownloader.MAX_BODY_BYTES,HttpDownloader.boundedBody(body).length());
    else assertThrows(IOException.class,()->HttpDownloader.boundedBody(body));
   }
  }
 }
}
