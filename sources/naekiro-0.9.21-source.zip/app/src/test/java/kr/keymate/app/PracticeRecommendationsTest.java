package kr.keymate.app;
import java.util.*;
import java.io.*;
import org.junit.Test;
import static org.junit.Assert.*;
public class PracticeRecommendationsTest {
 private final long now=1800000000000L;
 private Song song(int n){return new Song("https://www.youtube.com/watch?v="+String.format(Locale.ROOT,"%011d",n),"Song "+n);}
 private Playlists library(int count){Playlists p=new Playlists();Playlists.ListEntry list=p.create("My list");for(int n=1;n<=count;n++)list.songs.saveInOrder(song(n),n);return p;}
 private RecentSongs history(int n,long time)throws Exception{SavedSongs songs=new SavedSongs();songs.save(song(n),-7);Properties p=new Properties();p.setProperty("historyVersion","1");p.setProperty("songs",songs.encode());p.setProperty(song(n).url,""+time);StringWriter out=new StringWriter();p.store(out,"");return RecentSongs.decode(out.toString());}
 @Test public void selectsOnePerReasonBeforeFillingAndNeverChangesSavedKeys()throws Exception{
  Playlists library=library(5);library.create("Duplicate").songs.save(song(1),-8);SongNotes notes=new SongNotes();notes.put(song(1),-2,SongNotes.Rating.COMFORTABLE,"",SongNotes.Stage.NONE,now-1);notes.put(song(2),-3,SongNotes.Rating.COMFORTABLE,"",SongNotes.Stage.NONE,now-1);
  List<PracticeRecommendations.Pick> picks=new PracticeRecommendations().update(library,notes,history(3,now-PracticeRecommendations.FORTNIGHT),true,now);
  assertEquals(Arrays.asList(1,3,4),Arrays.asList(picks.get(0).saved.key,picks.get(1).saved.key,picks.get(2).saved.key));assertEquals(-2,picks.get(0).rating.ratingKey);assertEquals(PracticeRecommendations.Reason.LONG_AGO,picks.get(1).reason);assertEquals(1,library.entries().get(0).songs.find(song(1).url).key);
 }
 @Test public void missingOffDeletedFutureAndEvictedHistoryCannotClaimLongAgo()throws Exception{
  Playlists library=library(1);SongNotes notes=new SongNotes();RecentSongs recent=history(1,now-PracticeRecommendations.FORTNIGHT);PracticeRecommendations model=new PracticeRecommendations();
  assertEquals(PracticeRecommendations.Reason.SAVED,model.update(library,notes,recent,false,now).get(0).reason);
  recent.remove(song(1).url);assertEquals(PracticeRecommendations.Reason.SAVED,model.update(library,notes,recent,true,now).get(0).reason);
  assertEquals(PracticeRecommendations.Reason.SAVED,model.update(library,notes,history(1,now+1),true,now).get(0).reason);
  recent=history(1,now-PracticeRecommendations.FORTNIGHT);for(int n=2;n<23;n++)recent.record(song(n),0);assertEquals(0,recent.playedAt(song(1).url));assertEquals(PracticeRecommendations.Reason.SAVED,model.update(library,notes,recent,true,now).get(0).reason);
 }
 @Test public void stableUntilFactsChangeAndOtherOnlyShowsUnseenCandidates(){
  Playlists library=library(5);SongNotes notes=new SongNotes();RecentSongs recent=new RecentSongs();PracticeRecommendations model=new PracticeRecommendations();model.update(library,notes,recent,true,now);List<String> first=model.selection();model.update(library,notes,recent,true,now+1000);assertEquals(first,model.selection());assertTrue(model.hasOther());assertEquals(2,model.other().size());assertFalse(model.hasOther());for(String id:model.selection())assertFalse(first.contains(id));
  PracticeRecommendations rotated=new PracticeRecommendations();rotated.restore(model.selection(),model.seen());rotated.update(library,notes,recent,true,now);assertEquals(model.selection(),rotated.selection());assertFalse(rotated.hasOther());
  library.entries().get(0).songs.remove(song(4).url);assertEquals(3,rotated.update(library,notes,recent,true,now).size());assertFalse(rotated.selection().contains(song(4).url));
 }
 @Test public void latestRatingReplacesOldReasonAndMetadataEditKeepsRatingDate(){
  Playlists library=library(1);SongNotes notes=new SongNotes();RecentSongs recent=new RecentSongs();PracticeRecommendations model=new PracticeRecommendations();notes.put(song(1),-2,SongNotes.Rating.COMFORTABLE,"",SongNotes.Stage.NONE,now-100);
  assertEquals(PracticeRecommendations.Reason.COMFORTABLE,model.update(library,notes,recent,true,now).get(0).reason);notes.put(song(1),null,null,"note",SongNotes.Stage.PRACTICING,now-10);assertEquals(now-100,model.update(library,notes,recent,true,now).get(0).rating.ratedAt);
  notes.put(song(1),3,SongNotes.Rating.HIGH,"",SongNotes.Stage.NONE,now);assertEquals(PracticeRecommendations.Reason.SAVED,model.update(library,notes,recent,true,now).get(0).reason);notes.remove(song(1).url);assertNull(model.update(library,notes,recent,true,now).get(0).rating);
 }
 @Test public void zeroOneTwoCandidatesDoNotInventFillers(){for(int count=0;count<3;count++){PracticeRecommendations model=new PracticeRecommendations();assertEquals(count,model.update(library(count),new SongNotes(),new RecentSongs(),true,now).size());assertFalse(model.hasOther());}}
}
