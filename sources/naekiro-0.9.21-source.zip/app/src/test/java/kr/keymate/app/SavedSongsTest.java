package kr.keymate.app;

import org.junit.Test;

public final class SavedSongsTest {
 @Test public void roundTrip() throws Exception { SavedSongsChecks.roundTrip(); }
 @Test public void updatesSameVideoAcrossUrlForms() { SavedSongsChecks.updateAndIdentity(); }
 @Test public void deletionSurvivesReload() throws Exception { SavedSongsChecks.deleteAndEmpty(); }
 @Test public void snapshotsAndKeyLimits() { SavedSongsChecks.snapshotsAndLimits(); }
 @Test public void rejectsCorruptData() throws Exception { SavedSongsChecks.corruptData(); }
 @Test public void keepsDifferentSourcesSeparate() { SavedSongsChecks.distinctSources(); }
}
