package kr.keymate.app;

import org.junit.Test;
import java.io.*;
import java.util.*;
import static org.junit.Assert.*;

public class EmbedAvailabilityTest {
 static final String A="QssOhIB5_g4", B="BPr-NdAkmgY", C="M7lc1UVf-VE";
 static Song song(String id){return new Song("https://www.youtube.com/watch?v="+id,"Song · TJ Karaoke","");}
 static YouTubeSearchPage.Page page(String...ids){List<Song> songs=new ArrayList<>();for(String id:ids)songs.add(song(id));return new YouTubeSearchPage.Page(songs,null);}
 @Test public void remembersOnlyExplicitEmbeddingErrorsAndExpires()throws Exception{
  long[] now={1000};String[] saved={null};
  EmbedAvailability cache=new EmbedAvailability(ids->Map.of(),()->now[0],null,value->saved[0]=value);
  for(int code:new int[]{2,5,100,153,0}){cache.failed(song(A).url,new YouTubePlaybackException(code));assertFalse(cache.blocked(song(A).url));}
  cache.failed(song(A).url,new IOException("network"));assertFalse(cache.blocked(song(A).url));
  cache.failed(song(A).url,new YouTubePlaybackException(101));cache.failed(song(B).url,new YouTubePlaybackException(150));
  assertEquals(List.of(C),ids(cache.filter(page(A,B,C))));
  EmbedAvailability restored=new EmbedAvailability(ids->Map.of(),()->now[0],saved[0],v->{});
  assertTrue(restored.blocked(song(A).url));assertFalse(restored.blocked(song(C).url));
  now[0]+=EmbedAvailability.BLOCK_TTL;assertFalse(restored.blocked(song(A).url));
 }
 @Test public void ignoresCorruptAndFutureCacheAndClearsAfterActualPlayback(){
  EmbedAvailability cache=new EmbedAvailability(ids->Map.of(),()->1000,"{\""+A+"\":9999999999999}",v->{});
  assertFalse(cache.blocked(song(A).url));cache.failed(song(A).url,new YouTubePlaybackException(150));cache.played(song(A).url);assertFalse(cache.blocked(song(A).url));
  assertFalse(new EmbedAvailability(ids->Map.of(),()->1000,"garbage",v->{}).blocked(song(A).url));
 }
 @Test public void batchDenialsKeepUnknownAndSameChannelVideos()throws Exception{
  int[] requests={0};long[] now={1000};
  EmbedAvailability cache=new EmbedAvailability(ids->{requests[0]++;return Map.of(A,false,B,true);},()->now[0],null,v->{});
  assertEquals(List.of(B,C),ids(cache.filter(page(A,B,C))));
  cache.filter(page(A,B));assertEquals(1,requests[0]);
  now[0]+=EmbedAvailability.ALLOW_TTL;cache.filter(page(A,B));assertEquals(2,requests[0]);
 }
 @Test public void allowedMetadataCannotEraseRuntimeBlockArrivingDuringRequest()throws Exception{
  EmbedAvailability[] cache={null};
  cache[0]=new EmbedAvailability(ids->{cache[0].failed(song(A).url,new YouTubePlaybackException(150));return Map.of(A,true);},()->1000,null,v->{});
  assertTrue(cache[0].filter(page(A)).songs.isEmpty());
 }
 @Test public void networkOrQuotaFailureDoesNotHideUnknownVideosAndBacksOff()throws Exception{
  int[] calls={0};long[] now={1000};
  EmbedAvailability cache=new EmbedAvailability(ids->{calls[0]++;throw new IOException("quota");},()->now[0],null,v->{});
  cache.failed(song(A).url,new YouTubePlaybackException(101));
  assertEquals(List.of(B),ids(cache.filter(page(A,B))));cache.filter(page(B));assertEquals(1,calls[0]);
  now[0]+=60000;cache.filter(page(B));assertEquals(2,calls[0]);
 }
 @Test public void interruptionDoesNotBecomeRestrictionOrTriggerFurtherWork()throws Exception{
  EmbedAvailability cache=new EmbedAvailability(ids->{throw new AssertionError();},()->1000,null,v->{});
  Thread.currentThread().interrupt();try{assertThrows(InterruptedIOException.class,()->cache.filter(page(A)));}finally{Thread.interrupted();}
  assertFalse(cache.blocked(song(A).url));
 }
 @Test public void boundsStoredDenialsAndRetainsRecentOnes()throws Exception{
  String[] saved={null};EmbedAvailability cache=new EmbedAvailability(ids->Map.of(),()->1000,null,v->saved[0]=v);
  for(int i=0;i<510;i++)cache.failed(song(String.format(Locale.ROOT,"%011d",i)).url,new YouTubePlaybackException(150));
  assertFalse(cache.blocked(song("00000000000").url));assertTrue(cache.blocked(song("00000000509").url));
  assertTrue(saved[0].length()<32768);
 }
 static List<String> ids(YouTubeSearchPage.Page page){List<String> result=new ArrayList<>();for(Song song:page.songs)result.add(EmbedAvailability.id(song.url));return result;}
}
