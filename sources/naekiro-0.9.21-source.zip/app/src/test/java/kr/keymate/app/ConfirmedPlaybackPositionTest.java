package kr.keymate.app;
import org.junit.Test;
import static org.junit.Assert.*;
public class ConfirmedPlaybackPositionTest {
 @Test public void unknownAndAdsCannotOverwriteConfirmedContent(){ConfirmedPlaybackPosition position=new ConfirmedPlaybackPosition();position.reset(45000);position.observe(2,false);assertEquals(45000,position.value());position.ad(false);position.observe(48,false);assertEquals(48000,position.value());position.ad(true);position.observe(3,false);assertEquals(48000,position.value());position.ad(false);position.observe(5,true);assertEquals(48000,position.value());position.observe(50,false);assertEquals(50000,position.value());}
 @Test public void invalidValuesAndNewLoadsCannotReuseOldAdState(){ConfirmedPlaybackPosition p=new ConfirmedPlaybackPosition();p.reset(10000);p.ad(false);for(double bad:new double[]{Double.NaN,Double.POSITIVE_INFINITY,-1,86401})p.observe(bad,false);assertEquals(10000,p.value());p.reset(5000);p.observe(99,false);assertEquals(5000,p.value());p.ad(false);p.observe(4,false);assertEquals(4000,p.value());}
}
