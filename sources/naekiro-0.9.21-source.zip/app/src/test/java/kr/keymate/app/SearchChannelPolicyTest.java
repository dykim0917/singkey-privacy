package kr.keymate.app;

import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;

public class SearchChannelPolicyTest {
 private String video(String id,String title,String field,String channelId){
  return "{\"videoRenderer\":{\"videoId\":\""+id+"\",\"title\":{\"simpleText\":\""+title+"\"},\""+field+"\":{\"runs\":[{\"text\":\"TJ Karaoke\",\"navigationEndpoint\":{\"browseEndpoint\":{\"browseId\":\""+channelId+"\"}}}]}}}";
 }
 private String mixed(){return video("QssOhIB5_g4","Renamed channel upload","ownerText",SearchChannelPolicy.TJ)+","+video("M7lc1UVf-VE","[TJ노래방] fan cover","ownerText","UC_x5XG1OV2P6uZZ5FSM9Ttw")+","+video("BPr-NdAkmgY","Unknown uploader","ownerText","");}
 @Test public void filtersFirstPageByExactChannelIdentityNotTitleOrDisplayName()throws Exception{
  YouTubeSearchPage.Page page=YouTubeSearchPage.first("var ytInitialData = {\"contents\":["+mixed()+"]};",AppLanguage.KO);
  assertEquals(List.of("M7lc1UVf-VE","BPr-NdAkmgY"),EmbedAvailabilityTest.ids(page));assertEquals(1,page.excluded);
  assertFalse(SearchChannelPolicy.excluded(null));assertFalse(SearchChannelPolicy.excluded(SearchChannelPolicy.TJ+"x"));
 }
 @Test public void samePolicyAppliesToContinuationAndAlternativeOwnerFields()throws Exception{
  for(String field:List.of("ownerText","longBylineText","shortBylineText")){
   String json="{\"onResponseReceivedCommands\":[{\"appendContinuationItemsAction\":{\"continuationItems\":["+video("QssOhIB5_g4","Upload",field,SearchChannelPolicy.TJ)+","+mixed()+"]}}]}";
   YouTubeSearchPage.Page page=YouTubeSearchPage.next(json,new YouTubeSearchPage.Cursor("next","1.0",AppLanguage.KO));
   assertEquals(List.of("M7lc1UVf-VE","BPr-NdAkmgY"),EmbedAvailabilityTest.ids(page));assertEquals(1,page.excluded);
  }
 }
 @Test public void allTjPageKeepsCursorAndFindsOtherChannelWithoutStatusApi()throws Exception{
  String command="{\"continuationItemRenderer\":{\"continuationEndpoint\":{\"commandMetadata\":{\"webCommandMetadata\":{\"apiUrl\":\"/youtubei/v1/search\"}},\"continuationCommand\":{\"token\":\"next\"}}}}";
  String html="var ytInitialData = {\"contents\":{\"twoColumnSearchResultsRenderer\":{\"primaryContents\":{\"sectionListRenderer\":{\"contents\":["+video("QssOhIB5_g4","Upload","ownerText",SearchChannelPolicy.TJ)+","+command+"]}}}}};\"INNERTUBE_CLIENT_VERSION\":\"1.0\"";
  YouTubeSearchPage.Page first=YouTubeSearchPage.first(html,AppLanguage.KO);assertTrue(first.songs.isEmpty());assertNotNull(first.next);
  EmbedAvailability cache=new EmbedAvailability(ids->{throw new java.io.IOException("offline status API");},()->1000,null,value->{});
  YouTubeSearchPage.Page result=PlayableSearch.filter(first,cache,cursor->YouTubeSearchPage.next("{\"onResponseReceivedCommands\":[{\"appendContinuationItemsAction\":{\"continuationItems\":["+mixed()+"]}}]}",cursor));
  assertEquals(List.of("M7lc1UVf-VE","BPr-NdAkmgY"),EmbedAvailabilityTest.ids(result));assertEquals(2,result.excluded);
 }
 @Test public void liveSearchFiltersTjAcrossTwoQueriesAndTheirNextPages()throws Exception{
  Assume.assumeTrue("1".equals(System.getenv("KEYMATE_LIVE_TEST")));
  int excluded=0,remaining=0;
  for(String query:List.of("서지원 내 눈물 모아","이브 너 그럴때면")){
   YouTubeSearchPage.Page page=SongSearch.first(query,AppLanguage.KO,true);
   for(int index=0;index<2;index++){
    excluded+=page.excluded;remaining+=page.songs.size();
    assertTrue(page.songs.stream().noneMatch(song->song.title.endsWith(" · TJ노래방 공식 유튜브채널")));
    System.out.println("TJ_FILTER query="+query+" page="+(index+1)+" excluded="+page.excluded+" remaining="+page.songs.size());
    if(page.next==null)break;page=SongSearch.more(page.next);
   }
  }
  assertTrue("Expected official TJ search samples",excluded>0);assertTrue("Other channels must remain",remaining>0);
 }
}
