package kr.keymate.app;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.Test;
import org.junit.Assume;
import static org.junit.Assert.*;

public class SearchSuggestionsTest {
 @Test public void acceptsWordsButSkipsLinksAndUnfinishedHangulConsonants() {
  for(String input:Arrays.asList("아","아이유"," Adele ","2002"))assertTrue(input,SearchSuggestions.eligible(input));
  for(String input:Arrays.asList(""," ","ㅇ","https://youtu.be/abc","www.youtube.com/watch?v=x","youtu.be/abc","x".repeat(121)))assertFalse(input,SearchSuggestions.eligible(input));
 }
 @Test public void suggestionsAreBoundedDeduplicatedAndNeverLinks() {
  assertEquals(Arrays.asList("Adele","adele hello","아이유","밤편지","노래방"),SearchSuggestions.clean(Arrays.asList(null,"  "," Adele ","ADELE","https://youtu.be/x","adele  hello","아이유","밤편지","노래방","extra")));
 }
 @Test public void debounceOnlyFetchesTheLatestInput() throws Exception {
  List<String> fetched=new CopyOnWriteArrayList<>();BlockingQueue<List<String>> received=new LinkedBlockingQueue<>();
  try(SearchSuggestions source=new SearchSuggestions(q->{fetched.add(q);return Collections.singletonList(q);},100)) {
   SearchSuggestions.Session session=source.session(Runnable::run,received::add);
   session.request("a");session.request("ad");session.request("adele");
   assertEquals(Collections.singletonList("adele"),received.poll(5,TimeUnit.SECONDS));
   assertEquals(Collections.singletonList("adele"),fetched);
  }
 }
 @Test public void lateOldResponseCannotReplaceNewSuggestions() throws Exception {
  CountDownLatch oldStarted=new CountDownLatch(1),releaseOld=new CountDownLatch(1);
  BlockingQueue<Runnable> delivery=new LinkedBlockingQueue<>();List<List<String>> received=new ArrayList<>();
  try(SearchSuggestions source=new SearchSuggestions(q->{
   if(q.equals("old")){oldStarted.countDown();boolean released=false;while(!released){try{releaseOld.await();released=true;}catch(InterruptedException ignored){}}}
   return Collections.singletonList(q);
  },0)) {
   SearchSuggestions.Session session=source.session(delivery::add,received::add);
   session.request("old");assertTrue(oldStarted.await(5,TimeUnit.SECONDS));session.request("new");
   take(delivery).run();releaseOld.countDown();take(delivery).run();
   assertEquals(Collections.singletonList(Collections.singletonList("new")),received);
  }finally{releaseOld.countDown();}
 }
 @Test public void dismissOrClosePreventsAlreadyQueuedDelivery() throws Exception {
  BlockingQueue<Runnable> delivery=new LinkedBlockingQueue<>();List<List<String>> received=new ArrayList<>();
  try(SearchSuggestions source=new SearchSuggestions(q->Collections.singletonList(q),0)) {
   SearchSuggestions.Session session=source.session(delivery::add,received::add);
   session.request("adele");Runnable result=take(delivery);session.cancel();result.run();assertTrue(received.isEmpty());
   session.request("아이유");result=take(delivery);source.close();result.run();assertTrue(received.isEmpty());
  }
 }
 @Test public void cachesSuccessfulQueriesAndRecoversAfterNetworkFailure() throws Exception {
  AtomicInteger requests=new AtomicInteger();BlockingQueue<List<String>> received=new LinkedBlockingQueue<>();
  try(SearchSuggestions source=new SearchSuggestions(q->{if(requests.incrementAndGet()==1)throw new java.io.IOException("offline");return Collections.singletonList(q);},0)) {
   SearchSuggestions.Session session=source.session(Runnable::run,received::add);
   session.request("아이유");assertEquals(Collections.emptyList(),received.poll(5,TimeUnit.SECONDS));
   session.request("아이유");assertEquals(Collections.singletonList("아이유"),received.poll(5,TimeUnit.SECONDS));
   session.request("아이유");assertEquals(Collections.singletonList("아이유"),received.poll(5,TimeUnit.SECONDS));assertEquals(2,requests.get());
  }
 }
 @Test public void liveKoreanYouTubeSuggestions() throws Exception {
  Assume.assumeTrue("1".equals(System.getenv("KEYMATE_SUGGEST_TEST")));
  BlockingQueue<List<String>> received=new LinkedBlockingQueue<>();
  try(SearchSuggestions source=new SearchSuggestions()) {
   source.session(Runnable::run,received::add).request("아이유");
   List<String> result=received.poll(10,TimeUnit.SECONDS);assertNotNull(result);assertFalse(result.isEmpty());assertTrue(result.size()<=5);
   System.out.println("Korean suggestions: "+result);
  }
 }
 private static Runnable take(BlockingQueue<Runnable> queue) throws Exception {Runnable value=queue.poll(5,TimeUnit.SECONDS);assertNotNull("Expected callback",value);return value;}
}
