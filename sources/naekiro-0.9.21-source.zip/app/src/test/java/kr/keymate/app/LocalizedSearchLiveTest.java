package kr.keymate.app;

import java.util.*;
import org.junit.Test;
import org.junit.Assume;
import static org.junit.Assert.*;

/** Opt-in live observations; rankings can change and are never hard-coded. */
public class LocalizedSearchLiveTest {
 @Test public void searchAndSuggestionsInThreeLanguages() throws Exception {
  Assume.assumeTrue("1".equals(System.getenv("KEYMATE_I18N_TEST")));
  String[] queries={"Adele Someone Like You","아이유 밤편지","米津玄師 Lemon"};
  int index=0;
  for(AppLanguage lang:AppLanguage.values()) {
   String query=queries[index++];
   java.util.concurrent.BlockingQueue<List<String>> suggestions=new java.util.concurrent.LinkedBlockingQueue<>();
   try(SearchSuggestions source=new SearchSuggestions(lang)) {
    source.session(Runnable::run,suggestions::add).request(query.split(" ")[0]);
    List<String> result=suggestions.poll(12,java.util.concurrent.TimeUnit.SECONDS);
    assertNotNull("Suggestions "+lang,result);assertFalse("Suggestions "+lang,result.isEmpty());
    System.out.println("SUGGEST\t"+lang+"\t"+result);
   }
   for(boolean backing:new boolean[]{true,false}) {
    List<Song> songs=SongSearch.find(query,lang,backing);
    assertFalse(lang+" mode "+backing,songs.isEmpty());
    Set<String> urls=new HashSet<>();
    for(Song song:songs)assertTrue(urls.add(song.url)&&SongSearch.isYouTubeUrl(song.url));
    for(int i=0;i<Math.min(5,songs.size());i++)
     System.out.println("I18N\t"+lang+"\t"+backing+"\t"+(i+1)+"\t"+songs.get(i).title);
   }
  }
 }
}
