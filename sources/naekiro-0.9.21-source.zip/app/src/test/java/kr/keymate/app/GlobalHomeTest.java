package kr.keymate.app;

import com.grack.nanojson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class GlobalHomeTest {
 private static final long NOW=Instant.parse("2026-09-14T03:00:00Z").toEpochMilli();
 private String fixture() throws IOException {
  try(InputStream input=getClass().getResourceAsStream("/joysound-top10-2026-08.html")) {
   assertNotNull(input);return new String(input.readAllBytes(),StandardCharsets.UTF_8);
  }
 }
 @Test public void firstChoiceFollowsAppLanguageButSavedChoiceWins() {
  assertEquals(HomeCategory.KOREAN,HomeCategory.restore(null,AppLanguage.KO));
  assertEquals(HomeCategory.JAPANESE,HomeCategory.restore(null,AppLanguage.JA));
  assertEquals(HomeCategory.POP,HomeCategory.restore(null,AppLanguage.from(Locale.FRENCH)));
  for(AppLanguage language:AppLanguage.values())for(HomeCategory category:HomeCategory.values())
   assertEquals(category,HomeCategory.restore(category.id,language));
  assertEquals(HomeCategory.POP,HomeCategory.restore("corrupt",AppLanguage.EN));
 }
 @Test public void monthlyChartUsesPublishedPositionsAndPeriod() throws Exception {
  FeaturedSongs.Chart chart=FeaturedSongs.parseJoysound(fixture(),NOW);
  assertEquals(HomeCategory.JAPANESE,chart.category);assertEquals(10,chart.entries.size());
  assertEquals("2026.08.01 – 2026.08.31",chart.periodLabel());
  assertEquals("伯方の塩",chart.entries.get(0).title);assertEquals("塩谷信廣 伯方の塩",chart.entries.get(0).query);
  assertEquals(10,chart.entries.get(9).rank);assertEquals("爆裂愛してる",chart.entries.get(9).title);
  FeaturedSongs.Chart restored=FeaturedSongs.decode(chart.encode());
  assertEquals(HomeCategory.JAPANESE,restored.category);assertEquals(chart.entries.get(9).query,restored.entries.get(9).query);
  assertTrue(chart.isFresh(NOW));assertFalse(chart.isFresh(NOW+24*60*60*1000L));
 }
 @Test public void partialDuplicateWrongPageAndBadPeriodsAreRejected() throws Exception {
  String html=fixture();
  for(String broken:new String[]{html.replace("2026/08","2026/13"),html.replace("2026/08","2026/09"),html.replace("2026/08","2026/08/01"),
   html.replace("集計期間:","更新日:"),html.replace("all/monthly","all/weekly"),html.replace("\"position\": 10","\"position\": 1"),
   html.replace("\"position\": 10","\"position\": 11"),html.replace("MusicRecording","Thing")})
   assertThrows(IOException.class,()->FeaturedSongs.parseJoysound(broken,NOW));
 }
 @Test public void aLateResultCannotSwitchTheActiveHomeGroupAndFailureKeepsCache() throws Exception {
  HomeFeed feed=new HomeFeed(HomeCategory.JAPANESE);
  assertTrue(feed.begin(HomeCategory.JAPANESE,NOW,false));
  feed.select(HomeCategory.POP);
  FeaturedSongs.Chart chart=FeaturedSongs.parseJoysound(fixture(),NOW);
  feed.complete(HomeCategory.JAPANESE,chart);
  assertEquals(HomeCategory.POP,feed.selected());assertNull(feed.state(HomeCategory.KOREAN).chart);
  assertSame(chart,feed.state(HomeCategory.JAPANESE).chart);
  assertFalse(feed.begin(HomeCategory.POP,NOW,true));
  assertFalse(feed.begin(HomeCategory.JAPANESE,NOW,false));
  assertTrue(feed.begin(HomeCategory.JAPANESE,NOW,true));
  assertFalse(feed.begin(HomeCategory.JAPANESE,NOW,true));
  feed.complete(HomeCategory.JAPANESE,null);
  assertSame(chart,feed.state(HomeCategory.JAPANESE).chart);assertTrue(feed.state(HomeCategory.JAPANESE).failed);
  assertThrows(IllegalArgumentException.class,()->feed.restore(HomeCategory.KOREAN,chart));
 }
 @Test public void failedRequestsAreThrottledPerCategoryAndRecoverable() {
  HomeFeed feed=new HomeFeed(HomeCategory.KOREAN);
  assertTrue(feed.begin(HomeCategory.KOREAN,NOW,false));feed.complete(HomeCategory.KOREAN,null);
  assertFalse(feed.begin(HomeCategory.KOREAN,NOW+100,false));
  assertTrue(feed.begin(HomeCategory.JAPANESE,NOW+100,false));
  assertTrue(feed.begin(HomeCategory.KOREAN,NOW+60_001,false));
 }
 @Test public void legacyKoreanCacheStillLoadsAndUnknownCategoriesAreRejected() throws Exception {
  FeaturedSongs.Chart jp=FeaturedSongs.parseJoysound(fixture(),NOW);
  JsonObject root=JsonParser.object().from(jp.encode());root.put("version",1);root.remove("category");
  assertEquals(HomeCategory.KOREAN,FeaturedSongs.decode(JsonWriter.string(root)).category);
  root.put("version",2);root.put("category","pop");
  assertThrows(IOException.class,()->FeaturedSongs.decode(JsonWriter.string(root)));
 }
 @Test public void recommendationsAreUnrankedAndHaveNoChartFetchOrInventedVideoUrls() {
  Set<String> queries=new HashSet<>();
  for(FeaturedSongs.Entry entry:FeaturedSongs.popRecommendations()) {
   assertEquals(0,entry.rank);assertFalse(entry.title.isEmpty());assertFalse(entry.artist.isEmpty());assertTrue(queries.add(entry.query));
   assertFalse(SongSearch.isYouTubeUrl(entry.query));
  }
  assertEquals(10,queries.size());
 }
 @Test public void homeGroupNeverOverridesTheSearchLanguageOrTheCheckbox() throws Exception {
  List<String> queries=Arrays.asList("아이유 밤편지",FeaturedSongs.parseJoysound(fixture(),NOW).entries.get(2).query,FeaturedSongs.popRecommendations().get(0).query);
  for(AppLanguage language:AppLanguage.values())for(String query:queries) {
   assertEquals(query+" "+language.backingKeyword,SongSearch.searchQuery(query,language,true));
   assertEquals(query,SongSearch.searchQuery(query,language,false));
   for(String term:Arrays.asList("노래방","カラオケ","karaoke","MR","ｶﾗｵｹ"))
    assertEquals(query+" "+term,SongSearch.searchQuery(query+" "+term,language,true));
  }
 }
}
