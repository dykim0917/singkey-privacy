package kr.keymate.app;

import org.junit.Test;
import static org.junit.Assert.*;

public class SearchSafetyTest {
 private static final String ID="Upe2ewoz1PI",CANONICAL="https://www.youtube.com/watch?v="+ID;
 @Test public void acceptsVideoVariantsAndDropsTrackingAndRedirectParameters(){
  for(String link:new String[]{"https://youtu.be/"+ID+"?si=abc&t=20", "youtube.com/watch?v="+ID,
    "https://m.youtube.com/watch?feature=share&v="+ID+"#fragment", "https://music.youtube.com/watch?v="+ID,
    "https://www.youtube.com:443/shorts/"+ID+"/", "https://youtube.com/embed/"+ID,
    "https://youtube.com/live/"+ID,"https://www.youtube.com/watch?v="+ID+"&next=https://example.org"}){
   assertTrue(link,SearchSafety.validInput(link));assertEquals(link,CANONICAL,SearchSafety.canonicalVideo(link));
   assertEquals(CANONICAL,SongSearch.searchQuery(link,AppLanguage.JA,true));
   assertFalse(SearchSuggestions.eligible(link));
  }
 }
 @Test public void rejectsSchemesHostConfusionAndNonVideoPaths(){
  for(String link:new String[]{"http://youtube.com/watch?v="+ID,"https://youtube.com.example.org/watch?v="+ID,
    "https://evil.youtube.com/watch?v="+ID,"https://youtube.com@127.0.0.1/watch?v="+ID,
    "https://user@youtube.com/watch?v="+ID,"https://youtube.com:8443/watch?v="+ID,
    "https://youtube.com/redirect?q=https://127.0.0.1","https://youtube.com/playlist?list=abc",
    "https://youtu.be/abc","https://youtube.com/watch?v="+ID+"&v="+ID,
    "https://youtu.be/"+ID+"%2fextra","https://youtube.com/watch?v="+ID+"%0a",
    "https://127.0.0.1/", "https://[::1]/", "file:///data/user/0/kr.keymate.app/shared_prefs/x.xml",
    "content://provider/private", "javascript:alert(1)", "https:", "data:text/html,test", "intent://example", "//youtube.com/watch?v="+ID}){
   assertFalse(link,SearchSafety.validInput(link));assertNull(link,SearchSafety.canonicalVideo(link));
   assertFalse(link,SearchSuggestions.eligible(link));
   assertThrows(link,IllegalArgumentException.class,()->SongSearch.findExact(link));
  }
 }
 @Test public void preservesOrdinaryTextRatherThanInterpretingCodeOrQueryParameters() throws Exception {
  for(String text:new String[]{"아이유 밤편지", "米津玄師 Lemon", "Guns N' Roses & Adele", "Adele:Hello", "Adele: Hello",
    "<script>alert(1)</script>", "x' OR '1'='1", "hello &sp=other?q=world"}){
   assertTrue(text,SearchSafety.validInput(text));assertEquals(text,SongSearch.searchQuery(text,AppLanguage.EN,false));
  }
  String input="hello &sp=other?q=world";
  String url=YouTubeSearchPage.url(input,AppLanguage.EN);
  assertTrue(url.contains("search_query=hello"));assertFalse(url.contains("&sp=other"));
 }
 @Test public void boundsInputWithoutTruncatingAnOversizedQueryIntoAnotherSearch(){
  assertTrue(SearchSafety.validInput("가".repeat(200)));assertFalse(SearchSafety.validInput("가".repeat(201)));
  assertFalse(SearchSafety.validInput(CANONICAL+"&tracking="+"a".repeat(2048)));
  assertFalse(SearchSafety.validInput("hello\nworld"));assertFalse(SearchSafety.validInput("hello\u0000world"));
  assertThrows(IllegalArgumentException.class,()->SongSearch.find("x".repeat(201)));
  assertThrows(IllegalArgumentException.class,()->SongSearch.findExact("hello\nworld"));
  assertFalse(SearchSuggestions.eligible("x".repeat(121)));
 }
 @Test public void restrictsEachNetworkPurposeAndAllowsLongSignedMediaUrls(){
  assertTrue(SearchSafety.thumbnail("https://i.ytimg.com/vi/"+ID+"/hqdefault.jpg"));
  assertTrue(SearchSafety.media("https://rr1---sn-test.googlevideo.com/videoplayback?signature="+"a".repeat(3000)));
  assertTrue(SearchSafety.extractor("https://www.youtube.com/youtubei/v1/search"));
  assertTrue(SearchSafety.extractor("https://suggestqueries-clients6.youtube.com/complete/search?q=hello"));
  for(String url:new String[]{"http://i.ytimg.com/image.jpg","https://i.ytimg.com.example.org/image.jpg",
    "https://user@i.ytimg.com/image.jpg","https://127.0.0.1/","https://[::1]/","file:///tmp/image",
    "https://i.ytimg.com:8443/image.jpg","https://googlevideo.com.example.org/video","https://notgooglevideo.com/video"}){
   assertFalse(url,SearchSafety.thumbnail(url));assertFalse(url,SearchSafety.media(url));assertFalse(url,SearchSafety.extractor(url));
  }
  assertFalse(SearchSafety.thumbnail("https://www.youtube.com/redirect"));
  assertFalse(SearchSafety.extractor("https://rr1.googlevideo.com/video"));
  assertFalse(SearchSafety.media("https://www.youtube.com/watch?v="+ID));
 }
}
