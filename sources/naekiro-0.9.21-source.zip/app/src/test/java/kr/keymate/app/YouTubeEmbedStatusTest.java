package kr.keymate.app;

import org.junit.Test;
import java.io.*;
import java.util.*;
import okhttp3.*;
import okhttp3.mockwebserver.*;
import static org.junit.Assert.*;

public class YouTubeEmbedStatusTest {
 @Test public void sendsOnlyBatchedIdsWithRestrictedAndroidIdentity()throws Exception{
  try(MockWebServer server=new MockWebServer()){
   server.enqueue(new MockResponse().setBody("{\"items\":[{\"id\":\"QssOhIB5_g4\",\"status\":{\"embeddable\":false}},{\"id\":\"M7lc1UVf-VE\",\"status\":{\"embeddable\":true}}]}"));
   YouTubeEmbedStatus api=new YouTubeEmbedStatus(new OkHttpClient(),server.url("/videos"),"test-key","test.package","ABC123");
   assertEquals(Map.of("QssOhIB5_g4",false,"M7lc1UVf-VE",true),api.check(List.of("QssOhIB5_g4","M7lc1UVf-VE")));
   RecordedRequest request=server.takeRequest();assertEquals("test-key",request.getHeader("X-Goog-Api-Key"));assertEquals("test.package",request.getHeader("X-Android-Package"));assertEquals("ABC123",request.getHeader("X-Android-Cert"));
   assertEquals("status,snippet",request.getRequestUrl().queryParameter("part"));assertEquals("items(id,status/embeddable,snippet/channelId)",request.getRequestUrl().queryParameter("fields"));assertEquals("QssOhIB5_g4,M7lc1UVf-VE",request.getRequestUrl().queryParameter("id"));assertNull(request.getRequestUrl().queryParameter("key"));assertEquals(0,request.getBodySize());
  }
 }
 @Test public void missingOrMalformedStatusRemainsUnknown()throws Exception{
  assertTrue(YouTubeEmbedStatus.parse("{\"items\":[]}",Set.of("QssOhIB5_g4")).isEmpty());
  assertTrue(YouTubeEmbedStatus.parse("{\"items\":[{\"id\":\"QssOhIB5_g4\",\"status\":{\"embeddable\":\"false\"}},{\"id\":\"M7lc1UVf-VE\",\"status\":{\"embeddable\":false}}]}",Set.of("QssOhIB5_g4")).isEmpty());
  for(String body:List.of("{}","broken","{\"error\":{},\"items\":[]}"))assertThrows(IOException.class,()->YouTubeEmbedStatus.parse(body,Set.of("QssOhIB5_g4")));
 }
 @Test public void errorAndRedirectNeverReturnDenials()throws Exception{
  try(MockWebServer server=new MockWebServer()){
   YouTubeEmbedStatus api=new YouTubeEmbedStatus(new OkHttpClient.Builder().followRedirects(false).build(),server.url("/videos"),"key","pkg","cert");
   for(int code:new int[]{403,429,500,302}){server.enqueue(new MockResponse().setResponseCode(code).setHeader("Location",server.url("/elsewhere")));assertThrows(IOException.class,()->api.check(List.of("QssOhIB5_g4")));}
   assertEquals(4,server.getRequestCount());
  }
 }
 @Test public void absentKeySkipsRequestAndLiveCheckIsExplicit()throws Exception{
  assertTrue(new YouTubeEmbedStatus("","pkg","cert").check(List.of("QssOhIB5_g4")).isEmpty());
 }
 @Test public void excludesOfficialTjEvenWhenEmbeddableOrStatusMissing()throws Exception{
  String items="{\"items\":[{\"id\":\"QssOhIB5_g4\",\"status\":{\"embeddable\":true},\"snippet\":{\"channelId\":\""+SearchChannelPolicy.TJ+"\"}},{\"id\":\"BPr-NdAkmgY\",\"snippet\":{\"channelId\":\""+SearchChannelPolicy.TJ+"\"}},{\"id\":\"M7lc1UVf-VE\",\"status\":{\"embeddable\":true},\"snippet\":{\"channelId\":\"UC_x5XG1OV2P6uZZ5FSM9Ttw\",\"channelTitle\":\"TJ Karaoke cover\"}}]}";
  assertEquals(Map.of("QssOhIB5_g4",false,"BPr-NdAkmgY",false,"M7lc1UVf-VE",true),YouTubeEmbedStatus.parse(items,Set.of("QssOhIB5_g4","BPr-NdAkmgY","M7lc1UVf-VE")));
 }
}
