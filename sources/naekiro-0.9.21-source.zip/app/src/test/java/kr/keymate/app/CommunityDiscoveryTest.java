package kr.keymate.app;

import com.grack.nanojson.*;
import java.io.IOException;
import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class CommunityDiscoveryTest {
 private static final String OWNER="00000000-0000-4000-8000-000000000001",BLOCKED="00000000-0000-4000-8000-000000000002";
 private CommunityData.ListItem item(int id,boolean curated,String owner)throws IOException{
  JsonObject j=new JsonObject();j.put("id",String.format(Locale.ROOT,"10000000-0000-4000-8000-%012d",id));j.put("owner_id",owner);
  j.put("title","Playlist "+id);j.put("nickname","Singer");j.put("curated",curated);j.put("likes",0);
  JsonArray songs=new JsonArray();songs.add(new CommunityData.Track("Upe2ewoz1PI","Song",null).json(false));j.put("songs",songs);return new CommunityData.ListItem(j);
 }
 private List<CommunityData.ListItem> page(int start,boolean picks)throws IOException{
  List<CommunityData.ListItem> result=new ArrayList<>();for(int i=0;i<20;i++)result.add(item(start+i,picks,OWNER));return result;
 }
 @Test public void homeFindsPicksBeyondFirstUserPageWithoutMixingSections()throws Exception{
  List<Integer> calls=new ArrayList<>();
  CommunityDiscovery.Result result=CommunityDiscovery.load(offset->{calls.add(offset);return page(offset,offset>0);},Collections.emptyList(),0,null,Collections.emptySet());
  assertEquals(Arrays.asList(0,20),calls);assertEquals(40,result.items.size());
  assertEquals(20,result.items.stream().filter(i->CommunityDiscovery.matches(i,CommunityDiscovery.Section.PICKS)).count());
  assertEquals(20,result.items.stream().filter(i->CommunityDiscovery.matches(i,CommunityDiscovery.Section.COMMUNITY)).count());
 }
 @Test public void userBrowseSkipsAllCuratedPageAndStopsAtActualEnd()throws Exception{
  CommunityDiscovery.Result result=CommunityDiscovery.load(offset->offset==0?page(0,true):Arrays.asList(item(20,false,OWNER)),Collections.emptyList(),0,CommunityDiscovery.Section.COMMUNITY,Collections.emptySet());
  assertEquals(1,result.items.size());assertFalse(result.items.get(0).curated);assertFalse(result.hasMore);
 }
 @Test public void boundedScanIsNotReportedAsEmptyAndCanContinue()throws Exception{
  CommunityDiscovery.Source source=offset->offset<100?page(offset,false):Arrays.asList(item(100,true,OWNER));
  CommunityDiscovery.Result first=CommunityDiscovery.load(source,Collections.emptyList(),0,CommunityDiscovery.Section.PICKS,Collections.emptySet());
  assertTrue(first.items.isEmpty());assertTrue(first.hasMore);assertEquals(100,first.nextOffset);
  CommunityDiscovery.Result next=CommunityDiscovery.load(source,first.items,first.nextOffset,CommunityDiscovery.Section.PICKS,Collections.emptySet());
  assertEquals(1,next.items.size());assertFalse(next.hasMore);
 }
 @Test public void blockedAuthorsAreRemovedFromPreviousAndIncomingItems()throws Exception{
  CommunityDiscovery.Result result=CommunityDiscovery.load(offset->Arrays.asList(item(2,true,BLOCKED),item(3,true,OWNER)),Arrays.asList(item(1,true,BLOCKED)),0,CommunityDiscovery.Section.PICKS,Collections.singleton(BLOCKED));
  assertEquals(1,result.items.size());assertEquals(OWNER,result.items.get(0).owner);
 }
 @Test public void mineKeepsBothKindsAndPageOverlapDoesNotDuplicateCards()throws Exception{
  CommunityData.ListItem existing=item(1,true,OWNER);
  CommunityDiscovery.Result result=CommunityDiscovery.load(offset->Arrays.asList(existing,item(2,false,OWNER)),Arrays.asList(existing),20,CommunityDiscovery.Section.MINE,Collections.emptySet());
  assertEquals(2,result.items.size());assertTrue(result.items.get(0).curated);assertFalse(result.items.get(1).curated);
 }
 @Test public void failuresPropagateInsteadOfPretendingFeedIsEmpty()throws Exception{
  assertThrows(IOException.class,()->CommunityDiscovery.load(offset->{throw new IOException("Offline");},Collections.emptyList(),0,null,Collections.emptySet()));
 }
}
