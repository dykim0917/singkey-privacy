function(config) {
 'use strict';
 if(!['m.youtube.com','www.youtube.com','youtube.com'].includes(location.hostname)||window!==window.top)return;
 const bridge=window.singkeyNative;
 const send=(event,details={})=>bridge.postMessage(JSON.stringify({token:config.token,event,...details}));
 const matches=()=>new URL(location.href).searchParams.get('v')===config.videoID;
 const isAd=()=>!!document.querySelector('.ad-showing,.ad-interrupting');
 let video,graph,key=config.key,pausedByApp=!config.autoplay,failed=false,preparing=false;
 let state='',playing=false,ended=false,lastTime=0,lastMovement=performance.now(),lastMetrics=0;
 let hasPlayed=false,initialPosition=config.position,layoutUntil=0,layoutPlaying=false;
 let adWasPlaying=false,contentAfterAd=0,contentDuration=0,contentTime=0;
 const graphs=new WeakMap();
 const emitState=value=>{if(state!==value){state=value;send(value);}};
 const reportPlaying=value=>{if(playing!==value){playing=value;send(value?'playing':'paused');}};
 const reset=()=>graph?.processor.reset();
 function reportEnded(){
  // YouTube can remove the ad CSS class before dispatching its ended event.
  // Require observed content playback near its own end, after the ad transition.
  if(ended||isAd()||adWasPlaying||performance.now()<contentAfterAd||!hasPlayed||
     !Number.isFinite(contentDuration)||contentDuration<=0||contentTime<contentDuration-2)return;
  ended=true;reportPlaying(false);graph?.context.suspend();send('ended');
 }
 function fail(reason){
  if(failed)return;failed=true;video?.pause();graph?.context.suspend();reportPlaying(false);emitState('pitch_unavailable');
  if(config.diagnostics)send('diagnostic',{reason});
 }
 function bind(){
  if(!matches()){video?.pause();graph?.context.suspend();reportPlaying(false);emitState('page_changed');return;}
  const next=document.querySelector('video');if(!next||next===video)return;
  graph?.context.suspend();video=next;graph=graphs.get(next);failed=false;hasPlayed=false;ended=false;lastTime=0;lastMovement=performance.now();
  adWasPlaying=isAd();contentAfterAd=0;contentDuration=0;contentTime=0;
  const target=video;
  video.addEventListener('seeking',()=>{if(video===target){reset();reportPlaying(false);emitState('buffering');}});
  video.addEventListener('waiting',()=>{if(video===target){reportPlaying(false);emitState('buffering');}});
  video.addEventListener('playing',()=>{if(video===target&&!isAd()){if(pausedByApp)target.pause();else{hasPlayed=true;lastMovement=performance.now();}}});
  video.addEventListener('pause',()=>{if(video===target){reportPlaying(false);graph?.context.suspend();}});
  video.addEventListener('ended',()=>{if(video===target)reportEnded();});
  video.addEventListener('error',()=>{if(video===target){reportPlaying(false);emitState('failed');}});
  video.addEventListener('loadedmetadata',()=>{
   if(video===target&&initialPosition>0&&!isAd()&&Number.isFinite(target.duration)){target.currentTime=Math.min(initialPosition,Math.max(0,target.duration-0.1));initialPosition=0;}
  });
  if(pausedByApp)video.pause();send('ready');
 }
 async function prepare(){
  if(!video||!matches()||failed||preparing)return;
  if(graph){if(!video.paused)await graph.context.resume();return;}
  preparing=true;let context,source;
  const target=video;
  try{
   context=new AudioContext({latencyHint:'interactive'});
   const processor=new SingKeyAndroidDSP(Uint8Array.from(atob(config.wasm),c=>c.charCodeAt(0)),context.sampleRate);
   // Android's page CSP does not allow our blob AudioWorklet module. Use the
   // standard main-thread Web Audio API without changing CSP or CORS settings.
   const node=context.createScriptProcessor(processor.frames,2,2);
   const candidate={context,processor,node,source:null,lastCallback:0,maxGap:0};
   node.onaudioprocess=event=>{
    const now=performance.now();if(candidate.lastCallback)candidate.maxGap=Math.max(candidate.maxGap,now-candidate.lastCallback);candidate.lastCallback=now;
    if(target!==video||failed||pausedByApp){event.outputBuffer.getChannelData(0).fill(0);event.outputBuffer.getChannelData(1).fill(0);return;}
    try{processor.process(event.inputBuffer.getChannelData(0),event.inputBuffer.getChannelData(1),event.outputBuffer.getChannelData(0),event.outputBuffer.getChannelData(1),isAd()?0:key);}
    catch{fail('processor');}
   };
   source=context.createMediaElementSource(target);candidate.source=source;
   source.connect(node);node.connect(context.destination);graphs.set(target,candidate);
   if(target!==video||!matches()){await context.suspend();return;}
   graph=candidate;if(!video.paused)await context.resume();emitState(key?'pitch_pending':'original');
  }catch{
   // Do not claim a changed key while silently playing unprocessed audio.
   if(source){source.disconnect();source.connect(context.destination);await context.suspend();}
   else await context?.close();fail('graph');
  }finally{preparing=false;}
 }
 async function control(name,value){
  bind();if(!video||!matches())return;
  if(name==='layout'){layoutPlaying=!video.paused&&!pausedByApp&&!failed&&!isAd();layoutUntil=performance.now()+1500;return;}
  if(name==='pause'){layoutUntil=0;pausedByApp=true;video.pause();await graph?.context.suspend();reportPlaying(false);return;}
  if(name==='play'||name==='toggle'){
   layoutUntil=0;const shouldPlay=name==='play'||video.paused;
   pausedByApp=!shouldPlay;
   if(!shouldPlay){video.pause();await graph?.context.suspend();reportPlaying(false);return;}
   if(failed){emitState('pitch_unavailable');return;}
   await graph?.context.resume();try{await video.play();}catch{send('ready');}return;
  }
  if(name==='seek'&&Number.isFinite(value)&&value>=0&&!isAd()){reset();video.currentTime=value;return;}
  if(name==='key'&&Number.isInteger(value)&&Math.abs(value)<=12){
   layoutUntil=0;key=value;if(failed){emitState('pitch_unavailable');return;}
   if(key||graph)await prepare();else emitState('original');
  }
 }
 globalThis.singkeyBrowserControl=control;
 document.addEventListener('pointerdown',event=>{if(event.isTrusted){layoutUntil=0;pausedByApp=false;}},{capture:true});
 document.addEventListener('click',event=>{if(event.isTrusted&&key&&!failed)prepare();},{capture:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)graph?.context.suspend();});
 setInterval(()=>{
  bind();if(!video||!matches())return;
  const now=performance.now(),ad=isAd();
  if(pausedByApp){video.pause();reportPlaying(false);return;}
  if(layoutUntil&&now<layoutUntil&&layoutPlaying&&video.paused&&!video.ended&&!failed&&!ad&&!document.hidden&&video.readyState>=3){layoutUntil=0;video.play().catch(()=>{});}
  if(ad){adWasPlaying=true;reportPlaying(false);emitState('ad_playing');}
  else if(video.ended){reportEnded();}
  else if(!video.paused&&video.readyState>=3){
   if(adWasPlaying){adWasPlaying=false;contentAfterAd=now+1000;reset();}
   if(now>=contentAfterAd){contentTime=video.currentTime;contentDuration=video.duration;}
   if(video.currentTime!==lastTime){lastMovement=now;hasPlayed=true;}
   // Autoplay may start muted. Do not count inaudible playback as practice.
   reportPlaying(!failed&&!video.muted&&video.volume!==0&&now-lastMovement<1500);
   if(now-lastMovement>=1500)emitState('buffering');
   else if(state==='buffering'||state==='ad_playing')emitState(key?'pitch_pending':'original');
  }else reportPlaying(false);
  lastTime=video.currentTime;
  if(!video.paused&&key&&!graph&&!failed)prepare();
  if(graph&&!failed&&!video.paused&&graph.context.state!=='running')graph.context.resume();
  if(now-lastMetrics>=1000){
   lastMetrics=now;send('position',{seconds:Number.isFinite(video.currentTime)?video.currentTime:0,ad,muted:video.muted});
   if(graph&&!failed&&!video.paused){
    const levels=graph.processor.levels();
    if(!levels.healthy){fail('processor');return;}
    if(levels.input>0.00001&&levels.output>0.00001&&!ad)emitState(key?'pitch_active':'original');
    if(config.diagnostics){send('metrics',{...levels,key:ad?0:key,maxCallbackGapMs:graph.maxGap});graph.maxGap=0;}
   }
  }
  if(hasPlayed&&!video.paused&&!ad&&now-lastMovement>20000){video.pause();reportPlaying(false);emitState('failed');}
 },250);
 send('document_ready');
}
