function(config) {
 'use strict';
 if(window!==window.top||location.origin!==config.origin)return;
 const send=(event,details={})=>window.singkeyNative.postMessage(JSON.stringify({token:config.token,event,...details}));
 let player,ready=false,disposed=false,playing=false,ended=false,failed=false;
 let wantsPlayback=config.autoplay,key=config.key,pitchReady=key===0,ad=false,lastReport=0,pausePending=false,pitchWaitSince=null;
 const reportPlaying=value=>{if(playing!==value){playing=value;send(value?'playing':'paused');}};
 const canReportPlaying=()=>!disposed&&!failed&&wantsPlayback&&!ad&&(key===0||pitchReady)&&!player.isMuted()&&player.getVolume()>0;
 function sameVideo(){
  const url=player.getVideoUrl();
  // The player can briefly have no URL while cueing the initial video.
  if(!url)return true;
  try{return new URL(url).searchParams.get('v')===config.videoID;}catch{return false;}
 }
 function unavailable(){
  if(failed)return;failed=true;wantsPlayback=false;
  if(ready)player.pauseVideo();reportPlaying(false);send('pitch_unavailable');
 }
 function stateChanged(event){
  if(disposed||failed)return;
  switch(event.data){
   case 1:
    if(!sameVideo()){failed=true;wantsPlayback=false;player.pauseVideo();reportPlaying(false);send('failed',{code:0});return;}
    if(pausePending||document.hidden){player.pauseVideo();reportPlaying(false);return;}
    // A click on the official player's own controls is also a playback request.
    wantsPlayback=true;ended=false;reportPlaying(canReportPlaying());break;
   case 2: pausePending=false;reportPlaying(false);break;
   case 3: reportPlaying(false);send('buffering');break;
   case 0:
    reportPlaying(false);
    if(!ended){ended=true;wantsPlayback=false;send('ended');}break;
   case 5: reportPlaying(false);send('ready');break;
  }
 }
 window.onYouTubeIframeAPIReady=()=>{
  if(disposed)return;
  player=new YT.Player('player',{
   width:'100%',height:'100%',videoId:config.videoID,
   playerVars:{autoplay:0,controls:1,playsinline:1,fs:0,origin:config.origin,start:Math.floor(config.position)},
   events:{
    onReady:()=>{
     if(disposed||failed)return;ready=true;send('ready');
     if(key!==0&&!config.pitchEnabled){unavailable();return;}
     if(config.position>0){
      // seekTo on an unstarted iframe can start playback. Cue paused restores.
      if(wantsPlayback)player.seekTo(config.position,true);
      else player.cueVideoById({videoId:config.videoID,startSeconds:config.position});
     }
     if(wantsPlayback&&!document.hidden)player.playVideo();
    },
    onStateChange:stateChanged,
    onError:event=>{if(!disposed){failed=true;wantsPlayback=false;reportPlaying(false);send('failed',{code:Number(event.data)||0});}},
    onAutoplayBlocked:()=>{wantsPlayback=false;reportPlaying(false);send('autoplay_blocked');}
   }
  });
 };
 globalThis.singkeyBrowserControl=(action,value)=>{
  if(disposed)return;
  if(action==='pause'){wantsPlayback=false;if(ready){pausePending=[1,3].includes(player.getPlayerState());player.pauseVideo();}reportPlaying(false);return;}
  if(action==='stop'){wantsPlayback=false;disposed=true;reportPlaying(false);if(ready)player.destroy();return;}
  if(action==='key'){
   if(!Number.isInteger(value)||Math.abs(value)>12)return;
   key=value;pitchReady=value===0;pitchWaitSince=null;
   if(value!==0&&!config.pitchEnabled)unavailable();
   return;
  }
  if(action==='pitch_active'){if(value===key)pitchReady=true;return;}
  if(action==='pitch_pending'){pitchReady=key===0;pitchWaitSince=null;reportPlaying(false);return;}
  if(action==='ad'){ad=value===1;if(ad)reportPlaying(false);return;}
  if(!ready||failed)return;
  if(action==='play'){pausePending=false;wantsPlayback=true;player.playVideo();}
  if(action==='seek'&&Number.isFinite(value)&&value>=0){ended=false;player.seekTo(value,true);}
  // Resizing the host never starts a paused video or reloads the iframe.
 };
 document.addEventListener('visibilitychange',()=>{if(document.hidden)globalThis.singkeyBrowserControl('pause',0);});
 setInterval(()=>{
  if(!ready||disposed||failed)return;
  if(!sameVideo()){failed=true;player.pauseVideo();reportPlaying(false);send('failed',{code:0});return;}
  const state=player.getPlayerState();
  if(state===1)reportPlaying(canReportPlaying());
  const now=performance.now();
  // Also detect a missing/blocked frame adapter, which cannot report its own failure.
  if(state===1&&wantsPlayback&&!ad&&key!==0&&!pitchReady&&!document.hidden){
   if(pitchWaitSince===null)pitchWaitSince=now;
   if(now-pitchWaitSince>12000){unavailable();return;}
  }else pitchWaitSince=null;
  if(now-lastReport>=1000){
   lastReport=now;
   const seconds=player.getCurrentTime();
   if((state===1||state===2)&&!ad&&Number.isFinite(seconds)&&seconds>=0)send('position',{seconds,ad:false});
  }
 },250);
 send('document_ready');
 const script=document.createElement('script');script.src='https://www.youtube.com/iframe_api';
 script.onerror=()=>send('failed',{code:0});document.head.appendChild(script);
}
