package kr.keymate.app;

import java.io.*;
import java.util.*;

/** Submitted search text only. Independent of playback history and library backup. */
final class RecentQueries {
 static final int LIMIT=10;
 private final List<String> values=new ArrayList<>();
 static String normalize(String input){return input==null?"":input.replaceAll("[\\s\\p{Z}]+"," ").trim();}
 List<String> entries(){return Collections.unmodifiableList(values);}
 boolean record(String input){
  if(input==null||input.length()>SearchSafety.MAX_INPUT)return false;
  String value=normalize(input);if(!SearchSafety.validInput(value)||SearchSafety.looksLikeLink(value))return false;
  values.remove(value);values.add(0,value);while(values.size()>LIMIT)values.remove(LIMIT);return true;
 }
 void remove(String value){values.remove(value);}
 void clear(){values.clear();}
 String encode()throws IOException{Properties data=new Properties();data.setProperty("version","1");data.setProperty("count",""+values.size());for(int i=0;i<values.size();i++)data.setProperty("q."+i,values.get(i));StringWriter out=new StringWriter();data.store(out,"Naekiro recent searches");return out.toString();}
 static RecentQueries decode(String raw)throws IOException{
  RecentQueries result=new RecentQueries();if(raw==null||raw.isEmpty())return result;
  if(raw.length()>32768)throw new IOException("Search history too large");
  try{Properties data=new Properties();data.load(new StringReader(raw));if(!"1".equals(data.getProperty("version")))throw new IOException("Unsupported search history");int count=Integer.parseInt(data.getProperty("count"));if(count<0||count>LIMIT)throw new IOException("Invalid search count");for(int i=count-1;i>=0;i--)if(!result.record(data.getProperty("q."+i)))throw new IOException("Invalid query");return result;}catch(IllegalArgumentException e){throw new IOException("Invalid search history",e);}
 }
}
