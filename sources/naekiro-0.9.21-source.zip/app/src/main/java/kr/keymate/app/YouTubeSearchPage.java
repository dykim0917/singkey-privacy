package kr.keymate.app;

import com.grack.nanojson.*;
import java.io.IOException;
import java.util.*;
import java.util.regex.*;
import okhttp3.HttpUrl;

/** Reads public search metadata as data; never evaluates page JavaScript. */
final class YouTubeSearchPage {
 private static final Pattern INITIAL=Pattern.compile("(?:var\\s+ytInitialData|window\\[\"ytInitialData\"\\]|ytInitialData)\\s*=\\s*");
 private static final Pattern CLIENT_VERSION=Pattern.compile("\"INNERTUBE_CLIENT_VERSION\"\\s*:\\s*\"([0-9.]{1,64})\"");
 static final class Cursor {
  final String token,version;final AppLanguage language;
  Cursor(String token,String version,AppLanguage language){this.token=token;this.version=version;this.language=language;}
  String body()throws IOException{if(token==null||!token.matches("[A-Za-z0-9_%=.-]{1,16384}")||version==null||!version.matches("[0-9.]{1,64}"))throw new IOException("Invalid continuation");JsonObject client=new JsonObject();client.put("clientName","WEB");client.put("clientVersion",version);client.put("hl",language.language);client.put("gl",language.country);JsonObject context=new JsonObject();context.put("client",client);JsonObject body=new JsonObject();body.put("context",context);body.put("continuation",token);return JsonWriter.string(body);}
 }
 static final class Page {
  final List<Song> songs;final Cursor next;final int excluded;
  Page(List<Song> songs,Cursor next){this(songs,next,0);}
  Page(List<Song> songs,Cursor next,int excluded){this.songs=Collections.unmodifiableList(new ArrayList<>(songs));this.next=next;this.excluded=excluded;}
 }
 static String url(String query,AppLanguage language){
  return new HttpUrl.Builder().scheme("https").host("www.youtube.com").addPathSegment("results")
   .addQueryParameter("search_query",query).addQueryParameter("hl",language.language).addQueryParameter("gl",language.country).build().toString();
 }
 static List<Song> parse(String html)throws IOException{
  return first(html,AppLanguage.EN).songs;
 }
 static Page first(String html,AppLanguage language)throws IOException{
  if(html==null||html.length()>HttpDownloader.MAX_BODY_BYTES)throw new IOException("Search response too large");
  Matcher match=INITIAL.matcher(html);if(!match.find())throw new IOException("Search data unavailable");
  int start=match.end(),end=-1,depth=0;boolean string=false,escape=false;
  if(start>=html.length()||html.charAt(start)!='{')throw new IOException("Invalid search data");
  for(int i=start;i<html.length();i++){
   char c=html.charAt(i);
   if(string){if(escape)escape=false;else if(c=='\\')escape=true;else if(c=='\"')string=false;}
   else if(c=='\"')string=true;
   else if(c=='{'||c=='['){if(++depth>80)throw new IOException("Search data too deep");}
   else if(c=='}'||c==']'){if(--depth==0){end=i+1;break;}}
  }
  if(end<0)throw new IOException("Incomplete search data");
  try{
   JsonObject root=JsonParser.object().from(html.substring(start,end));
   Matcher version=CLIENT_VERSION.matcher(html);String clientVersion=version.find()?version.group(1):null;
   Object search=path(root,"contents","twoColumnSearchResultsRenderer","primaryContents","sectionListRenderer");
   return page(root,search,clientVersion,language);
  }catch(JsonParserException error){throw new IOException("Invalid search data",error);}
 }
 static Page next(String json,Cursor cursor)throws IOException{
  if(json==null||json.length()>HttpDownloader.MAX_BODY_BYTES)throw new IOException("Search response too large");
  validateDepth(json);
  try{JsonObject root=JsonParser.object().from(json);Object commands=root.get("onResponseReceivedCommands");if(commands==null)commands=root.get("onResponseReceivedActions");if(!(commands instanceof JsonArray))throw new IOException("Missing continuation results");return page(commands,commands,cursor.version,cursor.language);}catch(JsonParserException error){throw new IOException("Invalid continuation data",error);}
 }
 private static void validateDepth(String json)throws IOException{int depth=0;boolean string=false,escape=false;for(int i=0;i<json.length();i++){char c=json.charAt(i);if(string){if(escape)escape=false;else if(c=='\\')escape=true;else if(c=='"')string=false;}else if(c=='"')string=true;else if(c=='{'||c=='['){if(++depth>80)throw new IOException("Search data too deep");}else if(c=='}'||c==']')depth--;}}
 private static Page page(Object root,Object nextRoot,String version,AppLanguage language)throws IOException{
  ArrayList<Song> songs=new ArrayList<>();int[] excluded={0};walk(root,0,new int[]{0},new HashSet<>(),songs,excluded);String token=continuation(nextRoot,0,new int[]{0});
  return new Page(songs,token!=null&&version!=null?new Cursor(token,version,language):null,excluded[0]);
 }
 private static Object path(JsonObject node,String...keys){Object value=node;for(String key:keys){if(!(value instanceof JsonObject))return null;value=((JsonObject)value).get(key);}return value;}
 private static String continuation(Object node,int depth,int[] visited)throws IOException{
  if(depth>80||++visited[0]>100000)throw new IOException("Continuation too complex");
  if(node instanceof JsonObject){JsonObject item=(JsonObject)node;Object endpoint=path(item,"continuationItemRenderer","continuationEndpoint");if(endpoint instanceof JsonObject){Object api=path((JsonObject)endpoint,"commandMetadata","webCommandMetadata","apiUrl");Object token=path((JsonObject)endpoint,"continuationCommand","token");if("/youtubei/v1/search".equals(api)&&token instanceof String&&((String)token).matches("[A-Za-z0-9_%=.-]{1,16384}"))return (String)token;}for(Object value:item.values()){String found=continuation(value,depth+1,visited);if(found!=null)return found;}}
  else if(node instanceof JsonArray)for(Object value:(JsonArray)node){String found=continuation(value,depth+1,visited);if(found!=null)return found;}return null;
 }
 private static void walk(Object node,int depth,int[] visited,Set<String> seen,List<Song> result,int[] excluded)throws IOException{
  if(result.size()>=SearchSafety.MAX_RESULTS)return;
  if(depth>80||++visited[0]>100000)throw new IOException("Search data too complex");
  if(node instanceof JsonObject){
   JsonObject object=(JsonObject)node;JsonObject item=object.getObject("videoRenderer");
   if(item!=null){
    String id=item.getString("videoId",""),title=label(item.getObject("title")),channel=label(item.getObject("ownerText"));
    if(id.matches("[A-Za-z0-9_-]{11}")&&!title.isEmpty()&&title.length()<=2000&&channel.length()<=500&&seen.add(id)){
     if(excludedChannel(item))excluded[0]++;
     else result.add(new Song("https://www.youtube.com/watch?v="+id,title+(channel.isEmpty()?"":" · "+channel),"https://i.ytimg.com/vi/"+id+"/hqdefault.jpg"));
    }
   }
   // Preserve the page's result order. JSON arrays retain ranking order.
   for(Object value:object.values())walk(value,depth+1,visited,seen,result,excluded);
  }else if(node instanceof JsonArray)for(Object value:(JsonArray)node)walk(value,depth+1,visited,seen,result,excluded);
 }
 private static boolean excludedChannel(JsonObject item){
  for(String field:new String[]{"ownerText","longBylineText","shortBylineText"}){
   Object runs=path(item,field,"runs");
   if(runs instanceof JsonArray)for(Object run:(JsonArray)runs)if(run instanceof JsonObject){
    Object id=path((JsonObject)run,"navigationEndpoint","browseEndpoint","browseId");
    if(id instanceof String&&SearchChannelPolicy.excluded((String)id))return true;
   }
  }
  return false;
 }
 private static String label(JsonObject object){
  if(object==null)return "";String simple=object.getString("simpleText");if(simple!=null)return simple;
  StringBuilder value=new StringBuilder();JsonArray runs=object.getArray("runs");
  if(runs!=null)for(Object run:runs)if(run instanceof JsonObject){value.append(((JsonObject)run).getString("text",""));if(value.length()>2500)return "";}
  return value.toString();
 }
 private YouTubeSearchPage(){}
}
