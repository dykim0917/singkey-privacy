package kr.keymate.app;

import java.io.*;
import java.util.*;

/** Actual playback history, independent of explicitly saved playlist keys. */
final class RecentSongs {
 private SavedSongs songs = new SavedSongs();
 private final Map<String,Long> playedAt = new HashMap<>();
 List<SavedSongs.Entry> entries() { return songs.entries(); }
 long playedAt(String url) { SavedSongs.Entry e = songs.find(url); return e == null ? 0 : playedAt.getOrDefault(e.song.url,0L); }
 void record(Song song, int key) {
  SavedSongs.Entry old = songs.find(song.url);
  if (old != null) playedAt.remove(old.song.url);
  songs.save(song,key); playedAt.put(song.url,System.currentTimeMillis());
  trim();
 }
 private void trim() { while (songs.entries().size() > 20) remove(songs.entries().get(20).song.url); }
 void updateKey(Song song, int key) { if (songs.find(song.url) != null) {
  long time = playedAt(song.url); SavedSongs.Entry old = songs.find(song.url); playedAt.remove(old.song.url);
  songs.saveInOrder(song,key); playedAt.put(song.url,time);
 } }
 void remove(String url) { SavedSongs.Entry old = songs.find(url); if (old != null) playedAt.remove(old.song.url); songs.remove(url); }
 String encode() throws IOException {
  Properties p = new Properties(); p.setProperty("historyVersion","1"); p.setProperty("songs",songs.encode());
  for (SavedSongs.Entry e : entries()) p.setProperty(e.song.url,Long.toString(playedAt(e.song.url)));
  StringWriter out = new StringWriter(); p.store(out,"SingKey recent playback"); return out.toString();
 }
 static RecentSongs decode(String value) throws IOException {
  RecentSongs result = new RecentSongs(); if (value == null || value.isEmpty()) return result;
  try {
   Properties p = new Properties(); p.load(new StringReader(value));
   if (!"1".equals(p.getProperty("historyVersion"))) throw new IOException("Unsupported history version");
   result.songs = SavedSongs.decode(p.getProperty("songs"));
   for (SavedSongs.Entry e : result.entries()) result.playedAt.put(e.song.url,Long.parseLong(p.getProperty(e.song.url,"0")));
   result.trim(); return result;
  } catch (IllegalArgumentException e) { throw new IOException("Invalid history",e); }
 }
}
