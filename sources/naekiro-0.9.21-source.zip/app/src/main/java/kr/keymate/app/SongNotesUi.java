package kr.keymate.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.*;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Explicit, local notebook editing. No automatic prompts or analytics transmission. */
final class SongNotesUi implements AutoCloseable {
 static final String PREF="songNotes";
 private static final Object WRITE_LOCK=new Object();
 private final Activity activity;
 private final Runnable changed;
 private final SharedPreferences preferences;
 private final ExecutorService io=Executors.newSingleThreadExecutor();
 private SongNotes notes=new SongNotes();
 private boolean readable=true,busy,closed;
 private AlertDialog dialog;
 SongNotesUi(Activity activity,Runnable changed){
  this.activity=activity;this.changed=changed;preferences=activity.getPreferences(Activity.MODE_PRIVATE);
  synchronized(WRITE_LOCK){try{notes=SongNotes.decode(preferences.getString(PREF,null));}catch(IOException e){readable=false;}}
 }
 boolean readable(){return readable&&!busy;}
 SongNotes snapshot(){return notes.copy();}
 SongNotes.Entry find(String url){return notes.find(url);}
 void restored(SongNotes value){notes=value;readable=true;changed.run();}
 String summary(String url){SongNotes.Entry e=notes.find(url);if(e==null)return activity.getString(R.string.notes_empty_song);return summary(e);}
 private String summary(SongNotes.Entry e){
  String value=e.rating==SongNotes.Rating.NONE?"":activity.getString(R.string.notes_previous,keyText(e.ratingKey),activity.getString(ratingLabel(e.rating)),DateFormat.getDateInstance(DateFormat.SHORT).format(new Date(e.ratedAt)));
  if(e.stage!=SongNotes.Stage.NONE)value+=(value.isEmpty()?"":" · ")+activity.getString(stageLabel(e.stage));
  if(!e.note.isEmpty())value+=(value.isEmpty()?"":"\n")+e.note;return value;
 }
 void edit(Song song,int capturedKey){
  if(busy)return;if(!readable){showAll();return;}
  SongNotes.Entry previous=notes.find(song.url);
  LinearLayout body=column();
  TextView songTitle=SingKeyUi.heading(activity,song.title,17);songTitle.setPadding(0,0,0,dp(8));body.addView(songTitle);
  if(previous!=null){TextView last=SingKeyUi.label(activity,summary(previous),14,true);last.setPadding(dp(12),dp(12),dp(12),dp(12));last.setBackground(SingKeyUi.shape(activity,SingKeyUi.RAISED,10));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(12);lp.bottomMargin=dp(20);body.addView(last,lp);}
  body.addView(SingKeyUi.heading(activity,activity.getString(R.string.notes_rate_key,keyText(capturedKey)),16));
  RadioGroup ratings=new RadioGroup(activity);ratings.setOrientation(LinearLayout.VERTICAL);
  SongNotes.Rating[] choices=SongNotes.Rating.values();
  for(SongNotes.Rating rating:choices){RadioButton choice=new RadioButton(activity);choice.setId(View.generateViewId());choice.setTag(rating);choice.setText(ratingLabel(rating));AppDialog.choice(choice);ratings.addView(choice,new RadioGroup.LayoutParams(-1,-2));}
  body.addView(ratings);body.addView(SingKeyUi.label(activity,activity.getString(R.string.notes_rating_optional),14,true));
  TextView stageLabel=SingKeyUi.heading(activity,activity.getString(R.string.notes_stage),16);stageLabel.setPadding(0,dp(16),0,dp(4));body.addView(stageLabel);
  Spinner stage=new Spinner(activity);stage.setId(View.generateViewId());stageLabel.setLabelFor(stage.getId());
  String[] stages=new String[SongNotes.Stage.values().length];for(int i=0;i<stages.length;i++)stages[i]=activity.getString(stageLabel(SongNotes.Stage.values()[i]));
  ArrayAdapter<String> adapter=new ArrayAdapter<String>(activity,android.R.layout.simple_spinner_item,stages){
   private TextView item(int position){TextView v=SingKeyUi.label(activity,getItem(position),16,false);v.setPadding(dp(14),dp(12),dp(14),dp(12));v.setMinHeight(dp(48));return v;}
   @Override public View getView(int position,View convert,android.view.ViewGroup parent){TextView v=item(position);v.setCompoundDrawablesRelative(null,null,SingKeyUi.icon(activity,R.drawable.ic_sk_down,SingKeyUi.MUTED,16),null);return v;}
   @Override public View getDropDownView(int position,View convert,android.view.ViewGroup parent){return item(position);}
  };stage.setAdapter(adapter);stage.setBackground(SingKeyUi.outline(activity,SingKeyUi.RAISED,12,0xff29313e));stage.setPopupBackgroundDrawable(SingKeyUi.shape(activity,SingKeyUi.RAISED,12));stage.setMinimumHeight(dp(48));stage.setSelection(previous==null?0:previous.stage.ordinal());body.addView(stage,new LinearLayout.LayoutParams(-1,-2));
  TextView noteLabel=SingKeyUi.heading(activity,activity.getString(R.string.notes_memo),16);noteLabel.setPadding(0,dp(16),0,dp(4));body.addView(noteLabel);
  EditText memo=new EditText(activity);memo.setId(View.generateViewId());noteLabel.setLabelFor(memo.getId());memo.setHint(R.string.notes_memo_hint);memo.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);memo.setMinLines(2);memo.setMaxLines(5);memo.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(SongNotes.MAX_NOTE)});SingKeyUi.field(memo);memo.setText(previous==null?"":previous.note);body.addView(memo);
  ScrollView scroll=AppDialog.scroll(activity,body);
  AlertDialog editor=new AppDialog(activity).destructive(AlertDialog.BUTTON_NEUTRAL).setTitle(R.string.notes_title).setView(scroll).setNegativeButton(R.string.cancel,null).setPositiveButton(R.string.save,null).create();
  if(previous!=null)editor.setButton(AlertDialog.BUTTON_NEUTRAL,activity.getString(R.string.delete),(d,w)->confirmRemove(song));
  show(editor);
  editor.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
   SongNotes.Rating rating=null;int checked=ratings.getCheckedRadioButtonId();if(checked!=-1)rating=(SongNotes.Rating)ratings.findViewById(checked).getTag();
   SongNotes next=notes.copy();
   try{next.put(song,capturedKey,rating,memo.getText().toString(),SongNotes.Stage.values()[stage.getSelectedItemPosition()],System.currentTimeMillis());}
   catch(IllegalArgumentException error){message(R.string.notes_limit);return;}
   write(next,()->{editor.dismiss();Toast.makeText(activity,R.string.notes_saved,Toast.LENGTH_SHORT).show();});
  });
 }
 void showAll(){
  if(busy)return;
  if(!readable){show(new AppDialog(activity).setTitle(R.string.notes_title).setMessage(R.string.notes_unreadable).setNegativeButton(R.string.close,null).setPositiveButton(R.string.notes_clear,(d,w)->confirmClear()).create());return;}
  List<SongNotes.Entry> entries=notes.entries();
  if(entries.isEmpty()){show(new AppDialog(activity).setTitle(R.string.notes_title).setMessage(R.string.notes_empty).setPositiveButton(R.string.close,null).create());return;}
  ArrayAdapter<SongNotes.Entry> rows=new ArrayAdapter<SongNotes.Entry>(activity,android.R.layout.simple_list_item_1,entries){
   @Override public View getView(int position,View convert,android.view.ViewGroup parent){
    SongNotes.Entry e=getItem(position);LinearLayout row=new LinearLayout(activity);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(16),dp(12),dp(16),dp(12));
    row.addView(SingKeyUi.heading(activity,e.song.title,16));TextView detail=SingKeyUi.label(activity,summary(e),14,true);detail.setPadding(0,dp(6),0,dp(6));row.addView(detail);
    row.addView(SingKeyUi.label(activity,activity.getString(R.string.notes_updated,DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(e.updatedAt))),12,true));return row;
   }
  };
  show(new AppDialog(activity).destructive(AlertDialog.BUTTON_NEUTRAL).setTitle(R.string.notes_title).setAdapter(rows,(d,which)->{SongNotes.Entry e=entries.get(which);edit(e.song,e.ratingKey);}).setNegativeButton(R.string.close,null).setNeutralButton(R.string.notes_clear,(d,w)->confirmClear()).create());
 }
 private void confirmRemove(Song song){show(new AppDialog(activity).destructive(AlertDialog.BUTTON_POSITIVE).setTitle(R.string.notes_delete_title).setMessage(R.string.notes_delete_description).setNegativeButton(R.string.cancel,null).setPositiveButton(R.string.delete,(d,w)->{SongNotes next=notes.copy();next.remove(song.url);write(next,()->Toast.makeText(activity,R.string.notes_deleted,Toast.LENGTH_SHORT).show());}).create());}
 private void confirmClear(){show(new AppDialog(activity).destructive(AlertDialog.BUTTON_POSITIVE).setTitle(R.string.notes_clear).setMessage(R.string.notes_delete_description).setNegativeButton(R.string.cancel,null).setPositiveButton(R.string.delete,(d,w)->write(new SongNotes(),()->Toast.makeText(activity,R.string.notes_deleted,Toast.LENGTH_SHORT).show())).create());}
 private void write(SongNotes next,Runnable success){
  if(busy||closed)return;
  final String encoded;try{encoded=next.encode();}catch(IOException e){message(R.string.notes_save_failed);return;}
  busy=true;if(dialog!=null&&dialog.getButton(AlertDialog.BUTTON_POSITIVE)!=null)dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
  io.execute(()->{
   boolean saved;synchronized(WRITE_LOCK){if(closed)return;saved=preferences.edit().putString(PREF,encoded).commit();}
   activity.runOnUiThread(()->{if(closed||activity.isDestroyed())return;busy=false;if(dialog!=null&&dialog.getButton(AlertDialog.BUTTON_POSITIVE)!=null)dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);if(saved){notes=next;readable=true;changed.run();success.run();}else message(R.string.notes_save_failed);});
  });
 }
 private void message(int id){Toast.makeText(activity,id,Toast.LENGTH_LONG).show();}
 private void show(AlertDialog next){if(dialog!=null)dialog.dismiss();dialog=next;next.setOnDismissListener(d->{if(dialog==next)dialog=null;});next.show();}
 private LinearLayout column(){return AppDialog.body(activity);}
 private int dp(int value){return SingKeyUi.dp(activity,value);}
 void layoutChanged(){if(dialog!=null)AppDialog.resize(activity,dialog);}
 private String keyText(int key){return key==0?activity.getString(R.string.original_key):activity.getString(R.string.semitones,(key>0?"+":"")+key);}
 private int ratingLabel(SongNotes.Rating rating){switch(rating){case LOW:return R.string.notes_low;case COMFORTABLE:return R.string.notes_comfortable;case HIGH:return R.string.notes_high;default:return R.string.notes_rating_clear;}}
 private int stageLabel(SongNotes.Stage stage){switch(stage){case PRACTICING:return R.string.notes_practicing;case CONFIDENT:return R.string.notes_confident;default:return R.string.notes_no_stage;}}
 @Override public void close(){synchronized(WRITE_LOCK){closed=true;}if(dialog!=null)dialog.dismiss();io.shutdownNow();}
}
