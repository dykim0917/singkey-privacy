package kr.keymate.app;

/** Keep the user's song/artist query; strip only recognizable provider branding. */
final class AlternativeSearch {
 static String query(Song song,String previous){
  if(SearchSafety.validInput(previous)&&!SearchSafety.looksLikeLink(previous))return previous.trim();
  if(song==null)return "";
  String title=song.title;int channel=title.lastIndexOf(" · ");if(channel>=0)title=title.substring(0,channel);
  title=title.replaceFirst("(?i)^\\s*\\[(?:TJ|KY)\\s*(?:노래방|KARAOKE)\\]\\s*","")
   .replaceFirst("(?i)\\s*/\\s*(?:TJ|KY)\\s*KARAOKE\\s*$","")
   .replaceAll("(?i)\\s*\\((?:TJ|KY)[.\\s]*\\d+\\)","").trim();
  title=RecentQueries.normalize(title);
  if(title.equals(EmbedAvailability.id(song.url)))return "";
  if(title.length()>SearchSafety.MAX_QUERY)title=title.substring(0,SearchSafety.MAX_QUERY-(Character.isHighSurrogate(title.charAt(SearchSafety.MAX_QUERY-1))?1:0)).trim();
  return SearchSafety.validInput(title)&&!SearchSafety.looksLikeLink(title)?title:"";
 }
 private AlternativeSearch(){}
}
