package kr.keymate.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;
import okhttp3.*;

/** Independent, bounded thumbnail downloads; playback never waits for images. */
final class ThumbnailLoader {
 private final Handler main = new Handler(Looper.getMainLooper());
 private final OkHttpClient client;
 private volatile boolean closed;
 private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(4 * 1024 * 1024) {
  @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount(); }
 };
 ThumbnailLoader() {
  Dispatcher dispatcher = new Dispatcher(); dispatcher.setMaxRequests(4); dispatcher.setMaxRequestsPerHost(4);
  client = new OkHttpClient.Builder().dispatcher(dispatcher).followRedirects(false).followSslRedirects(false).callTimeout(12, TimeUnit.SECONDS).build();
 }
 void load(String url, ImageView target, BooleanSupplier active) {
  if (closed || !SearchSafety.thumbnail(url)) return;
  Bitmap cached = cache.get(url);
  if (cached != null) { target.setImageBitmap(cached); return; }
  Request request;
  try { request = new Request.Builder().url(url).build(); } catch (IllegalArgumentException e) { return; }
  client.newCall(request).enqueue(new Callback() {
   @Override public void onFailure(Call call, IOException error) { /* Keep the placeholder. */ }
   @Override public void onResponse(Call call, Response response) throws IOException {
    Bitmap bitmap;
    try (Response result = response) {
     if (!result.isSuccessful() || result.body() == null) return;
     ByteArrayOutputStream bytes = new ByteArrayOutputStream();
     byte[] buffer = new byte[8192]; int count;
     java.io.InputStream input = result.body().byteStream();
     while ((count = input.read(buffer)) != -1) {
      if (bytes.size() + count > 2 * 1024 * 1024 || call.isCanceled()) return;
      bytes.write(buffer, 0, count);
     }
     byte[] data = bytes.toByteArray();
     BitmapFactory.Options options = new BitmapFactory.Options(); options.inJustDecodeBounds = true;
     BitmapFactory.decodeByteArray(data, 0, data.length, options);
     if (options.outWidth <= 0 || options.outHeight <= 0) return;
     options.inSampleSize = 1;
     while (options.outWidth / options.inSampleSize > 480 || options.outHeight / options.inSampleSize > 270) options.inSampleSize *= 2;
     options.inJustDecodeBounds = false;
     bitmap = BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }
    if (bitmap != null && !closed) main.post(() -> {
     if (!closed && active.getAsBoolean()) { cache.put(url, bitmap); target.setImageBitmap(bitmap); }
    });
   }
  });
 }
 void cancelPending() { client.dispatcher().cancelAll(); }
 void close() {
  if (closed) return;
  closed=true;main.removeCallbacksAndMessages(null);cache.evictAll();
  // TLS socket shutdown may write close_notify. Never do that on the UI thread.
  new Thread(() -> {
   try {client.dispatcher().cancelAll();client.connectionPool().evictAll();}
   finally {client.dispatcher().executorService().shutdown();}
  },"singkey-thumbnail-close").start();
 }
}
