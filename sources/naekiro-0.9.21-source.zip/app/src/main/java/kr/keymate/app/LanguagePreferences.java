package kr.keymate.app;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.LocaleList;
import java.util.Locale;

/** Framework app locales on Android 13+, a device-local choice on earlier versions. */
final class LanguagePreferences {
 static String tag(Context context) {
  if(Build.VERSION.SDK_INT>=33) {
   LocaleList locales=context.getSystemService(android.app.LocaleManager.class).getApplicationLocales();
   return locales.isEmpty()?"":locales.get(0).getLanguage();
  }
  return context.getSharedPreferences("MainActivity",Context.MODE_PRIVATE).getString("appLanguage","");
 }
 static AppLanguage resolve(Context context) {
  String selected=tag(context);
  if(!selected.isEmpty())return AppLanguage.from(Locale.forLanguageTag(selected));
  LocaleList system=Build.VERSION.SDK_INT>=33?context.getSystemService(android.app.LocaleManager.class).getSystemLocales():android.content.res.Resources.getSystem().getConfiguration().getLocales();
  return AppLanguage.from(system.isEmpty()?Locale.ENGLISH:system.get(0));
 }
 static void apply(Activity activity,String tag) {
  if(!tag.isEmpty()&&!tag.equals("ko")&&!tag.equals("en")&&!tag.equals("ja"))throw new IllegalArgumentException("Unsupported language");
  if(tag.equals(tag(activity)))return;
  if(Build.VERSION.SDK_INT>=33)activity.getSystemService(android.app.LocaleManager.class).setApplicationLocales(LocaleList.forLanguageTags(tag));
  else {activity.getSharedPreferences("MainActivity",Context.MODE_PRIVATE).edit().putString("appLanguage",tag).apply();activity.recreate();}
 }
}
