package kr.keymate.app;

/** A downward pull must start in the native header, never in the video or list. */
final class PullToReloadGesture {
 private final float slop,threshold;
 private float startX,startY,distance;
 private boolean candidate,dragging;
 PullToReloadGesture(float slop,float threshold){this.slop=slop;this.threshold=threshold;}
 void start(float x,float y,boolean eligible){cancel();candidate=eligible;startX=x;startY=y;}
 boolean move(float x,float y){
  if(!candidate)return false;
  float dx=Math.abs(x-startX),dy=y-startY;
  if(!dragging){
   if(dx>slop&&dx>=Math.abs(dy)||dy < -slop){cancel();return false;}
   if(dy>slop&&dy>dx)dragging=true;
  }
  distance=Math.max(0,dy);return dragging;
 }
 boolean ready(){return dragging&&distance>=threshold;}
 boolean finish(){boolean reload=ready();cancel();return reload;}
 void cancel(){candidate=false;dragging=false;distance=0;}
}
