package kr.keymate.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import java.io.*;
import java.time.LocalDate;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.BooleanSupplier;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

/** User-selected documents only; never requests broad storage access. */
final class BackupDocuments implements AutoCloseable {
 private static final int EXPORT=710,IMPORT=711;
 private final Activity activity;
 private final Supplier<Playlists> current;
 private final Supplier<SongNotes> notes;
 private final BooleanSupplier readable;
 private final BiConsumer<Playlists,SongNotes> restored;
 private final ExecutorService io=Executors.newSingleThreadExecutor();
 private volatile boolean closed;
 private AlertDialog dialog;
 private boolean exportPending;
 private File exportSnapshot(){return new File(activity.getCacheDir(),"singkey-backup-pending.txt");}
 BackupDocuments(Activity activity,Supplier<Playlists> current,Supplier<SongNotes> notes,BooleanSupplier readable,BiConsumer<Playlists,SongNotes> restored){this.activity=activity;this.current=current;this.notes=notes;this.readable=readable;this.restored=restored;}
 void exportFile(){
  if(!readable.getAsBoolean()){message(R.string.backup_failed);return;}
  try {byte[] bytes=LibraryBackup.encode(current.get(),notes.get());try(OutputStream out=new FileOutputStream(exportSnapshot())){out.write(bytes);}exportPending=true;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/octet-stream").putExtra(Intent.EXTRA_TITLE,"Naekiro-"+LocalDate.now()+".naekiro");activity.startActivityForResult(intent,EXPORT);}
  catch(Exception e){exportPending=false;exportSnapshot().delete();message(R.string.backup_failed);}
 }
 void importFile(){
  try{activity.startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),IMPORT);}
  catch(Exception e){message(R.string.restore_failed);}
 }
 void save(Bundle state){state.putBoolean("backupExportPending",exportPending);}
 void restoreState(Bundle state){if(state!=null)exportPending=state.getBoolean("backupExportPending",false);}
 boolean result(int request,int result,Intent intent){
  if(request!=EXPORT&&request!=IMPORT)return false;
  if(result!=Activity.RESULT_OK||intent==null||intent.getData()==null){if(request==EXPORT){exportPending=false;exportSnapshot().delete();}return true;}
  Uri uri=intent.getData();
  if(!"content".equals(uri.getScheme())){message(request==EXPORT?R.string.backup_failed:R.string.restore_failed);return true;}
  busy();boolean pending=exportPending;exportPending=false;
  io.execute(()->{
   try {
    if(request==EXPORT){
     if(!pending)throw new IOException("Missing snapshot");
     byte[] bytes;try(InputStream in=new FileInputStream(exportSnapshot())){LibraryBackup.Data data=LibraryBackup.readData(in);bytes=LibraryBackup.encode(data.lists,data.notes);}
     try(OutputStream out=activity.getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("No output");out.write(bytes);out.flush();}
     exportSnapshot().delete();post(()->{dismiss();message(R.string.backup_complete);});
    }else{
     LibraryBackup.Data imported;try(InputStream in=activity.getContentResolver().openInputStream(uri)){imported=LibraryBackup.readData(in);}
     post(()->{dismiss();preview(imported);});
    }
   }catch(Exception e){post(()->{dismiss();message(request==EXPORT?R.string.backup_failed:R.string.restore_failed);});}
  });return true;
 }
 private void preview(LibraryBackup.Data imported){
  if(imported.lists.entries().isEmpty()&&imported.notes.entries().isEmpty()){message(R.string.restore_empty);return;}
  if(!readable.getAsBoolean()){message(R.string.restore_unreadable);return;}
  String preview=imported.notes.entries().isEmpty()?activity.getString(R.string.restore_preview,imported.lists.entries().size(),LibraryBackup.songs(imported.lists)):activity.getString(R.string.restore_notes_preview,imported.lists.entries().size(),LibraryBackup.songs(imported.lists),imported.notes.entries().size());
  dialog=new AppDialog(activity).setTitle(R.string.backup_import).setMessage(preview)
   .setNegativeButton(R.string.cancel,null).setPositiveButton(R.string.restore_add,(d,w)->merge(imported)).show();
 }
 private void merge(LibraryBackup.Data imported){
  try {
   if(!readable.getAsBoolean()){message(R.string.restore_unreadable);return;}
   String before=current.get().encode();SongNotes beforeNotes=notes.get();busy();
   io.execute(()->{
    try{
     Playlists merged=LibraryBackup.merge(Playlists.restore(before,""),imported.lists,activity.getString(R.string.restored_suffix));String encoded=merged.encode();
     SongNotes mergedNotes=SongNotes.merge(beforeNotes,imported.notes);String encodedNotes=mergedNotes.encode();
     boolean success;
     // Finish an already-started commit before recreation can load the next activity's library.
     synchronized(this){if(closed)return;success=activity.getPreferences(Activity.MODE_PRIVATE).edit().putString("playlists",encoded).putString(SongNotesUi.PREF,encodedNotes).commit();}
     post(()->{dismiss();if(success){restored.accept(merged,mergedNotes);message(R.string.restore_complete);}else message(R.string.restore_failed);});
    }catch(Exception e){post(()->{dismiss();message(R.string.restore_failed);});}
   });
  }catch(IOException e){message(R.string.restore_failed);}
 }
 private void busy(){dismiss();dialog=new AppDialog(activity).setMessage(R.string.file_working).setCancelable(false).show();}
 private void message(int id){if(!closed&&!activity.isFinishing())dialog=new AppDialog(activity).setMessage(id).setPositiveButton(android.R.string.ok,null).show();}
 private void dismiss(){if(dialog!=null){dialog.dismiss();dialog=null;}}
 private void post(Runnable task){activity.runOnUiThread(()->{if(!closed&&!activity.isDestroyed())task.run();});}
 @Override public void close(){synchronized(this){closed=true;}dismiss();io.shutdownNow();}
}
