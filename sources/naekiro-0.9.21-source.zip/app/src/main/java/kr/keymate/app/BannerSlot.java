package kr.keymate.app;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import com.google.android.libraries.ads.mobile.sdk.MobileAds;
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig;
import com.google.android.libraries.ads.mobile.sdk.banner.*;
import com.google.android.libraries.ads.mobile.sdk.common.*;
import java.util.concurrent.CompletableFuture;

/** Owns a single visible placement. Pending results from old screens are always destroyed. */
final class BannerSlot extends FrameLayout {
 private static CompletableFuture<Void> initialized;
 private final Activity activity;
 private final String unitId,placement;
 private final UsageAnalytics analytics;
 private final Runnable sizeChanged;
 private BannerAd banner;
 private boolean active,destroyed;
 private int request,widthDp;
 private final Runnable resize=this::load;
 BannerSlot(Activity activity,String unitId,String placement,UsageAnalytics analytics,Runnable sizeChanged){
  super(activity);this.activity=activity;this.unitId=unitId;this.placement=placement;this.analytics=analytics;this.sizeChanged=sizeChanged;
  setVisibility(GONE);setBackgroundColor(SingKeyUi.NAVY);
  addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{if(active&&r-l!=or-ol){removeCallbacks(resize);postDelayed(resize,250);}if(b-t!=ob-ot)sizeChanged.run();});
 }
 void active(boolean value){
  value=value&&BuildConfig.ADS_ENABLED;
  if(destroyed||active==value)return;active=value;
  if(!value){clear();setVisibility(GONE);}else{setVisibility(VISIBLE);post(resize);}
 }
 private static synchronized CompletableFuture<Void> initialize(Activity activity){
  if(initialized==null){
   initialized=new CompletableFuture<>();CompletableFuture<Void> pending=initialized;
   new Thread(()->{try{MobileAds.initialize(activity.getApplicationContext(),new InitializationConfig.Builder(activity.getString(R.string.admob_app_id)).build(),status->pending.complete(null));}catch(RuntimeException error){pending.completeExceptionally(error);}},"SingKeyAdsInit").start();
  }
  return initialized;
 }
 private void load(){
  if(!BuildConfig.ADS_ENABLED||!active||destroyed||activity.isDestroyed())return;
  int available=(int)(getWidth()/getResources().getDisplayMetrics().density);
  if(available<200||available==widthDp)return;
  clear();widthDp=available;int ticket=request;
  AdSize size=AdSize.getInlineAdaptiveBannerAdSize(available,placement.equals("home")?100:50);
  initialize(activity).whenComplete((nothing,error)->activity.runOnUiThread(()->{
   if(stale(ticket))return;
   if(error!=null){failed(ticket);return;}
   BannerAd.load(new BannerAdRequest.Builder(unitId,size).build(),new AdLoadCallback<BannerAd>(){
    @Override public void onAdLoaded(BannerAd ad){activity.runOnUiThread(()->{
     if(stale(ticket)){ad.destroy();return;}
     banner=ad;
     ad.setAdEventCallback(new BannerAdEventCallback(){@Override public void onAdImpression(){activity.runOnUiThread(()->{if(!stale(ticket))analytics.record(UsageEvent.ad(placement,true));});}});
     View view=ad.getView(activity);
     setPadding(0,placement.equals("player")?dp(36):placement.equals("home")?dp(16):0,0,placement.equals("player")?dp(36):dp(16));
     addView(view,new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER));requestLayout();sizeChanged.run();
    });}
    @Override public void onAdFailedToLoad(LoadAdError error){if(BuildConfig.DEBUG)android.util.Log.d("SingKeyAds",placement+": "+error);activity.runOnUiThread(()->failed(ticket));}
   });
  }));
 }
 private boolean stale(int ticket){return destroyed||!active||activity.isDestroyed()||ticket!=request;}
 private void failed(int ticket){if(stale(ticket))return;analytics.record(UsageEvent.ad(placement,false));setPadding(0,0,0,0);removeAllViews();sizeChanged.run();}
 private void clear(){request++;removeCallbacks(resize);if(banner!=null){banner.destroy();banner=null;}removeAllViews();setPadding(0,0,0,0);widthDp=0;sizeChanged.run();}
 void destroy(){active=false;destroyed=true;clear();}
 private int dp(int value){return SingKeyUi.dp(activity,value);}
}
