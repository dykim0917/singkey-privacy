package kr.keymate.app;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import okhttp3.HttpUrl;

/** OAuth lives in the system browser. An expiring nonce and PKCE bind the return to this app. */
final class CommunityOAuth {
 static String random(){byte[] bytes=new byte[32];new SecureRandom().nextBytes(bytes);return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);}
 static String challenge(String verifier){try{return Base64.getUrlEncoder().withoutPadding().encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));}catch(NoSuchAlgorithmException e){throw new AssertionError(e);}}
 static String authorize(String base,String provider,String app,String nonce,String verifier)throws IOException{
  if(!Arrays.asList("google","kakao").contains(provider)||!nonce.matches("[A-Za-z0-9_-]{43}")||!verifier.matches("[A-Za-z0-9_-]{43}"))throw new IOException("Invalid OAuth request");
  HttpUrl url=HttpUrl.parse(base);if(url==null||!url.isHttps()||!url.encodedPath().equals("/")||!url.username().isEmpty()||!url.password().isEmpty()||url.query()!=null||url.fragment()!=null)throw new IOException("Invalid service URL");
  HttpUrl.Builder request=url.newBuilder().addPathSegments("auth/v1/authorize").addQueryParameter("provider",provider).addQueryParameter("redirect_to",app+".auth://callback/"+nonce).addQueryParameter("code_challenge",challenge(verifier)).addQueryParameter("code_challenge_method","s256");
  // "scope" is forwarded to Kakao; "scopes" would append to Supabase's broader defaults.
  if(provider.equals("kakao"))request.addQueryParameter("scope","profile_nickname");
  return request.build().toString();
 }
 static String code(String callback,String app,String nonce,long started,long now)throws IOException{
  try{URI uri=URI.create(callback);
   if(nonce==null||!nonce.matches("[A-Za-z0-9_-]{43}")||now<started||now-started>600_000||!(app+".auth").equals(uri.getScheme())||!"callback".equals(uri.getHost())||uri.getPort()!=-1||uri.getRawUserInfo()!=null||!("/"+nonce).equals(uri.getRawPath())||uri.getRawFragment()!=null)throw new IOException("Invalid callback");
   String found=null;for(String p:Objects.toString(uri.getRawQuery(),"").split("&")){String[] pair=p.split("=",2);if(pair[0].equals("code")){if(found!=null||pair.length!=2)throw new IOException("Invalid code");found=java.net.URLDecoder.decode(pair[1],"UTF-8");}if(pair[0].equals("error"))throw new IOException("Login cancelled");}
   if(found==null||!found.matches("[A-Za-z0-9_-]{10,512}"))throw new IOException("Missing code");return found;
  }catch(IllegalArgumentException e){throw new IOException("Invalid callback",e);}
 }
 private CommunityOAuth(){}
}
