package kr.keymate.app;

import java.io.IOException;

/** Only explicit IFrame embedding denials are remembered as video restrictions. */
final class YouTubePlaybackException extends IOException {
 final int code;
 YouTubePlaybackException(int code){super("YouTube playback error "+code);this.code=code;}
 boolean embedBlocked(){return code==101||code==150;}
 static boolean embedBlocked(Exception error){return error instanceof YouTubePlaybackException&&((YouTubePlaybackException)error).embedBlocked();}
}
