package kr.keymate.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.util.ArrayList;
import java.util.List;

/** Shared presentation for app-owned dialogs. Keeps native actions and callbacks. */
final class AppDialog extends AlertDialog.Builder {
 private final Activity activity;
 private CharSequence title;
 private boolean primaryPositive=true;
 private int destructiveButton;
 AppDialog(Activity activity){super(activity);this.activity=activity;}
 AppDialog equalActions(){primaryPositive=false;return this;}
 AppDialog destructive(int which){destructiveButton=which;return this;}
 @Override public AppDialog setTitle(int res){return setTitle(activity.getText(res));}
 @Override public AppDialog setTitle(CharSequence value){title=value;super.setTitle(value);return this;}
 @Override public AlertDialog create(){
  if(title!=null){TextView heading=SingKeyUi.heading(activity,title.toString(),20);heading.setPadding(dp(activity,24),dp(activity,22),dp(activity,24),dp(activity,12));heading.setMaxLines(3);heading.setEllipsize(android.text.TextUtils.TruncateAt.END);if(android.os.Build.VERSION.SDK_INT>=28)heading.setAccessibilityHeading(true);setCustomTitle(heading);}
  AlertDialog dialog=super.create();dialog.setOnShowListener(d->style(activity,dialog,primaryPositive,destructiveButton));return dialog;
 }
 @Override public AlertDialog show(){AlertDialog dialog=create();dialog.show();return dialog;}
 private static int dp(Context c,int value){return SingKeyUi.dp(c,value);}
 static void resize(Activity a,AlertDialog dialog){if(dialog.getWindow()!=null){int width=Math.min(a.getResources().getDisplayMetrics().widthPixels-dp(a,32),dp(a,560));if(dialog.getWindow().getAttributes().width!=width)dialog.getWindow().setLayout(width,ViewGroup.LayoutParams.WRAP_CONTENT);}}
 private static void style(Activity a,AlertDialog dialog,boolean primaryPositive,int destructiveButton){
  Window window=dialog.getWindow();if(window==null)return;
  window.setBackgroundDrawable(SingKeyUi.outline(a,SingKeyUi.SURFACE,20,0xff29313e));window.setDimAmount(.64f);window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
  window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);resize(a,dialog);
  TextView message=dialog.findViewById(android.R.id.message);if(message!=null){message.setTextSize(16);message.setTextColor(SingKeyUi.INK);message.setLineSpacing(dp(a,4),1f);}
  ListView list=dialog.getListView();if(list!=null){list.setDivider(null);list.setPadding(dp(a,8),0,dp(a,8),0);list.setSelector(SingKeyUi.shape(a,0x24ccff00,10));}
  List<Button> buttons=new ArrayList<>();
  for(int which:new int[]{AlertDialog.BUTTON_NEUTRAL,AlertDialog.BUTTON_NEGATIVE,AlertDialog.BUTTON_POSITIVE}){
   Button b=dialog.getButton(which);if(b==null||b.getVisibility()!=View.VISIBLE)continue;
   b.setTextSize(14);b.setAllCaps(false);b.setMaxLines(3);b.setEllipsize(null);b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(dp(a,48));b.setMinimumHeight(dp(a,48));b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));b.setStateListAnimator(null);
   SingKeyUi.setButtonEmphasis(b,primaryPositive&&which==AlertDialog.BUTTON_POSITIVE&&which!=destructiveButton);if(which==destructiveButton)b.setTextColor(0xffffaaa3);b.setPadding(dp(a,12),dp(a,10),dp(a,12),dp(a,10));buttons.add(b);
  }
  if(!buttons.isEmpty()&&buttons.get(0).getParent() instanceof LinearLayout){
   LinearLayout original=(LinearLayout)buttons.get(0).getParent();boolean common=true;for(Button b:buttons)common&=b.getParent()==original;
   if(common){
    // The platform button bar reverses stacked children and reserves only one row.
    // Keep the native Button instances/callbacks, but measure our entire action area.
    ViewGroup parent=(ViewGroup)original.getParent();int index=parent.indexOfChild(original);ViewGroup.LayoutParams params=original.getLayoutParams();
    LinearLayout panel=new ActionPanel(a);panel.setId(original.getId());original.removeAllViews();parent.removeView(original);parent.addView(panel,index,params);
    panel.setGravity(Gravity.END);panel.setPadding(dp(a,20),dp(a,10),dp(a,20),dp(a,16));for(Button b:buttons)panel.addView(b);layoutActions(a,panel);
    window.getDecorView().addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{resize(a,dialog);layoutActions(a,panel);});
   }
  }
 }
 private static void layoutActions(Activity a,LinearLayout panel){
  boolean stacked=a.getResources().getConfiguration().fontScale>1.3f&&a.getResources().getConfiguration().screenWidthDp<600;
  int orientation=stacked?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL;
  if(panel.getTag()!=null&&panel.getOrientation()==orientation)return;
  panel.setTag(Boolean.TRUE);panel.setOrientation(orientation);
  for(int i=0;i<panel.getChildCount();i++){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(stacked?-1:0,-2,stacked?0:1);if(i>0){if(stacked)lp.topMargin=dp(a,4);else lp.leftMargin=dp(a,4);}panel.getChildAt(i).setLayoutParams(lp);}
 }
 static LinearLayout body(Context c){LinearLayout body=new LinearLayout(c);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(c,24),dp(c,4),dp(c,24),dp(c,16));return body;}
 static ScrollView scroll(Context c,View body){ScrollView scroll=new ContentScroll(c);scroll.setFillViewport(false);scroll.setClipToPadding(false);scroll.addView(body);return scroll;}
 static void space(LinearLayout body,int gap){for(int i=0;i<body.getChildCount();i++){View child=body.getChildAt(i);ViewGroup.LayoutParams current=child.getLayoutParams();LinearLayout.LayoutParams lp=current instanceof LinearLayout.LayoutParams?new LinearLayout.LayoutParams((LinearLayout.LayoutParams)current):new LinearLayout.LayoutParams(-1,-2);if(lp.width!=lp.height||lp.width<0)lp.width=-1;if(i>0)lp.topMargin=Math.max(lp.topMargin,dp(body.getContext(),gap));child.setLayoutParams(lp);}}
 static void fieldLabel(LinearLayout body,int label,EditText field){TextView title=SingKeyUi.heading(body.getContext(),body.getContext().getString(label),14);field.setId(View.generateViewId());title.setLabelFor(field.getId());body.addView(title);}
 static void choice(CompoundButton button){Context c=button.getContext();button.setTextSize(15);button.setTextColor(SingKeyUi.INK);button.setMinHeight(dp(c,48));button.setPadding(dp(c,8),dp(c,8),dp(c,8),dp(c,8));button.setCompoundDrawablePadding(dp(c,8));button.setButtonTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked},{}},new int[]{SingKeyUi.MINT,SingKeyUi.MUTED}));}
 static Button quiet(Context c,String text,View.OnClickListener click){Button b=SingKeyUi.button(c,text,click,false);b.setBackgroundColor(Color.TRANSPARENT);b.setTextColor(SingKeyUi.MUTED);SingKeyUi.feedback(b,10);return b;}
 private static final class ActionPanel extends LinearLayout {
  ActionPanel(Context c){super(c);}
  @Override protected void onMeasure(int widthSpec,int heightSpec){super.onMeasure(widthSpec,heightSpec);if(MeasureSpec.getMode(heightSpec)==MeasureSpec.UNSPECIFIED)setMinimumHeight(getMeasuredHeight());}
 }
 private static final class ContentScroll extends ScrollView {
  ContentScroll(Context c){super(c);}
  @Override protected void onMeasure(int widthSpec,int heightSpec){int limit=(int)(getResources().getDisplayMetrics().heightPixels*.60f);int available=MeasureSpec.getMode(heightSpec)==MeasureSpec.UNSPECIFIED?limit:Math.min(limit,MeasureSpec.getSize(heightSpec));super.onMeasure(widthSpec,MeasureSpec.makeMeasureSpec(available,MeasureSpec.AT_MOST));}
  @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);if(h<oldh)post(()->{View focus=findFocus();if(focus instanceof EditText){Rect rect=new Rect();focus.getDrawingRect(rect);focus.requestRectangleOnScreen(rect,true);}});}
 }
}
