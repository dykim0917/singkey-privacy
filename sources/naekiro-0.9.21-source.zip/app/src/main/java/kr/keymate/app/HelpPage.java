package kr.keymate.app;

import android.content.Context;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;


/** Offline guide kept alongside the native UI it describes. */
final class HelpPage {

 static void populate(LinearLayout page, Runnable search) {
  Context context = page.getContext();
  TextView subtitle = SingKeyUi.label(context, context.getString(R.string.help_subtitle), 14, true);
  subtitle.setPadding(0, dp(context, 8), 0, dp(context, 20));
  page.addView(subtitle);

  LinearLayout start = SingKeyUi.card(context);
  start.addView(heading(context, context.getString(R.string.help_start), 17));
  step(start, "1", context.getString(R.string.help_step_search), context.getString(R.string.help_step_search_body));
  step(start, "2", context.getString(R.string.help_step_key), context.getString(R.string.help_step_key_body));
  step(start, "3", context.getString(R.string.help_step_save), context.getString(R.string.help_step_save_body));
  page.addView(start);
  Button searchButton = SingKeyUi.button(context, context.getString(R.string.help_search_button), v -> search.run(), true);
  searchButton.setMaxLines(Integer.MAX_VALUE);
  page.addView(searchButton, new LinearLayout.LayoutParams(-1, -2));

  TextView questions = heading(context, context.getString(R.string.help_questions), 18);
  questions.setPadding(0, dp(context, 24), 0, dp(context, 12));
  page.addView(questions);

  question(page, context.getString(R.string.help_search_title), context.getString(R.string.help_search_body));
  question(page, context.getString(R.string.help_key_title), context.getString(R.string.help_key_body));
  question(page, context.getString(R.string.help_save_title), context.getString(R.string.help_save_body));
  question(page, context.getString(R.string.help_modes_title), context.getString(R.string.help_modes_body));
  question(page, context.getString(R.string.help_queue_title), context.getString(R.string.help_queue_body));
  question(page, context.getString(R.string.help_troubleshooting_title), context.getString(R.string.help_troubleshooting_body));
  question(page, context.getString(R.string.help_chart_title), context.getString(R.string.help_chart_body));


 }

 private static void step(LinearLayout card, String number, String title, String body) {
  Context context = card.getContext();
  LinearLayout row = new LinearLayout(context);
  row.setOrientation(LinearLayout.HORIZONTAL);
  row.setPadding(0, dp(context, 16), 0, 0);
  TextView index = heading(context, number, 16);
  index.setTextColor(SingKeyUi.MINT);
  index.setPadding(0, 0, dp(context, 12), 0);
  row.addView(index, new LinearLayout.LayoutParams(-2, -2));
  LinearLayout text = new LinearLayout(context);
  text.setOrientation(LinearLayout.VERTICAL);
  text.addView(heading(context, title, 15));
  TextView description = SingKeyUi.label(context, body, 14, true);
  description.setPadding(0, dp(context, 4), 0, 0);
  text.addView(description);
  row.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
  card.addView(row);
 }

 private static void question(LinearLayout page, String title, String answer) {
  Context context = page.getContext();
  LinearLayout card = SingKeyUi.card(context);
  card.setPadding(0, 0, 0, 0);
  TextView body = SingKeyUi.label(context, answer, 15, false);
  body.setPadding(dp(context, 16), 0, dp(context, 16), dp(context, 16));
  body.setVisibility(View.GONE);
  Button toggle = SingKeyUi.button(context, title, null, false);
  toggle.setTextSize(16);
  toggle.setMaxLines(Integer.MAX_VALUE);
  toggle.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
  toggle.setBackgroundColor(0);
  SingKeyUi.feedback(toggle, 14);
  toggle.setPadding(dp(context, 16), dp(context, 16), dp(context, 16), dp(context, 16));
  toggle.setMinimumHeight(dp(context, 56));
  toggle.setCompoundDrawablePadding(dp(context, 12));
  updateToggle(toggle, title, false);
  toggle.setOnClickListener(v -> {
   boolean expanded = body.getVisibility() != View.VISIBLE;
   body.setVisibility(expanded ? View.VISIBLE : View.GONE);
   updateToggle(toggle, title, expanded);
  });
  card.addView(toggle, new LinearLayout.LayoutParams(-1, -2));
  card.addView(body, new LinearLayout.LayoutParams(-1, -2));
  page.addView(card);
 }

 private static void updateToggle(Button button, String title, boolean expanded) {
  button.setCompoundDrawablesRelative(null, null, SingKeyUi.icon(button.getContext(),
    expanded ? R.drawable.ic_sk_up : R.drawable.ic_sk_down, SingKeyUi.MUTED, 20), null);
  if (Build.VERSION.SDK_INT >= 30) {
   button.setContentDescription(title);
   button.setStateDescription(button.getContext().getString(expanded ? R.string.expanded : R.string.collapsed));
  } else button.setContentDescription(button.getContext().getString(expanded ? R.string.collapse_section : R.string.expand_section, title));
 }

 private static TextView heading(Context context, String text, int size) {
  TextView view = SingKeyUi.heading(context, text, size);
  if (Build.VERSION.SDK_INT >= 28) view.setAccessibilityHeading(true);
  return view;
 }

 private static int dp(Context context, int value) { return SingKeyUi.dp(context, value); }
}
