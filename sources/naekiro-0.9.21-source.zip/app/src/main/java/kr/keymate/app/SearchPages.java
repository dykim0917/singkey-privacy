package kr.keymate.app;
import java.util.*;
/** Request tickets isolate queries, pagination retries and closed/rotated screens. */
final class SearchPages {
 static final int LIMIT=200;
 private long serial;
 private final List<Song> songs=new ArrayList<>();
 private final Set<String> seenCursors=new HashSet<>();
 private YouTubeSearchPage.Cursor next;
 boolean busy,failed,loaded;
 int excluded;
 static final class Ticket {final long serial;final YouTubeSearchPage.Cursor cursor;Ticket(long serial,YouTubeSearchPage.Cursor cursor){this.serial=serial;this.cursor=cursor;}}
 Ticket first(){invalidate();songs.clear();excluded=0;seenCursors.clear();next=null;loaded=false;busy=true;return new Ticket(serial,null);}
 Ticket more(){if(busy||!hasMore())return null;busy=true;failed=false;return new Ticket(++serial,next);}
 boolean complete(Ticket ticket,YouTubeSearchPage.Page page){if(ticket==null||ticket.serial!=serial||!busy)return false;excluded+=page.excluded;Set<String> urls=new HashSet<>();for(Song song:songs)urls.add(song.url);for(Song song:page.songs){if(songs.size()>=LIMIT)break;String canonical=SearchSafety.canonicalVideo(song.url);if(canonical!=null&&urls.add(canonical))songs.add(song);}if(ticket.cursor!=null)seenCursors.add(ticket.cursor.token);next=page.next;if(next!=null&&seenCursors.contains(next.token))next=null;busy=false;failed=false;loaded=true;return true;}
 boolean fail(Ticket ticket){if(ticket==null||ticket.serial!=serial||!busy)return false;busy=false;failed=true;return true;}
 void invalidate(){serial++;busy=false;failed=false;}
 void clear(){invalidate();songs.clear();excluded=0;next=null;loaded=false;seenCursors.clear();}
 boolean hasMore(){return next!=null&&songs.size()<LIMIT;}
 List<Song> songs(){return Collections.unmodifiableList(songs);}
 void retain(java.util.function.Predicate<Song> keep){int before=songs.size();songs.removeIf(song->!keep.test(song));excluded+=before-songs.size();}
}
