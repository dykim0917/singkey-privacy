package kr.keymate.app;

import java.util.*;

/** Local facts only. Playlist order is stable; it is not a saved-at timestamp. */
final class PracticeRecommendations {
 enum Reason { COMFORTABLE, LONG_AGO, SAVED }
 static final long FORTNIGHT=14L*24*60*60*1000;
 static final class Pick {
  final SavedSongs.Entry saved;
  final Reason reason;
  final SongNotes.Entry rating;
  final long playedAt;
  Pick(SavedSongs.Entry saved,Reason reason,SongNotes.Entry rating,long playedAt){this.saved=saved;this.reason=reason;this.rating=rating;this.playedAt=playedAt;}
 }
 private final LinkedHashMap<String,Pick> candidates=new LinkedHashMap<>();
 private final List<String> selected=new ArrayList<>();
 private final Set<String> seen=new LinkedHashSet<>();
 private String facts="";
 private boolean restored;
 void restore(List<String> selection,List<String> previous){if(selection!=null)selected.addAll(selection);if(previous!=null)seen.addAll(previous);restored=true;}
 ArrayList<String> selection(){return new ArrayList<>(selected);}
 ArrayList<String> seen(){return new ArrayList<>(seen);}
 List<Pick> update(Playlists library,SongNotes notes,RecentSongs recent,boolean historyEnabled,long now){
  candidates.clear();StringBuilder signature=new StringBuilder();
  for(Playlists.ListEntry list:library.entries())for(SavedSongs.Entry saved:list.songs.entries()){
   String url=SearchSafety.canonicalVideo(saved.song.url);if(url==null||candidates.containsKey(url))continue;
   SongNotes.Entry rating=notes.find(url);if(rating!=null&&(rating.rating==SongNotes.Rating.NONE||rating.ratedAt<=0||rating.ratedAt>now))rating=null;
   long played=historyEnabled?recent.playedAt(url):0;if(played<=0||played>now)played=0;
   Reason reason=rating!=null&&rating.rating==SongNotes.Rating.COMFORTABLE?Reason.COMFORTABLE:played>0&&now-played>=FORTNIGHT?Reason.LONG_AGO:Reason.SAVED;
   Pick pick=new Pick(saved,reason,rating,played);candidates.put(url,pick);
   signature.append(url).append('/').append(saved.key).append('/').append(reason).append('/').append(played).append('/').append(rating==null?0:rating.ratedAt).append('/').append(rating==null?0:rating.ratingKey).append(';');
  }
  String next=signature.toString();
  if(!next.equals(facts)){
   boolean keepRestore=restored&&selected.size()<=3&&!selected.isEmpty()&&candidates.keySet().containsAll(selected);
   if(!keepRestore){selected.clear();seen.clear();choose();}else{seen.retainAll(candidates.keySet());seen.addAll(selected);}
   facts=next;
  }
  restored=false;return picks();
 }
 boolean hasOther(){for(String url:candidates.keySet())if(!seen.contains(url))return true;return false;}
 List<Pick> other(){if(hasOther()){selected.clear();choose();}return picks();}
 private void choose(){
  for(Reason reason:Reason.values())for(Map.Entry<String,Pick> e:candidates.entrySet())if(e.getValue().reason==reason&&!seen.contains(e.getKey())){add(e.getKey());break;}
  for(Reason reason:Reason.values())for(Map.Entry<String,Pick> e:candidates.entrySet())if(selected.size()<3&&e.getValue().reason==reason&&!seen.contains(e.getKey()))add(e.getKey());
 }
 private void add(String url){if(selected.size()<3){selected.add(url);seen.add(url);}}
 private List<Pick> picks(){List<Pick> result=new ArrayList<>();for(String url:selected){Pick p=candidates.get(url);if(p!=null)result.add(p);}return Collections.unmodifiableList(result);}
}
