package kr.keymate.app;

/** User-selected search exclusion, independent of YouTube's embeddable flag. */
final class SearchChannelPolicy {
 // TJ's official channel, verified with videos.list on 2026-09-30.
 static final String TJ="UCZUhx8ClCv6paFW7qi3qljg";
 static boolean excluded(String channelId){return TJ.equals(channelId);}
 private SearchChannelPolicy(){}
}
