package kr.keymate.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.*;
import android.util.Base64;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Only session/PKCE secrets use this store. No tokens in library backups or logs. */
final class CommunitySecrets {
 private final SharedPreferences prefs;private final String alias;
 CommunitySecrets(Context c){prefs=c.getSharedPreferences("community_secrets",Context.MODE_PRIVATE);alias=c.getPackageName()+".community";}
 private javax.crypto.SecretKey key()throws Exception{KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);if(store.containsAlias(alias))return (javax.crypto.SecretKey)store.getKey(alias,null);KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");generator.init(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return generator.generateKey();}
 synchronized String read(String name)throws IOException{String raw=prefs.getString(name,null);if(raw==null)return null;try{String[] parts=raw.split(":",-1);if(parts.length!=2)throw new IOException("Invalid secret");Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));c.updateAAD(name.getBytes(StandardCharsets.UTF_8));return new String(c.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);}catch(Exception e){throw new IOException("Cannot read session",e);}}
 synchronized void write(String name,String value)throws IOException{try{SharedPreferences.Editor edit=prefs.edit();if(value==null)edit.remove(name);else{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());c.updateAAD(name.getBytes(StandardCharsets.UTF_8));edit.putString(name,Base64.encodeToString(c.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(c.doFinal(value.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP));}if(!edit.commit())throw new IOException("Cannot save session");}catch(Exception e){throw new IOException("Cannot save session",e);}}
}
