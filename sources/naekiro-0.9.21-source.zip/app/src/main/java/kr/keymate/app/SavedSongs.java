package kr.keymate.app;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

/** Device-local song bookmarks. Persist stable video URLs, never media streams. */
final class SavedSongs {
 static final class Entry {
  final Song song;
  final int key;
  Entry(Song song, int key) { this.song = song; this.key = KeyMath.clamp(key); }
 }
 private final ArrayList<Entry> entries = new ArrayList<>();
 List<Entry> entries() { return Collections.unmodifiableList(entries); }
 Entry find(String url) {
  String id = identity(url);
  for (Entry entry : entries) if (identity(entry.song.url).equals(id)) return entry;
  return null;
 }
 void save(Song song, int key) {
  remove(song.url);
  entries.add(0, new Entry(song, key));
 }
 void saveInOrder(Song song, int key) {
  Entry previous = find(song.url);
  int index = previous == null ? entries.size() : entries.indexOf(previous);
  if (previous != null) entries.remove(index);
  entries.add(index, new Entry(song, key));
 }
 void remove(String url) { Entry entry = find(url); if (entry != null) entries.remove(entry); }
 String encode() throws IOException {
  Properties data = new Properties();
  data.setProperty("version", "1");
  data.setProperty("count", Integer.toString(entries.size()));
  for (int i = 0; i < entries.size(); i++) {
   Entry entry = entries.get(i); String prefix = i + ".";
   data.setProperty(prefix + "url", entry.song.url);
   data.setProperty(prefix + "title", entry.song.title);
   data.setProperty(prefix + "thumbnail", entry.song.thumbnailUrl);
   data.setProperty(prefix + "key", Integer.toString(entry.key));
  }
  StringWriter out = new StringWriter(); data.store(out, "Keymate saved songs"); return out.toString();
 }
 static SavedSongs decode(String value) throws IOException {
  SavedSongs saved = new SavedSongs();
  if (value == null || value.isEmpty()) return saved;
  Properties data = new Properties();
  try {
   data.load(new StringReader(value));
   if (!"1".equals(data.getProperty("version"))) throw new IOException("Unsupported saved songs version");
   int count = Integer.parseInt(data.getProperty("count"));
   if (count < 0 || count > 10000) throw new IOException("Invalid saved songs count");
   for (int i = 0; i < count; i++) {
    String prefix = i + ".", url = data.getProperty(prefix + "url"), title = data.getProperty(prefix + "title");
    if (url == null || url.isEmpty() || title == null) throw new IOException("Incomplete saved song");
    int key = Integer.parseInt(data.getProperty(prefix + "key"));
    if (saved.find(url) == null) saved.entries.add(new Entry(new Song(url, title, data.getProperty(prefix + "thumbnail", "")), key));
   }
  } catch (IllegalArgumentException e) { throw new IOException("Invalid saved songs", e); }
  return saved;
 }
 private static String identity(String url) {
  try {
   URI uri = URI.create(url); String host = uri.getHost(), path = uri.getPath();
   String id = null;
   if ("youtu.be".equalsIgnoreCase(host) && path != null && path.length() > 1) id = path.substring(1).split("/")[0];
   else if (host != null && (host.equalsIgnoreCase("youtube.com") || host.toLowerCase(java.util.Locale.ROOT).endsWith(".youtube.com"))) {
    if ("/watch".equals(path) && uri.getRawQuery() != null) {
     for (String parameter : uri.getRawQuery().split("&")) if (parameter.startsWith("v=")) { id = parameter.substring(2); break; }
    } else if (path != null && path.matches("/(shorts|embed|live)/[^/]+/?")) id = path.split("/")[2];
   }
   if (id != null && id.matches("[A-Za-z0-9_-]{11}")) return "youtube:" + id;
  } catch (IllegalArgumentException ignored) { }
  return url;
 }
}
