package kr.keymate.app;

import com.grack.nanojson.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import okhttp3.*;

/** Search eligibility from official metadata and local channel policy; no media requests. */
final class YouTubeEmbedStatus implements EmbedAvailability.Checker {
 private static final HttpUrl ENDPOINT=HttpUrl.get("https://www.googleapis.com/youtube/v3/videos");
 private final OkHttpClient client;
 private final HttpUrl endpoint;
 private final String apiKey,packageName,certificate;
 YouTubeEmbedStatus(String key,String packageName,String certificate){this(new OkHttpClient.Builder().followRedirects(false).followSslRedirects(false).callTimeout(6,TimeUnit.SECONDS).build(),ENDPOINT,key,packageName,certificate);}
 // Package-private endpoint injection is for MockWebServer tests only.
 YouTubeEmbedStatus(OkHttpClient client,HttpUrl endpoint,String key,String packageName,String certificate){this.client=client;this.endpoint=endpoint;this.apiKey=key;this.packageName=packageName;this.certificate=certificate;}
 @Override public Map<String,Boolean> check(List<String> ids)throws IOException{
  if(apiKey.isEmpty()||ids.isEmpty())return Collections.emptyMap();
  if(ids.size()>50||!ids.stream().allMatch(EmbedAvailability::validId))throw new IOException("Invalid video IDs");
  if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();
  HttpUrl url=endpoint.newBuilder().addQueryParameter("part","status,snippet").addQueryParameter("id",String.join(",",ids)).addQueryParameter("fields","items(id,status/embeddable,snippet/channelId)").build();
  Request request=new Request.Builder().url(url).header("X-Goog-Api-Key",apiKey).header("X-Android-Package",packageName).header("X-Android-Cert",certificate).build();
  try(Response response=client.newCall(request).execute()){
   if(response.code()!=200||response.body()==null)throw new IOException("YouTube status unavailable ("+response.code()+")");
   String body=HttpDownloader.boundedBody(response.body(),64*1024);
   if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();
   return parse(body,new HashSet<>(ids));
  }
 }
 static Map<String,Boolean> parse(String json,Set<String> requested)throws IOException{
  if(json==null||json.length()>64*1024)throw new IOException("Invalid YouTube status");
  try{
   JsonObject root=JsonParser.object().from(json);
   if(!(root.get("items") instanceof JsonArray)||root.containsKey("error"))throw new IOException("Missing YouTube status");
   JsonArray items=(JsonArray)root.get("items");
   Map<String,Boolean> result=new HashMap<>();
   for(Object item:items){
    if(!(item instanceof JsonObject))continue;JsonObject video=(JsonObject)item;String id=video.getString("id");
    if(!requested.contains(id))continue;
    JsonObject snippet=video.getObject("snippet"),status=video.getObject("status");
    if(snippet!=null&&SearchChannelPolicy.excluded(snippet.getString("channelId")))result.put(id,false);
    else if(status!=null&&status.get("embeddable") instanceof Boolean)result.put(id,(Boolean)status.get("embeddable"));
   }
   return result;
  }catch(JsonParserException error){throw new IOException("Invalid YouTube status",error);}
 }
}
