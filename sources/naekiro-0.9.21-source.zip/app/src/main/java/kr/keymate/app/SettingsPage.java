package kr.keymate.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.res.ColorStateList;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

final class SettingsPage {
 static void populate(LinearLayout page,String language,Runnable chooseLanguage) {
  page.removeAllViews();Activity c=(Activity)page.getContext();
  page.addView(SingKeyUi.heading(c,c.getString(R.string.settings),24));
  section(page,R.string.settings_general);
  entry(page,R.string.app_language,language,chooseLanguage);
 }
 static void history(LinearLayout page,boolean history,Consumer<Boolean> recordHistory,Runnable clearHistory,Runnable notes) {
  Activity c=(Activity)page.getContext();
  section(page,R.string.settings_data);
  LinearLayout row=container(page);
  LinearLayout text=text(row,c.getString(R.string.history_record),"");row.addView(text,new LinearLayout.LayoutParams(0,-2,1));
  Switch toggle=new Switch(c);toggle.setChecked(history);toggle.setContentDescription(c.getString(R.string.history_record));
  toggle.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked},{}},new int[]{SingKeyUi.MINT,SingKeyUi.MUTED}));
  toggle.setMinimumHeight(SingKeyUi.dp(c,48));row.addView(toggle);row.setOnClickListener(v->toggle.setChecked(!toggle.isChecked()));
  toggle.setOnCheckedChangeListener((v,checked)->recordHistory.accept(checked));page.addView(row);divider(page);
  entry(page,R.string.history_clear,"",clearHistory);
  entry(page,R.string.notes_title,"",notes);
 }
 static void support(LinearLayout page,Runnable guide,Runnable contact,Runnable info) {
  Activity c=(Activity)page.getContext();
  section(page,R.string.settings_support);
  entry(page,R.string.help_title,"",guide);
  entry(page,R.string.contact_title,"",contact);
  entry(page,R.string.app_info,version(c),info);
 }
 static void account(LinearLayout page,Runnable account){entry(page,R.string.community_account,"",account);}
 static void searchHistory(LinearLayout page,boolean enabled,Consumer<Boolean> change,Runnable clear){
  Activity c=(Activity)page.getContext();LinearLayout row=container(page);row.addView(text(row,c.getString(R.string.search_history_record),""),new LinearLayout.LayoutParams(0,-2,1));Switch toggle=new Switch(c);toggle.setChecked(enabled);toggle.setContentDescription(c.getString(R.string.search_history_record));toggle.setMinimumHeight(SingKeyUi.dp(c,48));toggle.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked},{}},new int[]{SingKeyUi.MINT,SingKeyUi.MUTED}));row.addView(toggle);row.setOnClickListener(v->toggle.setChecked(!toggle.isChecked()));toggle.setOnCheckedChangeListener((v,checked)->change.accept(checked));page.addView(row);divider(page);entry(page,R.string.search_history_clear,"",clear);
 }
 static void recommendations(LinearLayout page,boolean enabled,Consumer<Boolean> change){
  Activity c=(Activity)page.getContext();LinearLayout row=container(page);row.addView(text(row,c.getString(R.string.recommendations_setting),""),new LinearLayout.LayoutParams(0,-2,1));Switch toggle=new Switch(c);toggle.setChecked(enabled);toggle.setContentDescription(c.getString(R.string.recommendations_setting));toggle.setMinimumHeight(SingKeyUi.dp(c,48));toggle.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked},{}},new int[]{SingKeyUi.MINT,SingKeyUi.MUTED}));row.addView(toggle);row.setOnClickListener(v->toggle.setChecked(!toggle.isChecked()));toggle.setOnCheckedChangeListener((v,checked)->change.accept(checked));page.addView(row);divider(page);
 }
 static void contact(LinearLayout page,Runnable back) {
  page.removeAllViews();Activity c=(Activity)page.getContext();header(page,R.string.contact_title,back);
  TextView email=SingKeyUi.label(c,c.getString(R.string.support_email),18,false);
  email.setPadding(0,SingKeyUi.dp(c,24),0,SingKeyUi.dp(c,24));
  email.setTextIsSelectable(true);
  android.text.util.Linkify.addLinks(email,android.text.util.Linkify.EMAIL_ADDRESSES);
  email.setLinkTextColor(SingKeyUi.MINT);
  page.addView(email,new LinearLayout.LayoutParams(-1,-2));
 }
 static void privacy(LinearLayout page,boolean analyticsAvailable,boolean analytics,Consumer<Boolean> toggleAnalytics,Runnable adChoices){
  Activity c=(Activity)page.getContext();section(page,R.string.settings_privacy);
  LinearLayout row=container(page);row.addView(text(row,c.getString(R.string.analytics_setting),analyticsAvailable?"":c.getString(R.string.analytics_unavailable)),new LinearLayout.LayoutParams(0,-2,1));
  Switch toggle=new Switch(c);toggle.setChecked(analyticsAvailable&&analytics);toggle.setContentDescription(c.getString(R.string.analytics_setting));toggle.setMinimumHeight(SingKeyUi.dp(c,48));
  toggle.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked},{}},new int[]{SingKeyUi.MINT,SingKeyUi.MUTED}));row.addView(toggle);
  toggle.setEnabled(analyticsAvailable);row.setEnabled(analyticsAvailable);
  if(analyticsAvailable){row.setOnClickListener(v->toggle.setChecked(!toggle.isChecked()));toggle.setOnCheckedChangeListener((v,checked)->toggleAnalytics.accept(checked));}
  else {toggle.setAlpha(.4f);toggle.setContentDescription(c.getString(R.string.analytics_setting)+". "+c.getString(R.string.analytics_unavailable));}
  page.addView(row);divider(page);
  if(BuildConfig.ADS_ENABLED)entry(page,R.string.ads_privacy,"",adChoices);
 }
 static void information(LinearLayout page,Runnable back,BiConsumer<String,String> legal) {
  page.removeAllViews();Activity c=(Activity)page.getContext();header(page,R.string.app_info,back);
  TextView brand=SingKeyUi.heading(c,c.getString(R.string.app_name),24);brand.setPadding(0,SingKeyUi.dp(c,20),0,SingKeyUi.dp(c,8));page.addView(brand);
  TextView detail=SingKeyUi.label(c,c.getString(R.string.developer_app_version,version(c)),14,true);detail.setPadding(0,0,0,SingKeyUi.dp(c,18));page.addView(detail);
  entry(page,R.string.copy_app_info,"",()->{
   ClipboardManager clipboard=c.getSystemService(ClipboardManager.class);
   if(clipboard!=null){clipboard.setPrimaryClip(ClipData.newPlainText(c.getString(R.string.app_name),c.getString(R.string.developer_app_version,version(c))+"\nAndroid "+android.os.Build.VERSION.RELEASE));if(android.os.Build.VERSION.SDK_INT<33)Toast.makeText(c,R.string.app_info_copied,Toast.LENGTH_SHORT).show();}
  });
  entry(page,R.string.privacy,"",()->legal.accept(c.getString(R.string.privacy),"privacy.txt"));
  entry(page,R.string.open_source,"",()->legal.accept(c.getString(R.string.open_source),"open-source.txt"));
 }
 static String version(Activity c){try{return c.getPackageManager().getPackageInfo(c.getPackageName(),0).versionName;}catch(Exception e){return "";}}
 static void header(LinearLayout page,int title,Runnable back){
  Activity c=(Activity)page.getContext();LinearLayout row=new LinearLayout(c);row.setGravity(Gravity.CENTER_VERTICAL);
  row.addView(SingKeyUi.iconButton(c,R.drawable.ic_sk_back,c.getString(R.string.navigate_back),v->back.run()));
  row.addView(SingKeyUi.heading(c,c.getString(title),22),new LinearLayout.LayoutParams(0,-2,1));page.addView(row);
 }
 private static void section(LinearLayout page,int name){Activity c=(Activity)page.getContext();TextView heading=SingKeyUi.label(c,c.getString(name),14,true);heading.setPadding(0,SingKeyUi.dp(c,24),0,SingKeyUi.dp(c,10));if(android.os.Build.VERSION.SDK_INT>=28)heading.setAccessibilityHeading(true);page.addView(heading);}
 private static LinearLayout container(LinearLayout page){LinearLayout row=new LinearLayout(page.getContext());row.setGravity(Gravity.CENTER_VERTICAL);int pad=SingKeyUi.dp(page.getContext(),12);row.setPadding(pad,pad,pad,pad);row.setMinimumHeight(SingKeyUi.dp(page.getContext(),64));row.setBackgroundColor(SingKeyUi.SURFACE);SingKeyUi.feedback(row,8);return row;}
 private static LinearLayout text(LinearLayout row,String title,String summary){LinearLayout text=new LinearLayout(row.getContext());text.setOrientation(LinearLayout.VERTICAL);text.setPadding(0,0,SingKeyUi.dp(row.getContext(),12),0);text.addView(SingKeyUi.heading(row.getContext(),title,16));if(!summary.isEmpty()){TextView label=SingKeyUi.label(row.getContext(),summary,14,true);label.setPadding(0,SingKeyUi.dp(row.getContext(),6),0,0);text.addView(label);}return text;}
 private static void entry(LinearLayout page,int title,String summary,Runnable action){
  LinearLayout row=container(page);row.addView(text(row,page.getContext().getString(title),summary),new LinearLayout.LayoutParams(0,-2,1));
  ImageView arrow=new ImageView(page.getContext());arrow.setImageDrawable(SingKeyUi.icon(page.getContext(),R.drawable.ic_sk_forward,SingKeyUi.MUTED,20));arrow.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);row.addView(arrow,new LinearLayout.LayoutParams(SingKeyUi.dp(page.getContext(),24),SingKeyUi.dp(page.getContext(),24)));
  row.setOnClickListener(v->action.run());page.addView(row);divider(page);
 }
 private static void divider(LinearLayout page){View line=new View(page.getContext());line.setBackgroundColor(0xff232a36);page.addView(line,new LinearLayout.LayoutParams(-1,SingKeyUi.dp(page.getContext(),1)));}
}
