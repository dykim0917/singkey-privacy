package kr.keymate.app;

import android.content.Context;
import android.os.Bundle;
import android.view.*;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.*;
import java.util.function.BooleanSupplier;

/** Pull feedback stays in the app header, outside the embedded video surface. */
@android.annotation.SuppressLint("ViewConstructor")
final class PlayerRefreshLayout extends FrameLayout {
 private final PullToReloadGesture gesture;
 private final BooleanSupplier canReload;
 private final Runnable reload;
 private final TextView hint;
 private boolean busy,candidate,compact;
 PlayerRefreshLayout(Context context,BooleanSupplier canReload,Runnable reload){
  super(context);this.canReload=canReload;this.reload=reload;
  gesture=new PullToReloadGesture(ViewConfiguration.get(context).getScaledTouchSlop(),SingKeyUi.dp(context,72));
  hint=SingKeyUi.label(context,"",12,true);hint.setGravity(Gravity.CENTER);hint.setMaxLines(2);hint.setIncludeFontPadding(false);
  hint.setAutoSizeTextTypeUniformWithConfiguration(10,12,1,android.util.TypedValue.COMPLEX_UNIT_SP);
  hint.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
  hint.setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
  hint.setAccessibilityDelegate(new AccessibilityDelegate(){
   @Override public void onInitializeAccessibilityNodeInfo(View host,AccessibilityNodeInfo info){
    super.onInitializeAccessibilityNodeInfo(host,info);
    if(available())info.addAction(new AccessibilityNodeInfo.AccessibilityAction(R.id.action_reload_player,getContext().getString(R.string.player_reload_action)));
   }
   @Override public boolean performAccessibilityAction(View host,int action,Bundle args){
    if(action==R.id.action_reload_player&&available()){reload.run();return true;}
    return super.performAccessibilityAction(host,action,args);
   }
  });
  FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,SingKeyUi.dp(context,48),Gravity.TOP);
  p.setMargins(SingKeyUi.dp(context,68),SingKeyUi.dp(context,12),SingKeyUi.dp(context,68),0);addView(hint,p);render();
 }
 private boolean available(){return !compact&&!busy&&canReload.getAsBoolean();}
 void compactHeader(boolean value){compact=value;gesture.cancel();candidate=false;hint.setVisibility(value?GONE:VISIBLE);render();}
 void refreshing(boolean value){if(busy==value)return;busy=value;gesture.cancel();render();}
 private void render(){hint.setText(busy?R.string.player_reloading:gesture.ready()?R.string.player_release_reload:R.string.player_pull_reload);hint.setTextColor(gesture.ready()?SingKeyUi.MINT:SingKeyUi.MUTED);}
 private void cancel(){candidate=false;gesture.cancel();render();getParent().requestDisallowInterceptTouchEvent(false);}
 @Override public boolean onInterceptTouchEvent(MotionEvent event){
  switch(event.getActionMasked()){
   case MotionEvent.ACTION_DOWN:
    candidate=available()&&event.getY()<SingKeyUi.dp(getContext(),64);
    gesture.start(event.getX(),event.getY(),candidate);
    if(candidate)getParent().requestDisallowInterceptTouchEvent(true);
    return false;
   case MotionEvent.ACTION_MOVE:
    if(!available()){cancel();return false;}
    boolean dragging=gesture.move(event.getX(),event.getY());render();return dragging;
   case MotionEvent.ACTION_POINTER_DOWN:case MotionEvent.ACTION_CANCEL:case MotionEvent.ACTION_UP:cancel();return false;
   default:return false;
  }
 }
 // Drag-only container; the header exposes an explicit accessibility reload action.
 @android.annotation.SuppressLint("ClickableViewAccessibility")
 @Override public boolean onTouchEvent(MotionEvent event){
  if(!candidate)return super.onTouchEvent(event);
  switch(event.getActionMasked()){
   case MotionEvent.ACTION_MOVE:gesture.move(event.getX(),event.getY());render();break;
   case MotionEvent.ACTION_UP:
    boolean fire=available()&&gesture.finish();cancel();if(fire)reload.run();break;
   case MotionEvent.ACTION_CANCEL:case MotionEvent.ACTION_POINTER_DOWN:cancel();break;
   default:break;
  }
  return true;
 }
}
