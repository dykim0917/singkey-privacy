package kr.keymate.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.grack.nanojson.*;
import okhttp3.HttpUrl;

final class SongSearch {
 private static final java.util.regex.Pattern EXPLICIT_BACKING = java.util.regex.Pattern.compile(
  "노래방|반주|カラオケ|からおけ|オフ[\\s・-]*ボーカル|オフ[\\s・-]*ヴォーカル|伴奏|歌なし|ボーカルなし|"+
  "(?<![a-z0-9])(?:mr|karaoke|instrumental|backing[\\s-]+track|off[\\s-]*vocal|no[\\s-]+vocals?)(?![a-z0-9])", java.util.regex.Pattern.CASE_INSENSITIVE);
 static String searchQuery(String input) {
  return searchQuery(input,AppLanguage.KO,true);
 }
 static String searchQuery(String input,AppLanguage language,boolean preferBacking) {
  if(input==null||input.trim().isEmpty())return "";
  if(!SearchSafety.validInput(input))throw new IllegalArgumentException("Invalid search input");
  String value = input.trim();
  String video=SearchSafety.canonicalVideo(value);if(video!=null)return video;
  String normalized=java.text.Normalizer.normalize(value,java.text.Normalizer.Form.NFKC);
  if (!preferBacking || value.isEmpty() || isYouTubeUrl(value) || EXPLICIT_BACKING.matcher(normalized).find()) return value;
  return value + " " + language.backingKeyword;
 }
 static boolean isYouTubeUrl(String value) {
  return SearchSafety.canonicalVideo(value)!=null;
 }
 static List<Song> find(String value) throws Exception {
  return find(value,AppLanguage.KO,true);
 }
 static List<Song> find(String value,AppLanguage language,boolean preferBacking) throws Exception {
  return first(value,language,preferBacking).songs;
 }
 static YouTubeSearchPage.Page first(String value,AppLanguage language,boolean preferBacking)throws Exception{if(!SearchSafety.validInput(value))throw new IllegalArgumentException("Invalid search input");String query=searchQuery(value,language,preferBacking);return isYouTubeUrl(query)?new YouTubeSearchPage.Page(findExact(query,language),null):YouTubeSearchPage.first(new HttpDownloader().read(YouTubeSearchPage.url(query,language),HttpDownloader.MAX_BODY_BYTES),language);}
 static YouTubeSearchPage.Page more(YouTubeSearchPage.Cursor cursor)throws Exception{return YouTubeSearchPage.next(new HttpDownloader().searchContinuation(cursor),cursor);}
 // Used by the opt-in comparison probe to preserve the original query variants.
 static List<Song> findExact(String value) throws Exception {
  return findExact(value,AppLanguage.KO);
 }
 static List<Song> findExact(String value,AppLanguage language) throws Exception {
  // searchQuery may append a short localized backing keyword after the user-input limit.
  if(value==null||value.trim().isEmpty()||value.chars().anyMatch(Character::isISOControl)||(value.length()>SearchSafety.MAX_QUERY+20&&!isYouTubeUrl(value)))throw new IllegalArgumentException("Invalid search input");
  if(SearchSafety.looksLikeLink(value)&&!isYouTubeUrl(value))throw new IllegalArgumentException("Unsupported link");
  if (isYouTubeUrl(value)) {
   String canonical=SearchSafety.canonicalVideo(value);
   String id=canonical.substring(canonical.indexOf("v=")+2),title=id;
   String url=new HttpUrl.Builder().scheme("https").host("www.youtube.com").addPathSegment("oembed").addQueryParameter("url",canonical).addQueryParameter("format","json").build().toString();
   try{
    JsonObject metadata=JsonParser.object().from(new HttpDownloader().read(url,64*1024));
    String name=metadata.getString("title",""),author=metadata.getString("author_name","");
    if(!name.isEmpty()&&name.length()<=2000&&author.length()<=500)title=name+(author.isEmpty()?"":" · "+author);
   }catch(java.io.InterruptedIOException interrupted){throw interrupted;}catch(java.io.IOException|JsonParserException unavailable){/* A valid shared link can still be opened in the visible website. */}
   return Collections.singletonList(new Song(canonical,title,"https://i.ytimg.com/vi/"+id+"/hqdefault.jpg"));
  }
  return YouTubeSearchPage.parse(new HttpDownloader().read(YouTubeSearchPage.url(value,language),HttpDownloader.MAX_BODY_BYTES));
 }
}
