package kr.keymate.app;

import java.util.*;

/** Skip a few fully filtered pages without losing the next-page cursor. */
final class PlayableSearch {
 interface More {YouTubeSearchPage.Page load(YouTubeSearchPage.Cursor cursor)throws Exception;}
 static YouTubeSearchPage.Page filter(YouTubeSearchPage.Page page,EmbedAvailability availability,More more)throws Exception{
  Set<String> visited=new HashSet<>();
  int excluded=0;
  for(int i=0;;i++){
   YouTubeSearchPage.Page filtered=availability.filter(page);
   excluded+=filtered.excluded;
   if(!filtered.songs.isEmpty()||filtered.next==null||i>=2)return new YouTubeSearchPage.Page(filtered.songs,filtered.next,excluded);
   if(!visited.add(filtered.next.token))return new YouTubeSearchPage.Page(filtered.songs,null,excluded);
   page=more.load(filtered.next);
  }
 }
 private PlayableSearch(){}
}
