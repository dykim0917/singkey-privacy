package kr.keymate.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.*;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.Uri;
import android.os.*;
import android.view.View;
import android.webkit.*;
import android.widget.FrameLayout;
import androidx.webkit.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.JSONObject;

/** Official iframe control, with a separately gated Web Audio compatibility experiment. */
@SuppressLint("ViewConstructor")
final class YouTubeIframePlayer extends PlaybackPlayer {
 private static final String FRAME_ORIGIN="https://www.youtube.com";
 private final Activity activity;
 private final String origin;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final FrameLayout unusedOverlay;
 private WebView web;
 private ScriptHandler pitchScript;
 private JavaScriptReplyProxy pitchFrame;
 private Listener listener;
 private String token="",videoID="",url="",pendingHtml;
 private long position;
 private final ConfirmedPlaybackPosition resumePosition=new ConfirmedPlaybackPosition();
 private boolean adPlaying;
 private int state=STATE_IDLE,key;
 private boolean playing,wantsPlayback,released,broken,pitchFailed,resumeAfterLayout,compactHeader,stopped=true;
 private Exception error;
 private final Runnable timeout=()->fail("YouTube player timeout");
 private final Runnable visibilityCheck=()->{
  if(released||web==null)return;
  if(isShown()&&getWindowVisibility()==VISIBLE)startWhenVisible();else pause();
 };
 private final Runnable layoutResume=()->{
  boolean resume=resumeAfterLayout;resumeAfterLayout=false;
  if(resume&&!released&&isShown()&&getWindowVisibility()==VISIBLE)play();
 };
 private final BroadcastReceiver noisy=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent intent){pause();}};

 YouTubeIframePlayer(Activity activity){
  super(activity);this.activity=activity;origin="https://"+activity.getPackageName();
  setBackgroundColor(Color.BLACK);unusedOverlay=new FrameLayout(activity);createWebView();
  if(Build.VERSION.SDK_INT>=33)activity.registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),Context.RECEIVER_NOT_EXPORTED);
  else activity.registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
 }
 @SuppressLint("SetJavaScriptEnabled")
 private void createWebView(){
  web=new WebView(activity);web.setBackgroundColor(Color.BLACK);
  WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
  settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);
  settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  settings.setMediaPlaybackRequiresUserGesture(false);settings.setSupportMultipleWindows(false);
  // Preserve embedded YouTube's cookies/context, including its own advertising.
  CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
  web.setWebChromeClient(new WebChromeClient(){
   @Override public void onPermissionRequest(PermissionRequest request){request.deny();}
  });
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
    if(!request.isForMainFrame())return false;
    if(request.hasGesture()&&"https".equals(request.getUrl().getScheme())){
     pause();try{activity.startActivity(new Intent(Intent.ACTION_VIEW,request.getUrl()));}catch(ActivityNotFoundException ignored){}
    }
    return true;
   }
   @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError problem){if(request.isForMainFrame())fail("YouTube connection failed");}
   @Override public boolean onRenderProcessGone(WebView view,RenderProcessGoneDetail detail){broken=true;pitchFrame=null;pitchScript=null;removeView(view);view.destroy();fail("YouTube browser process stopped");return true;}
  });
  // Native search/fullscreen controls live above, never over the YouTube surface.
  LayoutParams bounds=new LayoutParams(-1,-1);bounds.topMargin=compactHeader?0:SingKeyUi.dp(activity,64);addView(web,bounds);
  if(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)){
   WebViewCompat.addWebMessageListener(web,"singkeyNative",Collections.singleton(origin),(view,message,source,mainFrame,reply)->{
    if(!mainFrame||!origin.equals(source.toString()))return;receive(message.getData(),false,null);
   });
   if(BuildConfig.IFRAME_PITCH)WebViewCompat.addWebMessageListener(web,"singkeyPitchNative",Collections.singleton(FRAME_ORIGIN),(view,message,source,mainFrame,reply)->{
    if(mainFrame||!FRAME_ORIGIN.equals(source.toString()))return;receive(message.getData(),true,reply);
   });
  }
 }
 @Override void addListener(Listener value){listener=value;}
 @Override void compactHeader(boolean compact){
  compactHeader=compact;LayoutParams bounds=(LayoutParams)web.getLayoutParams();
  bounds.topMargin=compact?0:SingKeyUi.dp(activity,64);web.setLayoutParams(bounds);
 }
 @Override FrameLayout getOverlayFrameLayout(){return unusedOverlay;}
 @Override void load(String canonical,int initialKey,long startPosition,boolean autoplay){
  if(released)return;stop();
  if(broken){createWebView();broken=false;}
  if(!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)||
     (BuildConfig.IFRAME_PITCH&&!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT))){fail("Update Android System WebView");return;}
  Uri uri=Uri.parse(canonical);String id=uri.getQueryParameter("v");
  if(!BrowserPlayer.allowedOrigin(uri)||id==null||!id.matches("[A-Za-z0-9_-]{11}")){fail("Invalid YouTube video");return;}
  token=UUID.randomUUID().toString();url=canonical;videoID=id;key=KeyMath.clamp(initialKey);position=Math.max(0,startPosition);resumePosition.reset(position);adPlaying=false;
  wantsPlayback=autoplay;stopped=false;error=null;pitchFailed=false;setState(STATE_BUFFERING);
  try{
   JSONObject config=new JSONObject().put("token",token).put("videoID",id).put("key",key).put("position",position/1000d)
    .put("autoplay",autoplay).put("origin",origin).put("pitchEnabled",BuildConfig.IFRAME_PITCH);
   if(pitchScript!=null&&WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)){pitchScript.remove();pitchScript=null;}
   if(BuildConfig.IFRAME_PITCH&&WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)){
    JSONObject pitchConfig=new JSONObject().put("token",token).put("videoID",id).put("key",key).put("diagnostics",BuildConfig.DEBUG)
     .put("wasm",android.util.Base64.encodeToString(assetBytes("BrowserPitchDSP.wasm"),android.util.Base64.NO_WRAP));
    String script="(()=>{"+asset("AndroidPitchDSP.js")+"\n("+asset("YouTubeIframePitch.js")+")("+pitchConfig+");})();";
    pitchScript=WebViewCompat.addDocumentStartJavaScript(web,script,Collections.singleton(FRAME_ORIGIN));
   }
   pendingHtml="<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"+
    "<meta name='referrer' content='strict-origin-when-cross-origin'><style>html,body{margin:0;width:100%;height:100%;background:#000;overflow:hidden}#player{width:100%;height:100%;border:0}</style>"+
    "</head><body><div id='player'></div><script>("+asset("YouTubeIframePlayback.js")+")("+config+");</script></body></html>";
   startWhenVisible();
  }catch(Exception problem){fail("YouTube player assets unavailable");}
 }
 private void startWhenVisible(){
  if(pendingHtml==null||getWindowToken()==null||!isShown()||web.getWidth()<SingKeyUi.dp(activity,200)||web.getHeight()<SingKeyUi.dp(activity,200))return;
  String html=pendingHtml;pendingHtml=null;web.onResume();
  // Registered app identity, as required by YouTube's mobile WebView guidance.
  handler.postDelayed(timeout,45000);web.loadDataWithBaseURL(origin+"/",html,"text/html","UTF-8",null);
 }
 @Override protected void onAttachedToWindow(){super.onAttachedToWindow();post(this::startWhenVisible);}
 @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);post(this::startWhenVisible);}
 @Override protected void onWindowVisibilityChanged(int visibility){super.onWindowVisibilityChanged(visibility);if(web!=null){handler.removeCallbacks(visibilityCheck);handler.post(visibilityCheck);}}
 @Override protected void onVisibilityChanged(View changed,int visibility){
  super.onVisibilityChanged(changed,visibility);
  // Parent page changes also count. Defer so a synchronous fullscreen reparent
  // can finish without turning a resize into a playback command.
  if(web!=null){handler.removeCallbacks(visibilityCheck);handler.post(visibilityCheck);}
 }
 private void receive(String data,boolean frame,JavaScriptReplyProxy reply){
  if(released||stopped||data==null||data.length()>4096)return;
  try{
   JSONObject event=new JSONObject(data);if(!token.equals(event.optString("token")))return;
   String name=event.optString("event");
   if(frame){
    if(!videoID.equals(event.optString("videoID")))return;
    if(name.equals("frame_ready")){pitchFrame=reply;sendPitchKey();return;}
    if(name.equals("pitch_active")||name.equals("original")){if(event.optInt("key",99)==key)command("pitch_active",key);return;}
    if(name.equals("pitch_pending")){command("pitch_pending",0);return;}
    if(name.equals("ad")){adPlaying=event.optBoolean("active",true);resumePosition.ad(adPlaying);command("ad",adPlaying?1:0);return;}
    if(name.equals("metrics")){
     if(BuildConfig.DEBUG){
      JSONObject metrics=new JSONObject();
      for(String field:Arrays.asList("key","input","output","healthy","sampleRate","maxCallbackGapMs","callbackFrames","baseLatencyMs","outputLatencyMs","callbackCount","maxProcessMs"))metrics.put(field,event.opt(field));
      android.util.Log.d("NaekiroIframe",metrics.toString());
     }
     return;
    }
    if(name.equals("pitch_unavailable")){
     if(BuildConfig.DEBUG){
      String reason=event.optString("reason");
      if(!Arrays.asList("resume","processor","graph","command","audio_unavailable","audio_callback").contains(reason))reason="unknown";
      android.util.Log.d("NaekiroIframe","pitch_unavailable reason="+reason);
     }
     pitchUnavailable();return;
    }
    return;
   }
   if(BuildConfig.DEBUG&&!name.equals("position"))android.util.Log.d("NaekiroIframe","event="+name+" code="+event.optInt("code"));
   switch(name){
    case "ready":handler.removeCallbacks(timeout);error=null;setState(STATE_READY);if(!wantsPlayback)command("pause",0);break;
    case "playing":if(!isShown()||getWindowVisibility()!=VISIBLE){pause();break;}handler.removeCallbacks(timeout);wantsPlayback=true;setState(STATE_READY);setPlaying(true);break;
    case "paused":setPlaying(false);break;
    case "buffering":setPlaying(false);setState(STATE_BUFFERING);break;
    case "autoplay_blocked":wantsPlayback=false;setPlaying(false);setState(STATE_READY);break;
    case "ended":wantsPlayback=false;setPlaying(false);setState(STATE_ENDED);break;
    case "pitch_unavailable":pitchUnavailable();break;
    case "failed":fail(new YouTubePlaybackException(event.optInt("code")));break;
    case "position":double seconds=event.optDouble("seconds",-1);if(Double.isFinite(seconds)&&seconds>=0&&seconds<=86400){position=(long)(seconds*1000);resumePosition.observe(seconds,event.optBoolean("ad",true));}break;
    default:break;
   }
  }catch(org.json.JSONException ignored){}
 }
 private void pitchUnavailable(){
  if(pitchFailed)return;pitchFailed=true;pause();handler.removeCallbacks(timeout);setState(STATE_READY);
  if(listener!=null)listener.onPitchUnavailable();
 }
 private void sendPitchKey(){
  if(pitchFrame==null||!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER))return;
  try{pitchFrame.postMessage(new JSONObject().put("token",token).put("key",key).toString());}catch(Exception ignored){pitchUnavailable();}
 }
 private void command(String action,double value){if(!released&&!broken)web.evaluateJavascript("globalThis.singkeyBrowserControl?.("+JSONObject.quote(action)+","+value+")",null);}
 private void setPlaying(boolean value){if(playing==value)return;playing=value;setKeepScreenOn(value);if(listener!=null)listener.onIsPlayingChanged(value);}
 private void setState(int value){if(state==value)return;state=value;if(listener!=null)listener.onPlaybackStateChanged(value);}
 private void fail(String reason){fail(new IOException(reason));}
 private void fail(Exception reason){handler.removeCallbacks(timeout);error=reason;pause();setState(STATE_IDLE);if(listener!=null)listener.onPlayerError(error);}
 @Override void setKey(int value){key=KeyMath.clamp(value);command("key",key);sendPitchKey();}
 @Override void layoutChanged(){
  resumeAfterLayout=playing;handler.removeCallbacks(layoutResume);
  // WebView can pause media when its native view is reparented. Restore only
  // an active session; explicit pause/background/stop cancels this request.
  if(resumeAfterLayout)handler.postDelayed(layoutResume,500);
  post(this::startWhenVisible);
 }
 @Override void play(){if(released||error!=null||pitchFailed||!isShown()||getWindowVisibility()!=VISIBLE)return;wantsPlayback=true;web.onResume();command("play",0);}
 @Override void pause(){resumeAfterLayout=false;handler.removeCallbacks(layoutResume);wantsPlayback=false;command("pause",0);setPlaying(false);}
 @Override void seekTo(long millis){position=Math.max(0,millis);command("seek",position/1000d);}
 @Override void stop(){pause();command("stop",0);stopped=true;token="";pendingHtml=null;pitchFrame=null;handler.removeCallbacks(timeout);if(!broken){web.stopLoading();web.loadUrl("about:blank");}setState(STATE_IDLE);}
 @Override void release(){if(released)return;stop();released=true;handler.removeCallbacksAndMessages(null);activity.unregisterReceiver(noisy);if(!broken){if(pitchScript!=null&&WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT))pitchScript.remove();web.destroy();}}
 @Override boolean isPlaying(){return playing;}
 @Override boolean getPlayWhenReady(){return wantsPlayback;}
 @Override int getPlaybackState(){return state;}
 @Override int getMediaItemCount(){return url.isEmpty()?0:1;}
 @Override Exception getPlayerError(){return error;}
 @Override long getCurrentPosition(){return position;}
 @Override long getResumePosition(){return resumePosition.value();}
 private byte[] assetBytes(String name)throws IOException{
  try(InputStream input=activity.getAssets().open("browser/"+name);ByteArrayOutputStream result=new ByteArrayOutputStream()){
   byte[] buffer=new byte[8192];int n;while((n=input.read(buffer))!=-1){if(result.size()+n>1024*1024)throw new IOException("Asset too large");result.write(buffer,0,n);}return result.toByteArray();
  }
 }
 private String asset(String name)throws IOException{return new String(assetBytes(name),StandardCharsets.UTF_8);}
}
