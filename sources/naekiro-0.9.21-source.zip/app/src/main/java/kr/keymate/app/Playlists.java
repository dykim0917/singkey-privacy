package kr.keymate.app;

import java.io.*;
import java.util.*;

/** Named lists preserve insertion order; keys belong to each list entry. */
final class Playlists {
 static final class ListEntry {
  final String name;
  final SavedSongs songs;
  ListEntry(String name, SavedSongs songs) { this.name = name; this.songs = songs; }
 }
 private final ArrayList<ListEntry> lists = new ArrayList<>();
 List<ListEntry> entries() { return Collections.unmodifiableList(lists); }
 boolean contains(String url, int key) {
  for (ListEntry list : lists) {
   SavedSongs.Entry saved = list.songs.find(url);
   if (saved != null && saved.key == key) return true;
  }
  return false;
 }
 ListEntry create(String name) {
  name = name.trim();
  if (name.isEmpty() || name.length() > 40) throw new IllegalArgumentException("이름을 1~40자로 입력해주세요.");
  for (ListEntry list : lists) if (list.name.equals(name)) throw new IllegalArgumentException("같은 이름의 플레이리스트가 있어요.");
  ListEntry list = new ListEntry(name, new SavedSongs()); lists.add(list); return list;
 }
 List<SavedSongs.Entry> playback(ListEntry list, int start) {
  return new ArrayList<>(list.songs.entries().subList(start, list.songs.entries().size()));
 }
 String encode() throws IOException {
  Properties p = new Properties(); p.setProperty("version", "1"); p.setProperty("count", "" + lists.size());
  for (int i=0;i<lists.size();i++) { p.setProperty(i+".name", lists.get(i).name); p.setProperty(i+".songs", lists.get(i).songs.encode()); }
  StringWriter out = new StringWriter(); p.store(out,"Keymate playlists"); return out.toString();
 }
 static Playlists restore(String current, String legacy) throws IOException {
  if (current == null) {
   Playlists result = new Playlists(); result.lists.add(new ListEntry("내 곡", SavedSongs.decode(legacy))); return result;
  }
  try {
   Properties p = new Properties(); p.load(new StringReader(current));
   if (!"1".equals(p.getProperty("version"))) throw new IOException("Unknown playlist version");
   int count = Integer.parseInt(p.getProperty("count"));
   if (count < 0 || count > 10000) throw new IOException("Invalid count");
   Playlists result = new Playlists();
   for (int i=0;i<count;i++) {
    String name = p.getProperty(i+".name"), songs = p.getProperty(i+".songs");
    if (name == null || songs == null) throw new IOException("Incomplete playlist");
    result.create(name); result.lists.set(i,new ListEntry(name,SavedSongs.decode(songs)));
   }
   return result;
  } catch (IllegalArgumentException e) { throw new IOException("Invalid playlists",e); }
 }
}
