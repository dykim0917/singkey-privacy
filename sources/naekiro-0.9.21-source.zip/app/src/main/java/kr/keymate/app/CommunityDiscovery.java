package kr.keymate.app;

import java.io.IOException;
import java.util.*;

/** Separate discovery sections over the existing paginated public feed. */
final class CommunityDiscovery {
 enum Section { PICKS, COMMUNITY, MINE }
 interface Source { List<CommunityData.ListItem> page(int offset) throws IOException; }
 static final int PAGE_SIZE=20, MAX_PAGES=5, MAX_OFFSET=10000;
 static final class Result {
  final List<CommunityData.ListItem> items;
  final int nextOffset;
  final boolean hasMore;
  Result(Collection<CommunityData.ListItem> items,int offset,boolean more){
   this.items=Collections.unmodifiableList(new ArrayList<>(items));nextOffset=offset;hasMore=more;
  }
 }
 static boolean matches(CommunityData.ListItem item,Section section){
  return section==null||section==Section.MINE||item.curated==(section==Section.PICKS);
 }
 static Result load(Source source,List<CommunityData.ListItem> earlier,int offset,Section section,Set<String> blocked)throws IOException {
  if(offset<0||offset>MAX_OFFSET)throw new IOException("Invalid feed offset");
  LinkedHashMap<String,CommunityData.ListItem> items=new LinkedHashMap<>();
  for(CommunityData.ListItem item:earlier)if(matches(item,section)&&!blocked.contains(item.owner))items.put(item.id,item);
  int target=items.size()+PAGE_SIZE;
  boolean more=true;
  for(int page=0;page<MAX_PAGES;page++){
   List<CommunityData.ListItem> incoming=source.page(offset);
   if(incoming.size()>PAGE_SIZE)throw new IOException("Invalid feed page");
   for(CommunityData.ListItem item:incoming){
    if(matches(item,section)&&!blocked.contains(item.owner))items.put(item.id,item);
    else items.remove(item.id);
   }
   offset+=PAGE_SIZE;
   more=incoming.size()==PAGE_SIZE&&offset<=MAX_OFFSET;
   if(!more||(section==null?homeReady(items.values()):items.size()>=target))break;
  }
  return new Result(items.values(),offset,more);
 }
 private static boolean homeReady(Collection<CommunityData.ListItem> items){
  int picks=0,community=0;
  for(CommunityData.ListItem item:items)if(item.curated)picks++;else community++;
  return picks>=3&&community>=3;
 }
 private CommunityDiscovery(){}
}
