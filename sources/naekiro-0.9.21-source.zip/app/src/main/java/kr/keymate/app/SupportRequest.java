package kr.keymate.app;

import com.grack.nanojson.JsonWriter;
import java.util.regex.Pattern;

/** Only the fields shown on the contact form leave the device. */
final class SupportRequest {
 static final Pattern EMAIL=Pattern.compile("^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+$");
 static boolean validEmail(String email){return email.isEmpty()||(email.length()<=254&&EMAIL.matcher(email).matches());}
 static boolean validMessage(String message){return message.trim().length()>=10&&message.length()<=3000&&message.indexOf('\0')<0;}
 static String json(String id,String topic,String email,String message,String version,String android,String language){
  if(!id.matches("[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}")||!validEmail(email)||!validMessage(message)||!topic.matches("problem|idea|other"))throw new IllegalArgumentException("Invalid inquiry");
  return JsonWriter.string().object().value("requestId",id).value("topic",topic).value("replyTo",email).value("message",message).value("appVersion",version).value("androidVersion",android).value("language",language).end().done();
 }
}
