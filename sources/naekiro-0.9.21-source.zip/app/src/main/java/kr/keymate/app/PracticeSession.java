package kr.keymate.app;

import java.io.*;
import java.util.*;

/** Local continuation snapshot. No autoplay flag, stream URL, auth token or deduplication. */
final class PracticeSession {
 static final int MAX_QUEUE=500;
 static final long MAX_POSITION=86400000L;
 final SavedSongs.Entry current;
 final long position;
 final List<SavedSongs.Entry> queue;
 PracticeSession(SavedSongs.Entry current,long position,List<SavedSongs.Entry> queue){this.current=current;this.position=Math.max(0,Math.min(MAX_POSITION,position));this.queue=Collections.unmodifiableList(new ArrayList<>(queue));}
 static boolean move(List<SavedSongs.Entry> queue,int index,int direction){int target=index+direction;if((direction!=1&&direction!=-1)||index<0||index>=queue.size()||target<0||target>=queue.size())return false;Collections.swap(queue,index,target);return true;}
 String encode()throws IOException{
  if(queue.size()>MAX_QUEUE)throw new IOException("Queue too large");Properties data=new Properties();data.setProperty("practiceVersion","1");data.setProperty("position",""+position);data.setProperty("count",""+queue.size());data.setProperty("hasCurrent",""+(current!=null));if(current!=null)write(data,"current.",current);for(int i=0;i<queue.size();i++)write(data,i+".",queue.get(i));StringWriter out=new StringWriter();data.store(out,"Naekiro practice continuation");String raw=out.toString().replaceAll("(?m)^#[^\r\n]*[\r\n]+", "");if(raw.length()>8*1024*1024)throw new IOException("Session too large");return raw;
 }
 private static void write(Properties data,String prefix,SavedSongs.Entry entry)throws IOException{
  String url=SearchSafety.canonicalVideo(entry.song.url);if(url==null||entry.song.title==null||entry.song.title.length()>2504)throw new IOException("Invalid session song");data.setProperty(prefix+"url",url);data.setProperty(prefix+"title",entry.song.title);data.setProperty(prefix+"key",""+entry.key);
 }
 static PracticeSession decode(String raw)throws IOException{
  if(raw==null||raw.isEmpty())return new PracticeSession(null,0,Collections.emptyList());if(raw.length()>8*1024*1024)throw new IOException("Session too large");
  try{Properties data=new Properties();data.load(new StringReader(raw));if(!"1".equals(data.getProperty("practiceVersion")))throw new IOException("Unsupported practice session");int count=Integer.parseInt(data.getProperty("count"));long position=Long.parseLong(data.getProperty("position"));if(count<0||count>MAX_QUEUE||position<0||position>MAX_POSITION)throw new IOException("Invalid practice session");String has=data.getProperty("hasCurrent");if(!"true".equals(has)&&!"false".equals(has))throw new IOException("Invalid current state");List<SavedSongs.Entry> queue=new ArrayList<>();for(int i=0;i<count;i++)queue.add(read(data,i+"."));return new PracticeSession("true".equals(has)?read(data,"current."):null,position,queue);}catch(IllegalArgumentException e){throw new IOException("Invalid practice session",e);}
 }
 private static SavedSongs.Entry read(Properties data,String prefix)throws IOException{
  String url=SearchSafety.canonicalVideo(data.getProperty(prefix+"url")),title=data.getProperty(prefix+"title");int key=Integer.parseInt(data.getProperty(prefix+"key"));if(url==null||title==null||title.length()>2504||key < -12||key>12)throw new IOException("Invalid session song");String id=url.substring(url.length()-11);return new SavedSongs.Entry(new Song(url,title,"https://i.ytimg.com/vi/"+id+"/hqdefault.jpg"),key);
 }
}
