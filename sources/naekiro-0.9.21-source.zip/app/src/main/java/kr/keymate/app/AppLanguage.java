package kr.keymate.app;

import java.util.Locale;

/** One language choice shared by UI resources, search, and suggestions. */
enum AppLanguage {
 EN("en", "US", "karaoke"), KO("ko", "KR", "노래방"), JA("ja", "JP", "カラオケ");
 final String language, country, backingKeyword;
 AppLanguage(String language, String country, String backingKeyword) {
  this.language=language; this.country=country; this.backingKeyword=backingKeyword;
 }
 static AppLanguage from(Locale locale) {
  if(locale!=null) for(AppLanguage value:values()) if(value.language.equals(locale.getLanguage())) return value;
  return EN;
 }
 Locale locale() { return new Locale(language,country); }
}
