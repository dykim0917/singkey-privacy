package kr.keymate.app;

/** Resume only from a finite content position after an explicit non-ad signal. */
final class ConfirmedPlaybackPosition {
 private long value;
 private boolean known,ad;
 void reset(long start){value=Math.max(0,Math.min(PracticeSession.MAX_POSITION,start));known=false;ad=false;}
 void ad(boolean active){known=true;ad=active;}
 void observe(double seconds,boolean markedAdOrUnknown){if(known&&!ad&&!markedAdOrUnknown&&Double.isFinite(seconds)&&seconds>=0&&seconds<=86400)value=(long)(seconds*1000);}
 long value(){return value;}
}
