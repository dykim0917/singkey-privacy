package kr.keymate.app;

/** Counts audible foreground time, excluding pause, buffering and time in other apps. */
final class PracticeMeter {
 private long started=-1, accumulated;
 void playing(boolean playing,long now){
  if(playing&&started<0)started=now;
  if(!playing&&started>=0){accumulated+=Math.max(0,now-started);started=-1;}
 }
 long take(long now){
  long total=accumulated+(started<0?0:Math.max(0,now-started));
  accumulated=0;if(started>=0)started=now;return total;
 }
 void reset(){started=-1;accumulated=0;}
}
