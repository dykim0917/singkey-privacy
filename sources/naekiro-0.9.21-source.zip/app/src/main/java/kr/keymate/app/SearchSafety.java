package kr.keymate.app;

import java.net.URI;
import java.util.*;
import java.util.regex.Pattern;

/** Shared validation for typed text, shared links, search results and stored songs. */
final class SearchSafety {
 static final int MAX_INPUT=2048,MAX_QUERY=200,MAX_RESULTS=50,MAX_NETWORK_URL=16384;
 private static final Set<String> VIDEO_HOSTS=new HashSet<>(Arrays.asList("youtube.com","www.youtube.com","m.youtube.com","music.youtube.com"));
 private static final Pattern SCHEME=Pattern.compile("^(?:https?|ftp|file|content|javascript|data|intent|about|mailto|tel|sms):",Pattern.CASE_INSENSITIVE);
 static boolean looksLikeLink(String input){
  if(input==null)return false;String value=input.trim().toLowerCase(Locale.ROOT);
  // A colon in a song title (Artist:Title) is ordinary text, not an executable URI.
  return value.contains("://")||SCHEME.matcher(value).find()||value.startsWith("//")||value.startsWith("www.")||value.startsWith("youtu.be/")||value.startsWith("youtube.com/")||value.startsWith("m.youtube.com/")||value.startsWith("music.youtube.com/");
 }
 static boolean validInput(String input){
  if(input==null||input.length()>MAX_INPUT)return false;
  String value=input.trim();if(value.isEmpty()||value.chars().anyMatch(Character::isISOControl))return false;
  return looksLikeLink(value)?canonicalVideo(value)!=null:value.length()<=MAX_QUERY;
 }
 static String canonicalVideo(String input){
  if(input==null||input.length()>MAX_INPUT)return null;
  String value=input.trim();
  String lower=value.toLowerCase(Locale.ROOT);
  if(lower.startsWith("youtu.be/")||VIDEO_HOSTS.stream().anyMatch(host->lower.startsWith(host+"/")))value="https://"+value;
  URI uri=secureUri(value);if(uri==null)return null;
  String host=uri.getHost().toLowerCase(Locale.ROOT),path=uri.getRawPath(),id=null;
  if("youtu.be".equals(host)&&path!=null&&path.matches("/[A-Za-z0-9_-]{11}/?"))id=path.substring(1,12);
  else if(VIDEO_HOSTS.contains(host)){
   if("/watch".equals(path)&&uri.getRawQuery()!=null){
    for(String part:uri.getRawQuery().split("&"))if(part.startsWith("v=")){if(id!=null)return null;id=part.substring(2);}
   }else if(path!=null&&path.matches("/(shorts|embed|live)/[A-Za-z0-9_-]{11}/?"))id=path.split("/")[2];
  }
  return id!=null&&id.matches("[A-Za-z0-9_-]{11}")?"https://www.youtube.com/watch?v="+id:null;
 }
 static URI secureUri(String value){
  // Signed media URLs are longer than links pasted by the user.
  if(value==null||value.isEmpty()||value.length()>MAX_NETWORK_URL||value.chars().anyMatch(Character::isISOControl))return null;
  try{URI uri=URI.create(value);return "https".equalsIgnoreCase(uri.getScheme())&&uri.getHost()!=null&&uri.getRawUserInfo()==null&&(uri.getPort()==-1||uri.getPort()==443)?uri:null;}
  catch(IllegalArgumentException ignored){return null;}
 }
 static boolean thumbnail(String value){URI uri=secureUri(value);return uri!=null&&Arrays.asList("i.ytimg.com","img.youtube.com").contains(uri.getHost().toLowerCase(Locale.ROOT));}
 static boolean media(String value){URI uri=secureUri(value);if(uri==null)return false;String host=uri.getHost().toLowerCase(Locale.ROOT);return host.equals("googlevideo.com")||host.endsWith(".googlevideo.com");}
 static boolean extractor(String value){
  URI uri=secureUri(value);if(uri==null)return false;
  return Arrays.asList("youtube.com","www.youtube.com","m.youtube.com","music.youtube.com","youtu.be","youtubei.googleapis.com","www.google.com","consent.google.com","suggestqueries.google.com","suggestqueries-clients6.youtube.com").contains(uri.getHost().toLowerCase(Locale.ROOT));
 }
 private SearchSafety(){}
}
