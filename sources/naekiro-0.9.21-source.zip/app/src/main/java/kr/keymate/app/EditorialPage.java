package kr.keymate.app;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.function.Consumer;

/** A collection's own page; selecting a track opens search without starting playback. */
@android.annotation.SuppressLint("ViewConstructor") // Programmatic page with navigation callbacks.
final class EditorialPage extends LinearLayout {
 private final Activity activity;
 private final Consumer<FeaturedSongs.Entry> find;
 private final ScrollView scroll;
 private final LinearLayout content;
 private String collectionId;
 private int pendingScrollY=-1;

 EditorialPage(Activity a,Runnable back,Consumer<FeaturedSongs.Entry> find){
  super(a);activity=a;this.find=find;
  setOrientation(VERTICAL);setBackgroundColor(SingKeyUi.NAVY);

  LinearLayout header=new LinearLayout(a);header.setGravity(Gravity.CENTER_VERTICAL);
  header.setPadding(dp(12),dp(8),dp(16),dp(8));
  header.addView(SingKeyUi.iconButton(a,R.drawable.ic_sk_back,a.getString(R.string.back_to_home),v->back.run()));
  TextView section=SingKeyUi.heading(a,a.getString(R.string.community_picks_title),18);
  LinearLayout.LayoutParams sectionSize=new LinearLayout.LayoutParams(0,-2,1);sectionSize.setMarginStart(dp(8));
  header.addView(section,sectionSize);addView(header,new LinearLayout.LayoutParams(-1,-2));

  scroll=new ScrollView(a);scroll.setFillViewport(true);scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
  content=new LinearLayout(a);content.setOrientation(VERTICAL);content.setPadding(dp(20),dp(16),dp(20),dp(24));
  scroll.addView(content,new ScrollView.LayoutParams(-1,-2));addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
 }

 void show(EditorialCollections.Collection collection){
  if(collection.id.equals(collectionId))return;
  collectionId=collection.id;content.removeAllViews();

  int coverSize=Math.min(160,Math.max(96,getResources().getConfiguration().screenWidthDp-64));
  ImageView cover=new ImageView(activity);cover.setImageResource(collection.coverRes);cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
  cover.setBackground(SingKeyUi.shape(activity,SingKeyUi.RAISED,10));cover.setClipToOutline(true);
  cover.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
  LinearLayout.LayoutParams artwork=new LinearLayout.LayoutParams(dp(coverSize),dp(coverSize));artwork.gravity=Gravity.CENTER_HORIZONTAL;
  content.addView(cover,artwork);

  TextView title=SingKeyUi.heading(activity,activity.getString(collection.titleRes),24);title.setGravity(Gravity.CENTER);
  addOverview(title,16);
  TextView summary=SingKeyUi.label(activity,activity.getString(collection.summaryRes),14,true);summary.setGravity(Gravity.CENTER);
  addOverview(summary,8);
  String total=getResources().getQuantityString(R.plurals.community_picks_count,collection.tracks.size(),collection.tracks.size());
  TextView count=SingKeyUi.label(activity,total,13,true);count.setGravity(Gravity.CENTER);addOverview(count,10);

  LinearLayout tracks=new LinearLayout(activity);tracks.setOrientation(VERTICAL);
  LinearLayout.LayoutParams trackList=new LinearLayout.LayoutParams(-1,-2);trackList.topMargin=dp(24);content.addView(tracks,trackList);
  for(FeaturedSongs.Entry entry:collection.tracks)tracks.addView(track(entry),new LinearLayout.LayoutParams(-1,-2));
  restoreScrollPosition(0);
 }

 int scrollPosition(){return pendingScrollY>=0?pendingScrollY:scroll.getScrollY();}

 void restoreScrollPosition(int y){
  // Keep the offset until layout: navigation may restore this page while it is GONE.
  pendingScrollY=Math.max(0,y);requestLayout();
 }

 @Override protected void onLayout(boolean changed,int left,int top,int right,int bottom){
  super.onLayout(changed,left,top,right,bottom);
  if(pendingScrollY>=0){scroll.scrollTo(0,pendingScrollY);pendingScrollY=-1;}
 }

 private void addOverview(TextView label,int topMargin){
  LinearLayout.LayoutParams size=new LinearLayout.LayoutParams(-1,-2);size.topMargin=dp(topMargin);content.addView(label,size);
 }

 private View track(FeaturedSongs.Entry entry){
  LinearLayout row=new LinearLayout(activity);row.setGravity(Gravity.CENTER_VERTICAL);row.setMinimumHeight(dp(72));
  row.setPadding(0,dp(12),0,dp(12));
  LinearLayout text=new LinearLayout(activity);text.setOrientation(VERTICAL);
  text.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
  text.addView(SingKeyUi.heading(activity,entry.title,16));
  TextView artist=SingKeyUi.label(activity,entry.artist,13,true);artist.setPadding(0,dp(3),0,0);text.addView(artist);
  row.addView(text,new LinearLayout.LayoutParams(0,-2,1));

  ImageView search=new ImageView(activity);search.setImageDrawable(SingKeyUi.icon(activity,R.drawable.ic_sk_search,SingKeyUi.MUTED,24));
  search.setPadding(dp(12),dp(12),dp(12),dp(12));search.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
  LinearLayout.LayoutParams searchSize=new LinearLayout.LayoutParams(dp(48),dp(48));searchSize.setMarginStart(dp(8));row.addView(search,searchSize);
  row.setContentDescription(activity.getString(R.string.find_song,entry.title+" · "+entry.artist));
  row.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);row.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
  row.setAccessibilityDelegate(new View.AccessibilityDelegate(){
   @Override public void onInitializeAccessibilityNodeInfo(View host,AccessibilityNodeInfo node){
    super.onInitializeAccessibilityNodeInfo(host,node);node.setClassName(Button.class.getName());
   }
  });
  row.setOnClickListener(v->find.accept(entry));SingKeyUi.feedback(row,8);return row;
 }

 private int dp(int value){return SingKeyUi.dp(activity,value);}
}
