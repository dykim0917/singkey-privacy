package kr.keymate.app;

import com.grack.nanojson.*;
import java.io.*;
import java.util.*;
import java.util.function.*;

/** Local, bounded video-level cache. Unknown status must never become a denial. */
final class EmbedAvailability {
 static final long BLOCK_TTL=24*60*60*1000L, ALLOW_TTL=15*60*1000L;
 static final int LIMIT=500;
 interface Checker { Map<String,Boolean> check(List<String> ids)throws IOException; }
 private final Checker checker;
 private final LongSupplier clock;
 private final Consumer<String> persist;
 private final LinkedHashMap<String,Long> blocked=new LinkedHashMap<>(),allowed=new LinkedHashMap<>();
 private long retryAfter;
 EmbedAvailability(Checker checker,LongSupplier clock,String saved,Consumer<String> persist){
  this.checker=checker;this.clock=clock;this.persist=persist;
  if(saved!=null&&saved.length()<=32768)try{
   JsonObject values=JsonParser.object().from(saved);
   if(values.size()<=LIMIT)for(String id:values.keySet()){
    Object until=values.get(id);
    if(validId(id)&&until instanceof Number){long expiry=((Number)until).longValue();if(expiry>clock.getAsLong()&&expiry<=clock.getAsLong()+BLOCK_TTL)blocked.put(id,expiry);}
   }
  }catch(JsonParserException ignored){/* Disposable cache; leave saved songs and history alone. */}
 }
 static boolean validId(String id){return id!=null&&id.matches("[A-Za-z0-9_-]{11}");}
 static String id(String url){String canonical=SearchSafety.canonicalVideo(url);return canonical==null?null:canonical.substring(canonical.indexOf("v=")+2);}
 private void prune(){long now=clock.getAsLong();blocked.values().removeIf(until->until<=now||until>now+BLOCK_TTL);allowed.values().removeIf(until->until<=now||until>now+ALLOW_TTL);}
 private static void cap(LinkedHashMap<String,Long> values){while(values.size()>LIMIT)values.remove(values.keySet().iterator().next());}
 private void save(){JsonObject values=new JsonObject();values.putAll(blocked);persist.accept(JsonWriter.string(values));}
 synchronized boolean blocked(String url){prune();return blocked.containsKey(id(url));}
 synchronized void failed(String url,Exception error){if(!YouTubePlaybackException.embedBlocked(error))return;String id=id(url);if(id==null)return;prune();blocked.remove(id);blocked.put(id,clock.getAsLong()+BLOCK_TTL);allowed.remove(id);cap(blocked);save();}
 synchronized void played(String url){String id=id(url);if(id!=null&&blocked.remove(id)!=null)save();}
 synchronized List<Song> visible(List<Song> songs){prune();List<Song> result=new ArrayList<>();for(Song song:songs)if(id(song.url)!=null&&!blocked.containsKey(id(song.url)))result.add(song);return result;}
 YouTubeSearchPage.Page filter(YouTubeSearchPage.Page page)throws IOException{
  List<String> unknown=new ArrayList<>();
  synchronized(this){prune();if(clock.getAsLong()>=retryAfter)for(Song song:page.songs){String id=id(song.url);if(id!=null&&!blocked.containsKey(id)&&!allowed.containsKey(id)&&!unknown.contains(id))unknown.add(id);}}
  // Metadata failures leave unknown videos visible. A connection failure is not a ban.
  for(int start=0;start<unknown.size();start+=50){
   if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();
   List<String> batch=unknown.subList(start,Math.min(start+50,unknown.size()));
   try{
    Map<String,Boolean> statuses=checker.check(batch);
    if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();
    synchronized(this){boolean changed=false;for(String id:batch){Boolean status=statuses.get(id);if(status==null)continue;if(status){allowed.put(id,clock.getAsLong()+ALLOW_TTL);}else{blocked.put(id,clock.getAsLong()+BLOCK_TTL);allowed.remove(id);changed=true;}}cap(allowed);cap(blocked);if(changed)save();}
   }catch(InterruptedIOException error){if(Thread.currentThread().isInterrupted())throw error;synchronized(this){retryAfter=clock.getAsLong()+60000;}break;}
   catch(IOException error){synchronized(this){retryAfter=clock.getAsLong()+60000;}break;}
  }
  List<Song> songs=visible(page.songs);return new YouTubeSearchPage.Page(songs,page.next,page.excluded+page.songs.size()-songs.size());
 }
}
