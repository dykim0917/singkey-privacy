package kr.keymate.app;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.*;

/** Album-style discovery card. Opening a collection never implies starting playback. */
@android.annotation.SuppressLint("ViewConstructor") // Data-bound programmatic card; never inflated from XML.
final class RecommendationCard extends LinearLayout {
 RecommendationCard(Context c,String title,String count,int coverRes,View.OnClickListener open){
  super(c);
  int screenWidth=c.getResources().getConfiguration().screenWidthDp;
  boolean largeText=c.getResources().getConfiguration().fontScale>=1.4f;
  // The home has 20dp insets. Keep a sliver of the next album visible at phone widths.
  int width=Math.max(132,Math.min(184,148+Math.round((screenWidth-360)*16f/51f)));
  width=Math.min(width,Math.max(120,(screenWidth-76)/2));
  if(largeText)width=Math.min(Math.max(width,220),Math.max(160,screenWidth-64));
  setOrientation(VERTICAL);setGravity(Gravity.TOP);setLayoutParams(new LinearLayout.LayoutParams(dp(c,width),-2));
  ImageView artwork=new ImageView(c);artwork.setScaleType(ImageView.ScaleType.CENTER_CROP);artwork.setImageResource(coverRes);
  artwork.setBackground(SingKeyUi.shape(c,SingKeyUi.RAISED,8));artwork.setClipToOutline(true);artwork.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
  addView(artwork,new LinearLayout.LayoutParams(dp(c,width),dp(c,width)));
  LinearLayout text=new LinearLayout(c);text.setOrientation(VERTICAL);text.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
  TextView heading=SingKeyUi.heading(c,title,16);heading.setMaxLines(2);heading.setEllipsize(android.text.TextUtils.TruncateAt.END);text.addView(heading);
  TextView metadata=SingKeyUi.label(c,count,13,true);metadata.setPadding(0,dp(c,6),0,0);text.addView(metadata);
  LinearLayout.LayoutParams info=new LinearLayout.LayoutParams(-1,-2);info.topMargin=dp(c,10);addView(text,info);
  setContentDescription(title+", "+count);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
  setAccessibilityDelegate(new View.AccessibilityDelegate(){@Override public void onInitializeAccessibilityNodeInfo(View host,AccessibilityNodeInfo info){super.onInitializeAccessibilityNodeInfo(host,info);info.setClassName(Button.class.getName());}});
  setOnClickListener(open);SingKeyUi.feedback(this,12);
 }
 private static int dp(Context c,int value){return SingKeyUi.dp(c,value);}
}
