package kr.keymate.app;

import android.content.Context;
import android.content.pm.*;
import android.os.Build;
import java.security.MessageDigest;
import java.util.Locale;

final class AndroidApiIdentity {
 @SuppressWarnings("deprecation")
 static String certificate(Context context){
  try{
   PackageInfo info=context.getPackageManager().getPackageInfo(context.getPackageName(),Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES);
   Signature[] signatures=Build.VERSION.SDK_INT>=28?info.signingInfo.getApkContentsSigners():info.signatures;
   if(signatures==null||signatures.length!=1)return "";
   byte[] digest=MessageDigest.getInstance("SHA-1").digest(signatures[0].toByteArray());StringBuilder hex=new StringBuilder();
   for(byte value:digest)hex.append(String.format(Locale.ROOT,"%02X",value&255));return hex.toString();
  }catch(Exception unavailable){return "";}
 }
 private AndroidApiIdentity(){}
}
