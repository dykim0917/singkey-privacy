package kr.keymate.app;

/** A home song group, deliberately independent of the app's search language. */
enum HomeCategory {
 KOREAN("kr"), JAPANESE("jp"), POP("pop");
 final String id;
 HomeCategory(String id) { this.id=id; }
 boolean isChart() { return this!=POP; }
 static HomeCategory restore(String saved,AppLanguage language) {
  for(HomeCategory category:values())if(category.id.equals(saved))return category;
  return language==AppLanguage.KO?KOREAN:language==AppLanguage.JA?JAPANESE:POP;
 }
}
