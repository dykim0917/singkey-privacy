package kr.keymate.app;

import android.app.Activity;
import android.widget.FrameLayout;

/** Shared UI contract; each backend owns its playback and lifecycle. */
@android.annotation.SuppressLint("ViewConstructor") // Abstract, programmatically constructed player host.
abstract class PlaybackPlayer extends FrameLayout {
 static final int STATE_IDLE=1,STATE_BUFFERING=2,STATE_READY=3,STATE_ENDED=4;
 interface Listener {
  void onIsPlayingChanged(boolean playing);
  void onPlaybackStateChanged(int state);
  void onPlayerError(Exception error);
  void onPitchUnavailable();
 }
 PlaybackPlayer(Activity activity){super(activity);}
 abstract void addListener(Listener listener);
 abstract FrameLayout getOverlayFrameLayout();
 abstract void load(String url,int key,long position,boolean autoplay);
 abstract void setKey(int key);
 abstract void layoutChanged();
 void compactHeader(boolean compact){}
 abstract void play();
 abstract void pause();
 abstract void seekTo(long millis);
 abstract void stop();
 abstract void release();
 abstract boolean isPlaying();
 abstract boolean getPlayWhenReady();
 abstract int getPlaybackState();
 abstract int getMediaItemCount();
 abstract Exception getPlayerError();
 abstract long getCurrentPosition();
 /** Last position known to belong to the song, rather than an ad. */
 long getResumePosition(){return getCurrentPosition();}
}
