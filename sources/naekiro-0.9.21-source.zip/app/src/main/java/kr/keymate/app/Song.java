package kr.keymate.app;

/** A stable video URL, never an expiring media stream address. */
final class Song {
 final String url;
 final String title;
 final String thumbnailUrl;
 Song(String url, String title) { this(url, title, ""); }
 Song(String url, String title, String thumbnailUrl) { this.url = url; this.title = title; this.thumbnailUrl = thumbnailUrl; }
}
