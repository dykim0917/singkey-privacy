package kr.keymate.app;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Fixed editorial selections, available before any history, account or network response. */
final class EditorialCollections {
 private EditorialCollections() {}

 static final class Collection {
  final String id;
  final int titleRes,summaryRes,coverRes;
  final List<FeaturedSongs.Entry> tracks;
  Collection(String id,int titleRes,int summaryRes,int coverRes,FeaturedSongs.Entry...tracks) {
   this.id=id;this.titleRes=titleRes;this.summaryRes=summaryRes;this.coverRes=coverRes;
   this.tracks=Collections.unmodifiableList(Arrays.asList(tracks));
  }
 }

 // Reviewed 2026-10-03. Sources and selection rationale: docs/product/ANDROID_HOME_BENCHMARK_2026-10-03.md.
 // These are search seeds, not chart positions, video IDs, or a promise of playable search results.
 private static final List<Collection> COLLECTIONS=Collections.unmodifiableList(Arrays.asList(
  new Collection("band-singalong",R.string.home_editorial_band_title,R.string.home_editorial_band_summary,R.drawable.cover_editorial_band,
   song("한 페이지가 될 수 있게","DAY6"),song("고민중독","QWER"),
   song("Drowning","WOODZ"),song("0+0","한로로"),
   song("옥탑방","엔플라잉"),song("개화","LUCY"),
   song("좋은 밤 좋은 꿈","너드커넥션"),song("나는 나비","YB")),
  new Collection("autumn-ballads",R.string.home_editorial_ballad_title,R.string.home_editorial_ballad_summary,R.drawable.cover_editorial_ballad,
   song("계절의 끝","박재정"),song("너의 모든 순간","성시경"),
   song("광화문에서","규현"),song("가을밤에 든 생각","잔나비"),
   song("너를 만나","폴킴"),song("밤편지","아이유"),
   song("어떻게 이별까지 사랑하겠어, 널 사랑하는 거지","AKMU"),song("모든 날, 모든 순간","폴킴")),
  new Collection("jrock-anime",R.string.home_editorial_jrock_title,R.string.home_editorial_jrock_summary,R.drawable.cover_editorial_jrock,
   song("My World","SPYAIR"),song("イマジネーション","SPYAIR"),
   song("シルエット","KANA-BOON"),song("シュガーソングとビターステップ","UNISON SQUARE GARDEN"),
   song("前前前世","RADWIMPS"),song("GO!!!","FLOW"))
 ));
 private static FeaturedSongs.Entry song(String title,String artist) {return new FeaturedSongs.Entry(0,title,artist);}
 static List<Collection> all() {return COLLECTIONS;}
}
