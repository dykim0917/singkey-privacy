package kr.keymate.app;

import android.app.Activity;
import android.view.*;
import android.widget.*;
import java.text.DateFormat;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.IntFunction;

/** Compact local section below public playlists; each action states which key it uses. */
final class PracticeRecommendationsUi {
 static void render(LinearLayout root,List<PracticeRecommendations.Pick> picks,boolean hasOther,Runnable other,
                    BiConsumer<Song,Integer> play,BiConsumer<Song,Integer> queue,IntFunction<String> keyText){
  Activity c=(Activity)root.getContext();root.removeAllViews();int pad=SingKeyUi.dp(c,8);
  LinearLayout header=new LinearLayout(c);header.setGravity(Gravity.CENTER_VERTICAL);
  boolean stacked=c.getResources().getConfiguration().fontScale>1.3f;if(stacked)header.setOrientation(LinearLayout.VERTICAL);
  header.addView(SingKeyUi.heading(c,c.getString(R.string.recommendations_title),17),stacked?new LinearLayout.LayoutParams(-1,-2):new LinearLayout.LayoutParams(0,-2,1));
  if(hasOther)header.addView(AppDialog.quiet(c,c.getString(R.string.recommendations_other),v->other.run()));root.addView(header);
  if(picks.isEmpty()){root.addView(SingKeyUi.label(c,c.getString(R.string.recommendations_empty),14,true));return;}
  for(PracticeRecommendations.Pick pick:picks){
   SavedSongs.Entry saved=pick.saved;LinearLayout card=SingKeyUi.card(c);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(pad,pad,pad,pad);
   LinearLayout row=new LinearLayout(c);row.setGravity(Gravity.CENTER_VERTICAL);LinearLayout info=new LinearLayout(c);info.setOrientation(LinearLayout.VERTICAL);
   TextView title=SingKeyUi.heading(c,saved.song.title,14);title.setMaxLines(2);title.setEllipsize(android.text.TextUtils.TruncateAt.END);info.addView(title);
   String reason=pick.reason==PracticeRecommendations.Reason.COMFORTABLE?c.getString(R.string.recommendations_comfortable,keyText.apply(pick.rating.ratingKey)):pick.reason==PracticeRecommendations.Reason.LONG_AGO?c.getString(R.string.recommendations_long_ago,DateFormat.getDateInstance(DateFormat.MEDIUM,c.getResources().getConfiguration().getLocales().get(0)).format(new Date(pick.playedAt))):c.getString(R.string.recommendations_saved);
   TextView explanation=SingKeyUi.label(c,reason,13,true);explanation.setPadding(0,pad/2,pad,0);info.addView(explanation);
   TextView key=SingKeyUi.label(c,c.getString(R.string.recommendations_saved_key,keyText.apply(saved.key)),13,false);key.setTextColor(SingKeyUi.MINT);info.addView(key);if(stacked)row.setOrientation(LinearLayout.VERTICAL);row.addView(info,stacked?new LinearLayout.LayoutParams(-1,-2):new LinearLayout.LayoutParams(0,-2,1));
   LinearLayout actions=new LinearLayout(c);actions.setGravity(Gravity.END);
   actions.addView(SingKeyUi.iconButton(c,R.drawable.ic_sk_play,c.getString(R.string.recommendations_play,saved.song.title,keyText.apply(saved.key)),v->play.accept(saved.song,saved.key)));
   actions.addView(SingKeyUi.iconButton(c,R.drawable.ic_sk_plus,c.getString(R.string.queue_saved_song,saved.song.title,keyText.apply(saved.key)),v->queue.accept(saved.song,saved.key)));row.addView(actions,stacked?new LinearLayout.LayoutParams(-1,-2):new LinearLayout.LayoutParams(-2,-2));card.addView(row);
   if(pick.rating!=null&&pick.rating.ratingKey!=saved.key){int ratedKey=pick.rating.ratingKey;card.addView(AppDialog.quiet(c,c.getString(R.string.recommendations_previous_key,keyText.apply(ratedKey)),v->play.accept(saved.song,ratedKey)));}
   LinearLayout.LayoutParams placement=new LinearLayout.LayoutParams(-1,-2);placement.topMargin=pad;root.addView(card,placement);
  }
 }
}
