package kr.keymate.app;

import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Versioned, bounded backup. Import is validated completely before touching device data. */
final class LibraryBackup {
 static final int MAX_BYTES=4*1024*1024, MAX_SONGS=10000, MAX_LISTS=1000;
 static final class Data {
  final Playlists lists;final SongNotes notes;
  Data(Playlists lists,SongNotes notes){this.lists=lists;this.notes=notes;}
 }
 static byte[] encode(Playlists lists) throws IOException {
  String payload=lists.encode();validate(payload);
  Properties envelope=new Properties();envelope.setProperty("singkeyBackupVersion","1");
  envelope.setProperty("playlists",payload);envelope.setProperty("sha256",digest(payload));
  StringWriter text=new StringWriter();envelope.store(text,"SingKey playlists and saved keys");
  byte[] bytes=text.toString().getBytes(StandardCharsets.UTF_8);
  if(bytes.length>MAX_BYTES)throw new IOException("Backup too large");return bytes;
 }
 static byte[] encode(Playlists lists,SongNotes notes)throws IOException {
  String payload=lists.encode(),notebook=notes.encode();validate(payload);SongNotes.decode(notebook);
  Properties envelope=new Properties();envelope.setProperty("singkeyBackupVersion","2");envelope.setProperty("playlists",payload);envelope.setProperty("songNotes",notebook);
  envelope.setProperty("sha256",digest(payload.length()+":"+payload+notebook));
  StringWriter text=new StringWriter();envelope.store(text,"Naekiro playlists, keys and personal notes");byte[] bytes=text.toString().getBytes(StandardCharsets.UTF_8);
  if(bytes.length>MAX_BYTES)throw new IOException("Backup too large");return bytes;
 }
 static Playlists read(InputStream stream) throws IOException {
  return readData(stream).lists;
 }
 static Data readData(InputStream stream) throws IOException {
  if(stream==null)throw new IOException("No document");
  ByteArrayOutputStream data=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;
  while((count=stream.read(buffer))!=-1){if(data.size()+count>MAX_BYTES)throw new IOException("Backup too large");data.write(buffer,0,count);}
  try {
   Properties envelope=new Properties();envelope.load(new StringReader(data.toString("UTF-8")));
   String payload=envelope.getProperty("playlists");
   String version=envelope.getProperty("singkeyBackupVersion"),notebook=envelope.getProperty("songNotes");
   if(payload==null||(!"1".equals(version)&&!"2".equals(version)))throw new IOException("Invalid backup");
   String checksum;
   if("2".equals(version)){if(notebook==null)throw new IOException("Missing notebook");checksum=digest(payload.length()+":"+payload+notebook);}
   else {notebook=null;checksum=digest(payload);}
   if(!checksum.equals(envelope.getProperty("sha256")))throw new IOException("Invalid backup");
   validate(payload);return new Data(Playlists.restore(payload,""),SongNotes.decode(notebook));
  }catch(IllegalArgumentException e){throw new IOException("Invalid backup",e);}
 }
 static int songs(Playlists lists){int count=0;for(Playlists.ListEntry list:lists.entries())count+=list.songs.entries().size();return count;}
 static Playlists merge(Playlists existing,Playlists incoming,String suffix) throws IOException {
  Playlists result=Playlists.restore(existing.encode(),"");
  if(result.entries().size()+incoming.entries().size()>MAX_LISTS||songs(result)+songs(incoming)>MAX_SONGS)throw new IOException("Library too large");
  Set<String> names=new HashSet<>();for(Playlists.ListEntry list:result.entries())names.add(list.name);
  for(Playlists.ListEntry list:incoming.entries()) {
   String name=list.name;int counter=1;
   while(names.contains(name)){String tail=" "+suffix+(counter==1?"":" "+counter);int end=Math.min(list.name.length(),40-tail.length());if(end>0&&end<list.name.length()&&Character.isHighSurrogate(list.name.charAt(end-1)))end--;name=list.name.substring(0,end)+tail;counter++;}
   names.add(name);Playlists.ListEntry target=result.create(name);
   for(SavedSongs.Entry song:list.songs.entries())target.songs.saveInOrder(song.song,song.key);
  }
  return result;
 }
 private static void validate(String payload) throws IOException {
  try {
   Properties p=new Properties();p.load(new StringReader(payload));
   if(!"1".equals(p.getProperty("version")))throw new IOException("Unknown library version");
   int count=number(p,"count",MAX_LISTS),total=0;Set<String> names=new HashSet<>();
   for(int i=0;i<count;i++) {
    String name=p.getProperty(i+".name"),raw=p.getProperty(i+".songs");
    if(name==null||name.trim().isEmpty()||name.length()>40||!name.equals(name.trim())||!names.add(name)||raw==null)throw new IOException("Invalid list");
    Properties rows=new Properties();rows.load(new StringReader(raw));
    if(!"1".equals(rows.getProperty("version")))throw new IOException("Unknown songs version");
    int size=number(rows,"count",MAX_SONGS);total+=size;if(total>MAX_SONGS)throw new IOException("Too many songs");
    Set<String> ids=new HashSet<>();
    for(int j=0;j<size;j++) {
     String prefix=j+".",url=rows.getProperty(prefix+"url"),title=rows.getProperty(prefix+"title"),thumbnail=rows.getProperty(prefix+"thumbnail","");
     int key=Integer.parseInt(rows.getProperty(prefix+"key"));
     if(title==null||title.length()>2000||key< -12||key>12||!ids.add(videoId(url)))throw new IOException("Invalid song");
     if(!thumbnail.isEmpty()) {
      URI uri=URI.create(thumbnail);String host=uri.getHost();
      if(!"https".equalsIgnoreCase(uri.getScheme())||uri.getUserInfo()!=null||uri.getPort()!=-1||(!"i.ytimg.com".equalsIgnoreCase(host)&&!"img.youtube.com".equalsIgnoreCase(host)))throw new IOException("Invalid thumbnail");
     }
    }
   }
  }catch(IllegalArgumentException|NullPointerException e){throw new IOException("Invalid library",e);}
 }
 private static int number(Properties p,String key,int max)throws IOException{int value=Integer.parseInt(p.getProperty(key));if(value<0||value>max)throw new IOException("Invalid count");return value;}
 private static String videoId(String value)throws IOException {
  URI uri=URI.create(value);String host=uri.getHost(),path=uri.getPath(),id=null;
  if(!"https".equalsIgnoreCase(uri.getScheme())||uri.getUserInfo()!=null||uri.getPort()!=-1)throw new IOException("Invalid video URL");
  if("youtu.be".equalsIgnoreCase(host)&&path!=null)id=path.substring(1);
  else if("youtube.com".equalsIgnoreCase(host)||"www.youtube.com".equalsIgnoreCase(host)||"m.youtube.com".equalsIgnoreCase(host)){
   if("/watch".equals(path)&&uri.getRawQuery()!=null){for(String part:uri.getRawQuery().split("&"))if(part.startsWith("v="))id=part.substring(2);}
   else if(path!=null&&path.matches("/(shorts|embed|live)/[^/]+/?"))id=path.split("/")[2];
  }
  if(id==null||!id.matches("[A-Za-z0-9_-]{11}"))throw new IOException("Invalid video ID");return id;
 }
 private static String digest(String text)throws IOException {
  try {byte[] bytes=MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8));StringBuilder hex=new StringBuilder();for(byte b:bytes)hex.append(String.format(Locale.ROOT,"%02x",b));return hex.toString();}
  catch(java.security.NoSuchAlgorithmException e){throw new IOException(e);}
 }
}
