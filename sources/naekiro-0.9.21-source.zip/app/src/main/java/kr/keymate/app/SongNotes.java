package kr.keymate.app;

import java.io.*;
import java.util.*;

/** Latest user-written notes per video. Independent of playlist keys and playback history. */
final class SongNotes {
 static final int MAX_ENTRIES=500, MAX_NOTE=280, MAX_TEXT=4*1024*1024;
 enum Rating { NONE, LOW, COMFORTABLE, HIGH }
 enum Stage { NONE, PRACTICING, CONFIDENT }
 static final class Entry {
  final Song song;
  final Rating rating;
  final int ratingKey;
  final long ratedAt,updatedAt;
  final String note;
  final Stage stage;
  Entry(Song song,Rating rating,int key,long ratedAt,String note,Stage stage,long updatedAt){
   this.song=song;this.rating=rating;ratingKey=key;this.ratedAt=ratedAt;this.note=note;this.stage=stage;this.updatedAt=updatedAt;
  }
 }
 private final Map<String,Entry> notes=new LinkedHashMap<>();
 List<Entry> entries(){List<Entry> result=new ArrayList<>(notes.values());result.sort(Comparator.comparingLong((Entry e)->e.updatedAt).reversed());return Collections.unmodifiableList(result);}
 Entry find(String url){String canonical=SearchSafety.canonicalVideo(url);return canonical==null?null:notes.get(canonical);}
 SongNotes copy(){SongNotes result=new SongNotes();result.notes.putAll(notes);return result;}
 void remove(String url){String canonical=SearchSafety.canonicalVideo(url);if(canonical!=null)notes.remove(canonical);}
 // A null rating means metadata-only editing: keep the original rating, key and date.
 void put(Song song,Integer key,Rating rating,String note,Stage stage,long now){
  String url=SearchSafety.canonicalVideo(song.url);
  if(url==null||song.title==null||song.title.length()>2000||note==null||note.length()>MAX_NOTE||stage==null||now<=0)throw new IllegalArgumentException("Invalid note");
  Entry previous=notes.get(url);
  Rating value=rating==null?(previous==null?Rating.NONE:previous.rating):rating;
  int ratedKey=previous==null?0:previous.ratingKey;long ratedAt=previous==null?0:previous.ratedAt;
  if(rating!=null){
   if(rating==Rating.NONE){ratedKey=0;ratedAt=0;}
   else {if(key==null||key< -12||key>12)throw new IllegalArgumentException("Invalid rating key");ratedKey=key;ratedAt=now;}
  }
  String clean=note.trim();
  if(value==Rating.NONE&&stage==Stage.NONE&&clean.isEmpty()){notes.remove(url);return;}
  if(previous==null&&notes.size()>=MAX_ENTRIES)throw new IllegalArgumentException("Notebook full");
  String thumbnail=SearchSafety.thumbnail(song.thumbnailUrl)?song.thumbnailUrl:"";
  notes.put(url,new Entry(new Song(url,song.title,thumbnail),value,ratedKey,ratedAt,clean,stage,Math.max(now,previous==null?0:previous.updatedAt)));
 }
 String encode()throws IOException {
  Properties p=new Properties();p.setProperty("songNotesVersion","1");p.setProperty("count",Integer.toString(notes.size()));
  int i=0;for(Entry e:entries()){
   String prefix=(i++)+".";p.setProperty(prefix+"url",e.song.url);p.setProperty(prefix+"title",e.song.title);p.setProperty(prefix+"thumbnail",e.song.thumbnailUrl);
   p.setProperty(prefix+"rating",e.rating.name());p.setProperty(prefix+"key",Integer.toString(e.ratingKey));p.setProperty(prefix+"ratedAt",Long.toString(e.ratedAt));
   p.setProperty(prefix+"note",e.note);p.setProperty(prefix+"stage",e.stage.name());p.setProperty(prefix+"updatedAt",Long.toString(e.updatedAt));
  }
  StringWriter text=new StringWriter();p.store(text,"Naekiro personal song notes");if(text.getBuffer().length()>MAX_TEXT)throw new IOException("Notebook too large");return text.toString();
 }
 static SongNotes decode(String text)throws IOException {
  SongNotes result=new SongNotes();if(text==null||text.isEmpty())return result;
  if(text.length()>MAX_TEXT)throw new IOException("Notebook too large");
  try {
   Properties p=new Properties();p.load(new StringReader(text));if(!"1".equals(p.getProperty("songNotesVersion")))throw new IOException("Unknown notebook version");
   int count=Integer.parseInt(p.getProperty("count"));if(count<0||count>MAX_ENTRIES)throw new IOException("Invalid note count");
   for(int i=0;i<count;i++){
    String prefix=i+".",url=SearchSafety.canonicalVideo(p.getProperty(prefix+"url")),title=p.getProperty(prefix+"title"),thumbnail=p.getProperty(prefix+"thumbnail",""),note=p.getProperty(prefix+"note");
    Rating rating=Rating.valueOf(p.getProperty(prefix+"rating"));Stage stage=Stage.valueOf(p.getProperty(prefix+"stage"));
    int key=Integer.parseInt(p.getProperty(prefix+"key"));long ratedAt=Long.parseLong(p.getProperty(prefix+"ratedAt")),updatedAt=Long.parseLong(p.getProperty(prefix+"updatedAt"));
    if(url==null||result.notes.containsKey(url)||title==null||title.length()>2000||note==null||note.length()>MAX_NOTE||key< -12||key>12||updatedAt<=0||ratedAt<0||ratedAt>updatedAt||(!thumbnail.isEmpty()&&!SearchSafety.thumbnail(thumbnail)))throw new IOException("Invalid note");
    if((rating==Rating.NONE&&(ratedAt!=0||key!=0))||(rating!=Rating.NONE&&ratedAt==0))throw new IOException("Invalid rating");
    result.notes.put(url,new Entry(new Song(url,title,thumbnail),rating,key,ratedAt,note,stage,updatedAt));
   }
   return result;
  }catch(IllegalArgumentException|NullPointerException e){throw new IOException("Invalid notebook",e);}
 }
 static SongNotes merge(SongNotes current,SongNotes incoming)throws IOException {
  SongNotes result=current.copy();
  for(Entry e:incoming.entries())if(!result.notes.containsKey(e.song.url))result.notes.put(e.song.url,e);
  if(result.notes.size()>MAX_ENTRIES)throw new IOException("Notebook full");return result;
 }
}
