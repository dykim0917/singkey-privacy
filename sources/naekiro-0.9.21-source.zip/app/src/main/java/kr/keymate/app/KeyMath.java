package kr.keymate.app;
public final class KeyMath {
 private KeyMath() {}
 public static float ratio(int semitones) { return (float)Math.pow(2.0, semitones / 12.0); }
 public static int clamp(int key) { return Math.max(-12, Math.min(12, key)); }
}
