package kr.keymate.app;

import com.grack.nanojson.*;
import java.io.IOException;
import java.util.*;

/** Public payloads are deliberately separate from private notes and library backups. */
final class CommunityData {
 static final int MAX_SONGS=50, MAX_TITLE=80;
 static final String RULES_VERSION="2026-09-28";
 static final class Track {
  final String videoId,title; final Integer key;
  Track(String id,String title,Integer key) throws IOException {
   if(id==null||!id.matches("[A-Za-z0-9_-]{11}")||!text(title,200)||key!=null&&(key < -12||key>12))throw new IOException("Invalid track");
   this.videoId=id;this.title=title;this.key=key;
  }
  Song song(){return new Song("https://www.youtube.com/watch?v="+videoId,title,"https://i.ytimg.com/vi/"+videoId+"/hqdefault.jpg");}
  JsonObject json(boolean includeKey){JsonObject j=new JsonObject();j.put("video_id",videoId);j.put("title",title);if(includeKey&&key!=null)j.put("key",key);return j;}
 }
 static final class ListItem {
  final String id,owner,title,nickname;final List<Track> tracks;final boolean liked,curated;final int likes;
  ListItem(JsonObject j) throws IOException {
   id=uuid(j.getString("id"));owner=uuid(j.getString("owner_id"));title=j.getString("title");nickname=j.getString("nickname");
   if(!text(title,MAX_TITLE)||!text(nickname,24))throw new IOException("Invalid public list");
   tracks=Collections.unmodifiableList(tracks(j.getArray("songs")));liked=j.getBoolean("liked");curated=j.getBoolean("curated");likes=j.getInt("likes");if(likes<0)throw new IOException("Invalid count");
  }
 }
 static final class Draft {
  final String requestId,title; final List<Track> tracks; final boolean shareKeys;
  Draft(String requestId,String title,List<Track> tracks,boolean shareKeys) throws IOException {
   this.requestId=uuid(requestId);if(!text(title,MAX_TITLE)||tracks==null||tracks.isEmpty()||tracks.size()>MAX_SONGS)throw new IOException("Invalid draft");
   HashSet<String> seen=new HashSet<>();for(Track t:tracks)if(!seen.add(t.videoId))throw new IOException("Duplicate video");
   this.title=title.trim();this.tracks=Collections.unmodifiableList(new ArrayList<>(tracks));this.shareKeys=shareKeys;
  }
  JsonObject json(){JsonObject j=new JsonObject();j.put("p_request_id",requestId);j.put("p_title",title);JsonArray songs=new JsonArray();for(Track t:tracks)songs.add(t.json(shareKeys));j.put("p_songs",songs);j.put("p_rules",RULES_VERSION);return j;}
  String encode(){JsonObject j=json();j.put("share_keys",shareKeys);return JsonWriter.string(j);}
  static Draft decode(String source)throws IOException{try{JsonObject j=JsonParser.object().from(source);return new Draft(j.getString("p_request_id"),j.getString("p_title"),tracks(j.getArray("p_songs")),j.getBoolean("share_keys"));}catch(JsonParserException|RuntimeException e){throw new IOException("Invalid draft",e);}}
 }
 static List<Track> tracks(JsonArray array)throws IOException{
  if(array==null||array.isEmpty()||array.size()>MAX_SONGS)throw new IOException("Invalid songs");List<Track> result=new ArrayList<>();HashSet<String> seen=new HashSet<>();
  for(Object value:array){if(!(value instanceof JsonObject))throw new IOException("Invalid song");JsonObject j=(JsonObject)value;
   Integer key=null;if(j.containsKey("key")&&j.get("key")!=null){Object v=j.get("key");if(!(v instanceof Number)||((Number)v).doubleValue()!=((Number)v).intValue())throw new IOException("Invalid key");key=((Number)v).intValue();}
   Track t=new Track(j.getString("video_id"),j.getString("title"),key);if(!seen.add(t.videoId))throw new IOException("Duplicate song");result.add(t);
  }return result;
 }
 static List<ListItem> lists(String raw)throws IOException{try{JsonArray a=JsonParser.array().from(raw);if(a.size()>50)throw new IOException("Too many lists");List<ListItem> result=new ArrayList<>();for(Object o:a){if(!(o instanceof JsonObject))throw new IOException("Invalid list");result.add(new ListItem((JsonObject)o));}return result;}catch(JsonParserException|RuntimeException e){throw new IOException("Invalid feed",e);}}
 static Playlists importCopy(Playlists current,ListItem source,boolean useSharedKeys)throws IOException {
  Playlists result=Playlists.restore(current.encode(),"");String base=source.title.substring(0,Math.min(40,source.title.length())).trim(),name=base;int suffix=2;
  while(hasName(result,name)){String tail=" ("+(suffix++)+")";name=base.substring(0,Math.min(base.length(),40-tail.length()))+tail;}
  Playlists.ListEntry target=result.create(name);
  for(Track t:source.tracks){int key=0;for(Playlists.ListEntry l:current.entries()){SavedSongs.Entry saved=l.songs.find(t.song().url);if(saved!=null){key=saved.key;break;}}
   if(useSharedKeys&&t.key!=null)key=t.key;target.songs.saveInOrder(t.song(),key);
  }return result;
 }
 private static boolean hasName(Playlists p,String name){for(Playlists.ListEntry l:p.entries())if(l.name.equals(name))return true;return false;}
 static String uuid(String value)throws IOException{if(value==null||!value.matches("[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}"))throw new IOException("Invalid id");return value;}
 static boolean text(String value,int limit){return value!=null&&!value.trim().isEmpty()&&value.length()<=limit&&value.chars().noneMatch(Character::isISOControl);}
 private CommunityData(){}
}
