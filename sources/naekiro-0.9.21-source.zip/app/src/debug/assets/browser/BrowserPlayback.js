function(config) {
    'use strict';
    if (!['m.youtube.com', 'www.youtube.com', 'youtube.com'].includes(location.hostname)) return;
    const productEvents = new Set(['ready', 'playing', 'paused', 'ended', 'page_changed', 'pitch_pending', 'pitch_active', 'pitch_unavailable', 'pitch_unsupported', 'ad_playing', 'original', 'audio_muted', 'sound_preference']);
    const send = (event, detail = {}) => {
        if (config.diagnostics === false && !productEvents.has(event)) return;
        window.webkit.messageHandlers.singkeyBrowser.postMessage({token: config.token, event, ...detail});
    };
    send('capabilities', {decoder: typeof AudioDecoder === 'function', mse: typeof MediaSource === 'function' || typeof ManagedMediaSource === 'function'});
    if (config.bufferMode) { new SingKeyBufferedPlayback(config, send); return; }
    // Metadata-only probe. Native arguments, returned buffers and network requests
    // are unchanged. Page-world probing is explicitly selected at launch.
    const probed = new Set();
    for (const Type of [globalThis.MediaSource, globalThis.ManagedMediaSource]) {
        if (!Type || probed.has(Type.prototype)) continue;
        probed.add(Type.prototype);
        const add = Type.prototype.addSourceBuffer;
        Type.prototype.addSourceBuffer = function(type) {
            const result = Reflect.apply(add, this, [type]);
            const kind = type.startsWith('audio/') ? type.includes('mp4a') ? 'aac' : type.includes('opus') ? 'opus' : 'other_audio' : 'video';
            send('buffer_type', {kind});
            return result;
        };
    }
    let video, graph, graphTask, key = config.key, pausedByApp = false, changed = false, lastPitch = '';
    const matches = () => new URL(location.href).searchParams.get('v') === config.videoID;
    const isAd = () => !!document.querySelector('.ad-showing, .ad-interrupting');
    const pitchState = state => { if (lastPitch !== state) { lastPitch = state; send(state); } };
    const diagnostic = reason => send('diagnostic', {reason});
    function markPlaying() {
        if (!matches() || isAd()) return;
        if (pausedByApp) { video.pause(); return; }
        send('playing');
    }
    function bind() {
        if (!matches()) {
            if (!changed) { changed = true; video?.pause(); send('page_changed'); }
            return;
        }
        changed = false;
        const next = document.querySelector('video');
        if (!next || next === video) return;
        if (video) { diagnostic('video_replaced'); graph?.source.disconnect(); graph?.context.close(); graph = undefined; }
        video = next;
        const bound = video;
        video.addEventListener('playing', () => { if (video === bound) markPlaying(); });
        video.addEventListener('pause', () => { if (video === bound && matches() && !isAd()) send('paused'); });
        video.addEventListener('ended', () => { if (video === bound && matches() && !isAd()) send('ended'); });
        video.addEventListener('seeking', () => graph?.node.port.postMessage('reset'));
        video.addEventListener('error', () => diagnostic('media_error'));
        if (pausedByApp) video.pause();
        send('ready');
        if (!video.paused && video.readyState >= 2) markPlaying();
    }
    async function preparePitch() {
        bind();
        if (!video || !matches()) return;
        if (graph) { await graph.context.resume(); return; }
        if (graphTask) return graphTask;
        const target = video;
        graphTask = (async () => {
            const context = new AudioContext({latencyHint: 'interactive'});
            let source;
            try {
                if (!context.audioWorklet) { diagnostic('worklet_unavailable'); throw new Error(); }
                const moduleURL = URL.createObjectURL(new Blob([config.processor], {type: 'application/javascript'}));
                try { await context.audioWorklet.addModule(moduleURL); }
                catch { diagnostic('module_error'); throw new Error(); }
                finally { URL.revokeObjectURL(moduleURL); }
                if (target !== video || !matches()) { await context.close(); return; }
                const wasm = Uint8Array.from(atob(config.wasm), c => c.charCodeAt(0));
                const node = new AudioWorkletNode(context, 'singkey-browser-pitch', {outputChannelCount: [2], processorOptions:{wasm}});
                node.onprocessorerror = () => { diagnostic('processor_error'); pitchState('pitch_unavailable'); };
                const before = context.createAnalyser(), after = context.createAnalyser();
                before.fftSize = 2048; after.fftSize = 2048;
                // Browser CORS rules remain enabled. A blocked source may be silent;
                // this prototype reports that instead of claiming successful pitch.
                source = context.createMediaElementSource(target);
                source.connect(before); before.connect(node); node.connect(after); after.connect(context.destination);
                graph = {context, source, node, before, after, samples: new Float32Array(2048), silent: 0};
                node.parameters.get('key').value = isAd() ? 0 : key;
                await context.resume();
                pitchState('pitch_pending');
            } catch {
                diagnostic('graph_error'); pitchState('pitch_unavailable');
                // If routing was already changed, restore the direct Web Audio path.
                // A source blocked by CORS cannot be repaired by changing headers.
                if (source) { source.disconnect(); source.connect(context.destination); }
                else await context.close();
            }
        })();
        try { await graphTask; } finally { graphTask = undefined; }
    }
    function rms(analyser, samples) {
        analyser.getFloatTimeDomainData(samples);
        let sum = 0; for (let i = 0; i < samples.length; i++) sum += samples[i] * samples[i];
        return Math.sqrt(sum / samples.length);
    }
    globalThis.singkeyBrowserControl = async (name, value) => {
        bind(); if (!video || !matches()) return;
        if (name === 'pause') { pausedByApp = true; video.pause(); return; }
        if (name === 'toggle') {
            pausedByApp = !video.paused;
            if (pausedByApp) video.pause();
            else { await graph?.context.resume(); try { await video.play(); } catch { send('ready'); } }
        }
        if (name === 'key' && Number.isInteger(value) && value >= -12 && value <= 12) {
            key = value;
            // A silent/failed graph is not proof that key0 restored original audio.
            // The native recovery button reloads the page with key0 explicitly.
            if (lastPitch === 'pitch_unavailable') return;
            if (key !== 0) await preparePitch();
            if (graph) { graph.node.parameters.get('key').setValueAtTime(isAd() ? 0 : key, graph.context.currentTime); pitchState(key === 0 ? 'original' : 'pitch_pending'); }
            else if (key === 0) pitchState('original');
        }
    };
    document.addEventListener('click', event => {
        if (!event.isTrusted) return;
        pausedByApp = false;
        if (key !== 0 && lastPitch !== 'pitch_unavailable') preparePitch();
    }, {capture: true});
    setInterval(() => {
        bind();
        if (!video || !matches() || video.paused || video.seeking) return;
        const src = video.currentSrc;
        const source = !src ? 'empty' : src.startsWith('blob:') ? 'blob' : src.includes('.m3u8') || src.includes('/hls') ? 'hls' : 'network';
        send('media_state', {muted: video.muted, volume: video.volume, ready: video.readyState, time: video.currentTime, rate: video.playbackRate, source, graph: !!graph, context: graph?.context.state || 'none'});
        if (key !== 0 && !graph && !graphTask && lastPitch !== 'pitch_unavailable') preparePitch();
        if (!graph) return;
        const appliedKey = isAd() ? 0 : key;
        graph.node.parameters.get('key').value = appliedKey;
        const input = rms(graph.before, graph.samples), output = rms(graph.after, graph.samples);
        if (graph.context.state !== 'running') { diagnostic('context_suspended'); pitchState('pitch_pending'); }
        else if (input > 0.00001 && output > 0.00001) { graph.silent = 0; pitchState(appliedKey === 0 ? 'original' : 'pitch_active'); }
        else if (++graph.silent === 5) { diagnostic('source_silent'); pitchState('pitch_unavailable'); }
        send('metrics', {input, output, time: video.currentTime, key: appliedKey});
    }, 1000);
    bind();
}
