// Repository Sonic/PitchDSP compiled to WASM. No render-callback allocation/logging.
class SingKeyBrowserPitch extends AudioWorkletProcessor {
    static get parameterDescriptors() { return [{name:'key', defaultValue:0, minValue:-12, maxValue:12, automationRate:'k-rate'}]; }
    constructor(options) {
        super();
        this.dsp = new WebAssembly.Instance(new WebAssembly.Module(options.processorOptions.wasm), {}).exports;
        this.handle = this.dsp.SKPitchCreate(sampleRate, 2);
        this.pointers = this.dsp.malloc(8);
        const left = this.dsp.malloc(1024), right = this.dsp.malloc(1024);
        if (!this.handle || !this.pointers || !left || !right) throw new Error('pitch_allocation');
        new Uint32Array(this.dsp.memory.buffer, this.pointers, 2).set([left, right]);
        this.left = new Float32Array(this.dsp.memory.buffer, left, 256);
        this.right = new Float32Array(this.dsp.memory.buffer, right, 256);
        this.key = 0;
        this.port.onmessage = event => {
            if (event.data?.type === 'health') this.port.postMessage({
                generation:event.data.generation,
                healthy:this.dsp.SKPitchIsHealthy(this.handle) === 1,
                key:this.key,
                frames:Number(this.dsp.SKPitchProcessedFrames(this.handle)),
                audible:Number(this.dsp.SKPitchAudibleFrames(this.handle))
            });
            else if (event.data === 'reset') this.dsp.SKPitchReset(this.handle);
        };
    }
    process(inputs, outputs, parameters) {
        const input = inputs[0], output = outputs[0], count = output[0].length;
        if (count > 256) return false;
        const key = Math.round(parameters.key[0]);
        if (key !== this.key) { this.dsp.SKPitchSetKey(this.handle, key); this.key = key; }
        for (let i = 0; i < count; i++) { this.left[i] = input[0]?.[i] || 0; this.right[i] = input[1]?.[i] ?? this.left[i]; }
        this.dsp.SKPitchProcess(this.handle, this.pointers, count, 1);
        for (let i = 0; i < count; i++) { output[0][i] = this.left[i]; if (output[1]) output[1][i] = this.right[i]; }
        return true;
    }
}
registerProcessor('singkey-browser-pitch', SingKeyBrowserPitch);
