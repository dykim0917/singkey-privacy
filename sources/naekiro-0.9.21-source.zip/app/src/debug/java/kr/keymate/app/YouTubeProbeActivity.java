package kr.keymate.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;

/** Reproducible, isolated debug screen; does not access the user's library or analytics. */
@android.annotation.SuppressLint("SetTextI18n") // Diagnostic labels, never shipped in Release.
public final class YouTubeProbeActivity extends Activity {
 private YouTubeIframePlayer player;
 private TextView status;
 private String videoID;
 @Override public void onCreate(Bundle saved){
  super.onCreate(saved);
  if(!BuildConfig.YOUTUBE_IFRAME){finish();return;}
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setFitsSystemWindows(true);setContentView(root);
  status=new TextView(this);status.setText("YouTube API test");root.addView(status);
  player=new YouTubeIframePlayer(this);
  root.addView(player,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout keys=new LinearLayout(this);root.addView(keys);
  button(keys,"−2",()->player.setKey(-2));button(keys,"0",()->player.setKey(0));button(keys,"+2",()->player.setKey(2));
  LinearLayout controls=new LinearLayout(this);root.addView(controls);
  button(controls,"Play",()->player.play());button(controls,"Pause",()->player.pause());button(controls,"+10s",()->player.seekTo(player.getCurrentPosition()+10000));
  Button reload=new Button(this);reload.setText("Reload original key");reload.setOnClickListener(v->loadOriginal());root.addView(reload);
  player.addListener(new PlaybackPlayer.Listener(){
   public void onIsPlayingChanged(boolean value){status.setText("playing="+value+" position="+player.getCurrentPosition());}
   public void onPlaybackStateChanged(int value){status.setText("state="+value);}
   public void onPlayerError(Exception error){status.setText(error.getMessage());}
   public void onPitchUnavailable(){status.setText("Pitch unavailable — choose original key and reload");}
  });
  String id=getIntent().getStringExtra("video");
  if(id==null||!id.matches("[A-Za-z0-9_-]{11}"))id="M7lc1UVf-VE";
  videoID=id;loadOriginal();
 }
 private void loadOriginal(){player.load("https://www.youtube.com/watch?v="+videoID,0,0,true);}
 private void button(LinearLayout row,String label,Runnable action){Button b=new Button(this);b.setText(label);b.setOnClickListener(v->action.run());row.addView(b,new LinearLayout.LayoutParams(0,-2,1));}
 @Override protected void onStop(){if(player!=null)player.pause();super.onStop();}
 @Override protected void onDestroy(){if(player!=null)player.release();super.onDestroy();}
}
