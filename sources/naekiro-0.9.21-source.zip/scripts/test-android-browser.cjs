// Run with Node. Exercises the actual packaged DSP and player state script.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const root=path.resolve(__dirname,'../app/src/main/assets/browser');
const dspCode=fs.readFileSync(path.join(root,'AndroidPitchDSP.js'),'utf8');
const playerCode=fs.readFileSync(path.join(root,'AndroidBrowserPlayback.js'),'utf8');
const wasm=new Uint8Array(fs.readFileSync(path.join(root,'BrowserPitchDSP.wasm')));
const DSP=vm.runInNewContext(dspCode+';SingKeyAndroidDSP',{WebAssembly,Uint32Array,Float32Array});
const report=[];
const latencyReport=[];
const regroupingReport=[];
// Bound browser batching separately from Sonic's FIFO; this is not an A/V sync measurement.
for(const rate of [44100,48000]){
 const dsp=new DSP(wasm,rate),frames=dsp.frames;
 assert(frames/rate<=.024,'browser callback batch must stay within 24 ms');
 const input=new Float32Array(frames),output=new Float32Array(frames);let first=-1;
 for(let n=0;n<rate*.2;n+=frames){
  for(let i=0;i<frames;i++)input[i]=n+i<rate*.05?.1*Math.sin(2*Math.PI*440*(n+i)/rate):0;
  dsp.process(input,input,output,null,2);
  if(first<0){const at=output.findIndex(v=>Math.abs(v)>.000001);if(at>=0)first=n+at;}
 }
 assert(first>=0);assert(Math.abs(first/rate-.08)<.001,'track the remaining 80 ms DSP delay');
 latencyReport.push({rate,frames,batchMs:frames/rate*1000,dspOnsetMs:first/rate*1000});dsp.destroy();
}
// Larger browser callbacks must only regroup the same DSP samples. Align the
// key boundary in both runs so this checks buffering, not different command times.
for(const rate of [44100,48000]){
 const total=Math.ceil(rate*2/1024)*1024,changeAt=Math.ceil(rate/1024)*1024;
 const input=[new Float32Array(total),new Float32Array(total)];
 for(let i=0;i<total;i++){
  const t=i/rate;
  input[0][i]=.12*Math.sin(2*Math.PI*220*t)+.08*Math.sin(2*Math.PI*277.1826*t);
  input[1][i]=.13*Math.sin(2*Math.PI*330*t)+.06*Math.sin(2*Math.PI*550*t);
 }
 function render(frames,changeKey){
  const dsp=new DSP(wasm,rate,frames),output=[new Float32Array(total),new Float32Array(total)];
  const block=[new Float32Array(frames),new Float32Array(frames)];
  for(let n=0;n<total;n+=frames){
   dsp.process(input[0].subarray(n,n+frames),input[1].subarray(n,n+frames),...block,changeKey&&n>=changeAt?-3:-2);
   assert(dsp.healthy());output[0].set(block[0],n);output[1].set(block[1],n);
  }
  dsp.destroy();return output;
 }
 for(const changeKey of [false,true]){
  const small=render(512,changeKey),large=render(1024,changeKey);
  for(let c=0;c<2;c++)assert.equal(Buffer.compare(Buffer.from(small[c].buffer),Buffer.from(large[c].buffer)),0,`${rate}/${changeKey?'key change':'fixed -2'}/channel ${c}: callback regrouping changed DSP samples`);
  regroupingReport.push({rate,frames:[512,1024],keys:changeKey?[-2,-3]:[-2],identical:true});
 }
}
for(const rate of [44100,48000])for(const key of [-12,-5,-2,0,2,5,12]){
 const dsp=new DSP(wasm,rate),memory=dsp.dsp.memory.buffer.byteLength,frames=dsp.frames;
 const input=[new Float32Array(frames),new Float32Array(frames)],output=[new Float32Array(frames),new Float32Array(frames)],samples=[];
 for(let n=0;n<rate*3;n+=frames){
  for(let i=0;i<frames;i++)input[0][i]=.1*Math.sin(2*Math.PI*440*(n+i)/rate);
  dsp.process(...input,...output,key);assert(dsp.healthy());
  assert(output[0].every(Number.isFinite));assert(output[1].every(x=>x===0));
  if(n>=rate)samples.push(...output[0]);
 }
 const expected=440*2**(key/12),segment=samples.slice(0,rate);
 const weighted=segment.map((v,i)=>v*(.5-.5*Math.cos(2*Math.PI*i/(segment.length-1))));
 let peak=0,measured=0;
 for(let hz=expected-6;hz<=expected+6;hz+=.025){const a=2*Math.cos(2*Math.PI*hz/rate);let x=0,y=0;for(const v of weighted){const z=v+a*x-y;y=x;x=z;}const power=x*x+y*y-a*x*y;if(power>peak){peak=power;measured=hz;}}
 const cents=1200*Math.log2(measured/expected);assert(Math.abs(cents)<10,`${rate}/${key}: ${cents} cents`);
 dsp.reset();input[0].fill(0);
 for(let b=0;b<30;b++){dsp.process(...input,...output,key);assert(output.every(c=>c.every(x=>x===0)));}
 assert.equal(dsp.dsp.memory.buffer.byteLength,memory);
 report.push({rate,key,cents});dsp.destroy();
}
// Stress repeated key changes for one minute without a growing WASM heap.
for(const rate of [44100,48000]){
 const dsp=new DSP(wasm,rate),size=dsp.dsp.memory.buffer.byteLength,frames=dsp.frames;
 const left=new Float32Array(frames),right=new Float32Array(frames),outL=new Float32Array(frames),outR=new Float32Array(frames);
 for(let n=0;n<rate*60;n+=frames){for(let i=0;i<frames;i++){left[i]=.1*Math.sin(2*Math.PI*220*(n+i)/rate);right[i]=.1*Math.sin(2*Math.PI*330*(n+i)/rate);}dsp.process(left,right,outL,outR,Math.floor(n/(rate*.25))%25-12);assert(outL.every(Number.isFinite)&&outR.every(Number.isFinite));}
 assert.equal(dsp.dsp.memory.buffer.byteLength,size);assert(dsp.healthy());dsp.destroy();
}
function fixture(){
 let now=0,ad=false,tick;const events=[],handlers={},docHandlers={};
 const video={paused:true,ended:false,readyState:4,currentTime:0,duration:100,muted:false,
  addEventListener:(n,f)=>handlers[n]=f,pause(){this.paused=true;handlers.pause?.();},async play(){this.paused=false;handlers.playing?.();}};
 const window={singkeyNative:{postMessage:value=>events.push(JSON.parse(value))}};window.top=window;
 const document={hidden:false,querySelector:selector=>selector==='video'?video:ad?{}:null,addEventListener:(n,f)=>docHandlers[n]=f};
 const context={window,document,location:{hostname:'m.youtube.com',href:'https://m.youtube.com/watch?v=Upe2ewoz1PI'},URL,performance:{now:()=>now},setInterval:f=>tick=f};
 vm.runInNewContext(`(${playerCode})({token:'test',videoID:'Upe2ewoz1PI',key:0,autoplay:true,position:0})`,context);tick();
 return {video,events,handlers,document,context,setAd:value=>ad=value,step(ms=250){now+=ms;tick();},control:context.singkeyBrowserControl};
}
(async()=>{
 const f=fixture();await f.video.play();f.video.currentTime=99;f.step();
 f.setAd(true);f.video.currentTime=5;f.step();f.setAd(false);f.video.ended=true;f.handlers.ended();f.step();
 assert(!f.events.some(e=>e.event==='ended'),'ad completion must not advance queue');
 f.video.ended=false;f.video.currentTime=99.2;f.step();f.step(1100);f.video.ended=true;f.handlers.ended();f.step();
 assert.equal(f.events.filter(e=>e.event==='ended').length,1,'real completion emitted once');
 const p=fixture();await p.video.play();await p.control('layout',0);p.video.pause();p.step();assert(!p.video.paused,'rotation resumes previously playing content');
 await p.control('pause',0);p.step();assert(p.video.paused,'explicit pause cancels rotation resume');
 await p.control('layout',0);p.step();assert(p.video.paused,'paused rotation remains paused');
 const n=fixture();await n.video.play();n.context.location.href='https://m.youtube.com/watch?v=XXXXXXXXXXX';n.step();assert(n.video.paused);assert(n.events.some(e=>e.event==='page_changed'));
 const m=fixture();m.video.muted=true;await m.video.play();m.video.currentTime=1;m.step();assert(!m.events.some(e=>e.event==='playing'),'muted autoplay is not practice');m.video.muted=false;m.video.currentTime=2;m.step();assert(m.events.some(e=>e.event==='playing'));
 console.log(JSON.stringify({pass:true,dspCases:report.length,latencyReport,regroupingReport,maxErrorCents:Math.max(...report.map(r=>Math.abs(r.cents))),rapidKeysSeconds:120,stateChecks:['ad completion','single content completion','rotation resume','explicit pause','paused rotation','changed video','muted practice excluded'],report},null,2));
})().catch(error=>{console.error(error);process.exitCode=1;});
