// Behavioral checks for the packaged official controller and optional Web Audio adapter.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const assets=path.resolve(__dirname,'../app/src/main/assets/browser');
const controller=fs.readFileSync(path.join(assets,'YouTubeIframePlayback.js'),'utf8');
const pitch=fs.readFileSync(path.join(assets,'YouTubeIframePitch.js'),'utf8');
function playerFixture(overrides={}){
 let now=0,tick,options,state=-1;const messages=[],calls=[],handlers={};
 const fake={playVideo(){calls.push('play');},pauseVideo(){calls.push('pause');},destroy(){calls.push('destroy');},seekTo(v){calls.push(['seek',v]);},cueVideoById(v){calls.push(['cue',v.videoId,v.startSeconds]);},
  getPlayerState:()=>state,getVideoUrl:()=>'https://www.youtube.com/watch?v=M7lc1UVf-VE',getCurrentTime:()=>42,isMuted:()=>false,getVolume:()=>100};
 const document={hidden:false,addEventListener:(n,f)=>handlers[n]=f,createElement:()=>({}),head:{appendChild:s=>calls.push(['script',s.src])}};
 const context={document,URL,location:{origin:'https://kr.keymate.app.youtubeprobe'},performance:{now:()=>now},setInterval:f=>tick=f};
 context.window=context;context.top=context;context.singkeyNative={postMessage:s=>messages.push(JSON.parse(s))};
 context.YT={Player:function(id,opts){options=opts;return fake;}};
 vm.runInNewContext(`(${controller})(${JSON.stringify({token:'session',videoID:'M7lc1UVf-VE',origin:context.location.origin,key:0,position:0,autoplay:true,pitchEnabled:true,...overrides})})`,context);
 context.onYouTubeIframeAPIReady();
 return {context,document,calls,messages,fake,handlers,ready:()=>options.events.onReady(),state(v){state=v;options.events.onStateChange({data:v});},
  error:code=>options.events.onError({data:code}),blocked:()=>options.events.onAutoplayBlocked(),step(){now+=1000;tick();},control:context.singkeyBrowserControl};
}
const RealDSP=vm.runInNewContext(fs.readFileSync(path.join(assets,'AndroidPitchDSP.js'),'utf8')+';SingKeyAndroidDSP',{WebAssembly,Uint32Array,Float32Array});
const wasm=fs.readFileSync(path.join(assets,'BrowserPitchDSP.wasm')).toString('base64');
const checks=[];
function test(name,fn){fn();checks.push(name);}
test('pause before ready suppresses initial autoplay',()=>{const f=playerFixture();f.control('pause',0);f.ready();assert(!f.calls.includes('play'));});
test('late playing event cannot undo explicit pause',()=>{const f=playerFixture();f.ready();f.state(1);f.control('pause',0);f.state(1);assert.equal(f.messages.at(-1).event,'paused');f.state(2);f.control('play',0);f.state(1);assert.equal(f.messages.at(-1).event,'playing');});
test('user can resume from official controls after pause acknowledgement',()=>{const f=playerFixture();f.ready();f.state(1);f.control('pause',0);f.state(2);f.state(1);assert.equal(f.messages.at(-1).event,'playing');});
test('pausing a cued video does not block its first official play click',()=>{const f=playerFixture({autoplay:false});f.ready();f.state(5);f.control('pause',0);f.state(1);assert.equal(f.messages.at(-1).event,'playing');});
test('pitch playback is reported only after the matching key is active',()=>{const f=playerFixture({key:-2});f.ready();f.state(1);assert(!f.messages.some(m=>m.event==='playing'));f.control('pitch_active',2);f.step();assert(!f.messages.some(m=>m.event==='playing'));f.control('pitch_active',-2);f.step();assert(f.messages.some(m=>m.event==='playing'));});
test('missing frame adapter fails after the playback grace period',()=>{const f=playerFixture({key:2});f.ready();f.state(1);for(let i=0;i<16;i++)f.step();assert.equal(f.messages.filter(m=>m.event==='pitch_unavailable').length,1);assert(f.calls.includes('pause'));assert(!f.messages.some(m=>m.event==='playing'));});
test('ads do not count as practice while frame reports an ad',()=>{const f=playerFixture();f.ready();f.state(1);f.control('ad',1);assert.equal(f.messages.at(-1).event,'paused');f.step();assert.equal(f.messages.at(-1).event,'paused');f.control('ad',0);f.step();assert(f.messages.slice(-2).some(m=>m.event==='playing'));});
test('official ended event advances exactly once',()=>{const f=playerFixture();f.ready();f.state(1);f.state(0);f.state(0);assert.equal(f.messages.filter(m=>m.event==='ended').length,1);});
test('stop discards subsequent callbacks',()=>{const f=playerFixture();f.ready();f.control('stop',0);const n=f.messages.length;f.state(1);f.error(153);f.step();assert.equal(f.messages.length,n);assert(f.calls.includes('destroy'));});
test('autoplay blocked leaves an idle usable player',()=>{const f=playerFixture();f.ready();f.blocked();assert.equal(f.messages.at(-1).event,'autoplay_blocked');f.state(1);assert.equal(f.messages.at(-1).event,'playing');});
test('nonzero key is not silently ignored in API-only mode',()=>{const f=playerFixture({pitchEnabled:false});f.ready();f.control('key',2);f.state(1);assert.equal(f.messages.at(-1).event,'pitch_unavailable');assert(f.calls.includes('pause'));});
test('visibility pauses instead of enabling background play',()=>{const f=playerFixture();f.ready();f.state(1);f.document.hidden=true;f.handlers.visibilitychange();f.state(1);assert.equal(f.messages.at(-1).event,'paused');});
test('changed video does not inherit saved key or practice attribution',()=>{const f=playerFixture();f.ready();f.fake.getVideoUrl=()=>'https://www.youtube.com/watch?v=AAAAAAAAAAA';f.state(1);assert.equal(f.messages.at(-1).event,'failed');assert(f.calls.includes('pause'));assert(!f.messages.some(m=>m.event==='playing'));});
function audioFixture({origin='https://www.youtube.com',pathname='/embed/M7lc1UVf-VE',top=false,realDsp=false,diagnostics=true}={}){
 let now=0,tick,ad=false,media,processMs=0;const messages=[],contexts=[];
 const makeVideo=()=>({paused:false,readyState:4,muted:false,volume:1,handlers:{},addEventListener(n,f){this.handlers[n]=f;}});media=makeVideo();
 class Context{
  constructor(){this.sampleRate=48000;this.state='running';this.destination={};this.gains=[];contexts.push(this);}
  createGain(){const n={gain:{value:1},connect(){}};this.gains.push(n);return n;}
  createScriptProcessor(frames){this.frames=frames;this.node={connect(){}};return this.node;}
  createMediaElementSource(){return {connect(){},disconnect(){}};}
  resume(){this.state='running';return Promise.resolve();}suspend(){this.state='suspended';return Promise.resolve();}close(){return Promise.resolve();}
 }
 class DSP{constructor(){this.frames=1024;this.signal=false;}reset(){this.signal=false;}destroy(){}process(l,r,o,p,key){this.signal=l.some(v=>v!==0);o.set(l);p.set(r);now+=processMs;}levels(){const input=this.signal?.1:0;this.signal=false;return {input,output:input,healthy:true};}}
 const bridge={postMessage:s=>messages.push(JSON.parse(s))};
 const context={location:{origin,pathname},document:{hidden:false,querySelector:s=>s==='video'?media:ad?{}:null,addEventListener(){}},
  performance:{now:()=>now},setInterval:f=>tick=f,AudioContext:Context,SingKeyAndroidDSP:realDsp?RealDSP:DSP,Uint8Array,atob:s=>Buffer.from(s,'base64').toString('binary'),window:{singkeyPitchNative:bridge}};
 context.window.top=top?context.window:{};
 vm.runInNewContext(`(${pitch})({token:'session',videoID:'M7lc1UVf-VE',key:0,diagnostics:${diagnostics},wasm:'${wasm}'})`,context);
 return {messages,contexts,bridge,step(ms=1000){now+=ms;tick?.();},ad(v){ad=v;},paused(v){media.paused=v;},replace(){media=makeVideo();},seek(){media.handlers.seeking?.();},key(key,token='session'){bridge.onmessage?.({data:JSON.stringify({key,token})});},
  process(signal=true,durationMs=0){processMs=durationMs;const c=contexts.at(-1),input=new Float32Array(c.frames).fill(signal?.1:0),out=[new Float32Array(c.frames),new Float32Array(c.frames)];c.node.onaudioprocess({inputBuffer:{getChannelData:()=>input},outputBuffer:{getChannelData:i=>out[i]}});return out;}};
}
test('audio adapter refuses wrong origin, video and main frame',()=>{for(const options of [{origin:'https://evil.example'},{pathname:'/watch'},{top:true}]){const f=audioFixture(options);f.step();assert.equal(f.messages.length,0);assert.equal(f.contexts.length,0);}});
test('stale commands cannot create an audio graph',()=>{const f=audioFixture();f.step();f.key(2,'old');assert.equal(f.contexts.length,0);});
test('nonzero key routes processed audio, ads and zero bypass DSP',()=>{const f=audioFixture();f.step();f.key(-2);let g=f.contexts.at(-1).gains;assert.deepEqual(g.map(n=>n.gain.value),[0,1]);f.process();f.step();assert(f.messages.some(m=>m.event==='pitch_active'&&m.key===-2));f.ad(true);assert(f.process()[0].every(v=>v===0));assert.deepEqual(g.map(n=>n.gain.value),[1,0]);f.step();assert(f.messages.some(m=>m.event==='ad'&&m.active));f.ad(false);f.process();f.step();assert.deepEqual(g.map(n=>n.gain.value),[0,1]);f.key(0);assert.deepEqual(g.map(n=>n.gain.value),[1,0]);});
test('silent inaccessible audio fails once instead of claiming pitch success',()=>{const f=audioFixture();f.step();f.key(2);for(let i=0;i<14;i++){f.process(false);f.step();}assert.equal(f.messages.filter(m=>m.event==='pitch_unavailable').length,1);assert(!f.messages.some(m=>m.event==='pitch_active'));});
test('resume after a long pause allows audio callbacks to restart',()=>{const f=audioFixture();f.step();f.key(-2);f.process();f.step();f.paused(true);f.step(30000);f.paused(false);f.step();assert(!f.messages.some(m=>m.event==='pitch_unavailable'));f.process();f.step();assert.equal(f.messages.filter(m=>m.event==='pitch_active').length,2);});
test('resume grace period still detects a stalled audio callback',()=>{const f=audioFixture();f.step();f.key(2);f.process();f.step();f.paused(true);f.step(30000);f.paused(false);for(let i=0;i<6;i++)f.step();assert.equal(f.messages.filter(m=>m.event==='pitch_unavailable').length,1);});
test('replacement video suspends previous graph and creates its own',()=>{const f=audioFixture();f.step();f.key(2);const first=f.contexts[0];f.replace();f.step();assert.equal(first.state,'suspended');assert.equal(f.contexts.length,2);});
test('changing a nonzero key preserves queued real DSP audio',()=>{
 const f=audioFixture({realDsp:true});f.step();f.key(2);
 for(let i=0;i<64;i++)f.process();
 f.key(-2);
 assert(f.process()[0].some(v=>Math.abs(v)>.00001),'changing pitch must not discard the FIFO and insert 80 ms of silence');
});
test('returning from original key clears old queued audio even between callbacks',()=>{
 const f=audioFixture({realDsp:true});f.step();f.key(2);
 for(let i=0;i<64;i++)f.process();
 f.key(0);f.key(-2);
 for(let i=0;i<6;i++)assert(f.process(false)[0].every(v=>v===0));
});
test('seeking clears real DSP audio from the previous position',()=>{
 const f=audioFixture({realDsp:true});f.step();f.key(2);
 for(let i=0;i<64;i++)f.process();
 f.seek();
 for(let i=0;i<12;i++)assert(f.process(false)[0].every(v=>v===0));
});
test('latency diagnostics report missing hardware estimates as unknown',()=>{
 const f=audioFixture({realDsp:true});f.step();f.key(2);
 for(let i=0;i<64;i++)f.process();f.step();
 const m=f.messages.find(m=>m.event==='metrics');assert(m);assert.equal(m.callbackFrames,1024);
 assert.equal(m.baseLatencyMs,null);assert.equal(m.outputLatencyMs,null);
 const c=f.contexts.at(-1);c.baseLatency=.01;c.outputLatency=.2;f.process();f.step();
 const measured=f.messages.filter(m=>m.event==='metrics').at(-1);assert.equal(measured.baseLatencyMs,10);assert.equal(measured.outputLatencyMs,200);
});
test('debug callback counts and processing duration reset after each report and pause',()=>{
 const f=audioFixture();f.step();f.key(-2);f.step();
 f.process(true,2);f.process(true,5);f.process(true,1);f.step();
 const m=f.messages.filter(m=>m.event==='metrics').at(-1);
 assert.equal(m.callbackCount,3);assert.equal(m.maxProcessMs,5);
 f.process(true,1);f.step();const next=f.messages.filter(m=>m.event==='metrics').at(-1);
 assert.equal(next.callbackCount,1);assert.equal(next.maxProcessMs,1);
 f.process(true,7);f.paused(true);f.step(30000);f.paused(false);f.step();
 f.process(true,2);f.step();const resumed=f.messages.filter(m=>m.event==='metrics').at(-1);
 assert.equal(resumed.callbackCount,1);assert.equal(resumed.maxProcessMs,2);
});
test('production keeps pitch health checks without emitting debug metrics',()=>{
 const f=audioFixture({diagnostics:false});f.step();f.key(-2);f.process();f.step();
 assert(f.messages.some(m=>m.event==='pitch_active'));assert(!f.messages.some(m=>m.event==='metrics'));
});
test('restoring a paused position cues without seek-triggered playback',()=>{
 const f=playerFixture({autoplay:false,position:142.75});f.ready();
 assert(!f.calls.some(c=>Array.isArray(c)&&c[0]==='seek'));
 assert.deepEqual(f.calls.find(c=>Array.isArray(c)&&c[0]==='cue'),['cue','M7lc1UVf-VE',142.75]);
 assert(!f.calls.includes('play'));
 f.control('play',0);assert(f.calls.includes('play'));
});
test('restoring active playback seeks and plays the saved position',()=>{
 const f=playerFixture({autoplay:true,position:142.75});f.ready();
 assert.deepEqual(f.calls.find(c=>Array.isArray(c)&&c[0]==='seek'),['seek',142.75]);assert(f.calls.includes('play'));
});
test('a cued video cannot replace the saved resume position with its placeholder time',()=>{
 const f=playerFixture({autoplay:false,position:142.75});f.ready();f.state(5);f.step();
 assert(!f.messages.some(m=>m.event==='position'));f.control('play',0);f.state(1);f.step();assert(f.messages.some(m=>m.event==='position'));
});
test('embedding denial retains its code and ignores a late ready callback',()=>{
 for(const code of [101,150,153]){const f=playerFixture();f.error(code);f.ready();f.state(5);f.step();
  assert.equal(f.messages.at(-1).event,'failed');assert.equal(f.messages.at(-1).code,code);assert(!f.calls.includes('play'));}
});
console.log(JSON.stringify({pass:true,checks},null,2));
