# Build a Play upload bundle with a dedicated key, never the development key.
[CmdletBinding()]
param([string]$SigningDirectory=(Join-Path $env:USERPROFILE '.android\singkey-upload'))
$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
$keyPath=Join-Path $SigningDirectory 'singkey-upload.jks'
$passwordPath=Join-Path $SigningDirectory 'password.dpapi'
$keytool=Join-Path $env:JAVA_HOME 'bin\keytool.exe'
if(-not (Test-Path -LiteralPath $keytool)){throw 'Set JAVA_HOME to JDK 17 before running.'}
if((Test-Path -LiteralPath $keyPath) -ne (Test-Path -LiteralPath $passwordPath)) {
 throw 'Incomplete signing directory. Restore the matching key and password; no files were overwritten.'
}
$oldStore=$env:SINGKEY_UPLOAD_STORE
$oldPassword=$env:SINGKEY_UPLOAD_PASSWORD
$oldAlias=$env:SINGKEY_UPLOAD_ALIAS
try {
 if(-not (Test-Path -LiteralPath $keyPath)) {
  throw 'The existing Play upload key is required. Restore singkey-upload.jks and password.dpapi for the original Windows user; this update script never creates a replacement key.'
 }
 $secure=(Get-Content -LiteralPath $passwordPath -Raw).Trim() | ConvertTo-SecureString
 $ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
 try {$env:SINGKEY_UPLOAD_PASSWORD=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)}
 finally {[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)}
 $certificatePath=[System.IO.Path]::GetTempFileName()
 try {
  & $keytool -exportcert -keystore $keyPath -alias singkey-upload -storepass:env SINGKEY_UPLOAD_PASSWORD -file $certificatePath
  if($LASTEXITCODE -ne 0){throw 'Cannot read the existing upload certificate.'}
  $fingerprint=(Get-FileHash -LiteralPath $certificatePath -Algorithm SHA256).Hash.ToLowerInvariant()
  if($fingerprint -ne '2728cfe2e7261389c5622e8303250709503b71a27456b4d5bc114bfa33e4b669') {
   throw 'This is not the upload key registered for kr.keymate.app. No bundle was built.'
  }
 } finally {Remove-Item -LiteralPath $certificatePath -ErrorAction SilentlyContinue}
 $env:SINGKEY_UPLOAD_STORE=$keyPath
 $env:SINGKEY_UPLOAD_ALIAS='singkey-upload'
 Push-Location $project
 try {
  & .\gradlew.bat --no-daemon bundleRelease
  if($LASTEXITCODE -ne 0){throw 'Release bundle build failed.'}
  New-Item -ItemType Directory -Force -Path dist | Out-Null
  $gradle=Get-Content app/build.gradle -Raw
  $version=[regex]::Match($gradle,"versionName '([^']+)'").Groups[1].Value
  if(-not $version){throw 'Missing versionName.'}
  $bundle="dist/naekiro-$version-play.aab"
  Copy-Item -LiteralPath app/build/outputs/bundle/release/app-release.aab -Destination $bundle
  & (Join-Path $env:JAVA_HOME 'bin/jarsigner.exe') -verify $bundle
  if($LASTEXITCODE -ne 0){throw 'Bundle signature verification failed.'}
  & $keytool -exportcert -rfc -keystore $keyPath -alias singkey-upload -storepass:env SINGKEY_UPLOAD_PASSWORD -file dist/singkey-upload-certificate.pem
  if($LASTEXITCODE -ne 0){throw 'Public certificate export failed.'}
  Get-FileHash -LiteralPath $bundle -Algorithm SHA256
  Write-Output "Upload bundle: $bundle"
  Write-Output "Private key is local only: $keyPath. Keep an independent secure backup before production."
 } finally {Pop-Location}
} finally {
 $env:SINGKEY_UPLOAD_STORE=$oldStore
 $env:SINGKEY_UPLOAD_PASSWORD=$oldPassword
 $env:SINGKEY_UPLOAD_ALIAS=$oldAlias
}
