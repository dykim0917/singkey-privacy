// Public publishable key only. Never deploy a secret/service-role key.
window.NAEKIRO_COMMUNITY={url:'',key:'',androidPackage:'kr.keymate.app'};
