-- Run once on a new Supabase project. No service-role key belongs in the Android app.
begin;
create schema if not exists community_private;
revoke all on schema community_private from public, anon, authenticated;
create table community_private.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 nickname text not null check(char_length(nickname) between 1 and 24 and nickname !~ '[[:cntrl:]]'),
 rules_version text not null, accepted_at timestamptz not null default now(), suspended boolean not null default false
);
create table community_private.playlists (
 id uuid primary key, owner_id uuid not null references community_private.profiles(id) on delete cascade,
 title text not null, songs jsonb not null, created_at timestamptz not null default now(),
 withdrawn boolean not null default false, hidden boolean not null default false, curated boolean not null default false
);
create index community_feed_order on community_private.playlists(created_at desc,id desc);
create index community_owner on community_private.playlists(owner_id);
create table community_private.likes (
 user_id uuid references community_private.profiles(id) on delete cascade,
 playlist_id uuid references community_private.playlists(id) on delete cascade,
 primary key(user_id,playlist_id)
);
create table community_private.blocks (
 user_id uuid references community_private.profiles(id) on delete cascade,
 blocked_id uuid references community_private.profiles(id) on delete cascade,
 primary key(user_id,blocked_id), check(user_id<>blocked_id)
);
create table community_private.reports (
 user_id uuid references community_private.profiles(id) on delete cascade,
 playlist_id uuid references community_private.playlists(id) on delete cascade,
 reason text not null check(reason in ('spam','inappropriate','rights','other')),
 created_at timestamptz not null default now(), primary key(user_id,playlist_id)
);
alter table community_private.profiles enable row level security;
alter table community_private.playlists enable row level security;
alter table community_private.likes enable row level security;
alter table community_private.blocks enable row level security;
alter table community_private.reports enable row level security;
revoke all on all tables in schema community_private from public, anon, authenticated;

create function community_private.member() returns uuid language plpgsql stable security definer set search_path='' as $$
declare u uuid:=auth.uid(); begin
 if u is null or not exists(select 1 from community_private.profiles where id=u and not suspended) then raise exception 'member_required' using errcode='42501'; end if;return u;
end $$;
create function public.community_profile(p_nickname text default null,p_rules text default null) returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); result jsonb; begin
 if u is null or not exists(select 1 from auth.users where id=u) then raise exception 'login_required' using errcode='42501';end if;
 if exists(select 1 from community_private.profiles where id=u and suspended) then raise exception 'account_unavailable' using errcode='42501';end if;
 if p_nickname is not null then
  if char_length(trim(p_nickname)) not between 1 and 24 or p_nickname ~ '[[:cntrl:]]' or p_rules is distinct from '2026-09-28' then raise exception 'invalid_profile';end if;
  insert into community_private.profiles(id,nickname,rules_version) values(u,trim(p_nickname),p_rules)
  on conflict(id) do update set nickname=excluded.nickname,rules_version=excluded.rules_version,accepted_at=now();
 end if;
 select jsonb_build_object('id',id,'nickname',nickname) into result from community_private.profiles where id=u;
 return coalesce(result,'{}'::jsonb);
end $$;
create function public.community_feed(p_id uuid default null,p_mine boolean default false,p_offset integer default 0) returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if p_offset is null or p_offset<0 or p_offset>10000 then raise exception 'invalid_offset';end if;
 if p_mine and auth.uid() is null then raise exception 'login_required' using errcode='42501';end if;
 return coalesce((select jsonb_agg(item order by created_at desc,id desc) from (
  select p.created_at,p.id,jsonb_build_object('id',p.id,'owner_id',p.owner_id,'title',p.title,'nickname',a.nickname,'songs',p.songs,'curated',p.curated,
    'likes',(select count(*) from community_private.likes l where l.playlist_id=p.id),
    'liked',exists(select 1 from community_private.likes l where l.playlist_id=p.id and l.user_id=auth.uid())) as item
  from community_private.playlists p join community_private.profiles a on a.id=p.owner_id
  where not p.withdrawn and not p.hidden and not a.suspended
   and (p_id is null or p.id=p_id) and (not p_mine or p.owner_id=auth.uid())
   and not exists(select 1 from community_private.blocks b where b.user_id=auth.uid() and b.blocked_id=p.owner_id)
  order by p.created_at desc,p.id desc limit 20 offset p_offset
 ) q),'[]'::jsonb);
end $$;
create function public.community_publish(p_request_id uuid,p_title text,p_songs jsonb,p_rules text) returns uuid language plpgsql security definer set search_path='' as $$
declare u uuid:=community_private.member(); s jsonb; begin
 -- Serialize limits and retries for one author, including concurrent requests.
 perform 1 from community_private.profiles where id=u for update;
 if p_request_id is null or p_rules is distinct from '2026-09-28' or p_title is null or char_length(trim(p_title)) not between 1 and 80 or p_title ~ '[[:cntrl:]]' then raise exception 'invalid_publication';end if;
 if p_songs is null or jsonb_typeof(p_songs)<>'array' then raise exception 'invalid_songs';end if;
 if jsonb_array_length(p_songs) not between 1 and 50 or octet_length(p_songs::text)>60000 then raise exception 'invalid_songs';end if;
 for s in select value from jsonb_array_elements(p_songs) loop
  if jsonb_typeof(s)<>'object' or jsonb_typeof(s->'video_id') is distinct from 'string' or (s->>'video_id') !~ '^[A-Za-z0-9_-]{11}$'
   or jsonb_typeof(s->'title') is distinct from 'string' or char_length(trim(s->>'title')) not between 1 and 200 or (s->>'title') ~ '[[:cntrl:]]'
   or (s - array['video_id','title','key'])<>'{}'::jsonb then raise exception 'invalid_song';end if;
  if s ? 'key' then
   if jsonb_typeof(s->'key') is distinct from 'number' then raise exception 'invalid_key';end if;
   if (s->>'key')::numeric not between -12 and 12 or (s->>'key')::numeric<>trunc((s->>'key')::numeric) then raise exception 'invalid_key';end if;
  end if;
 end loop;
 if (select count(distinct value->>'video_id') from jsonb_array_elements(p_songs))<>jsonb_array_length(p_songs) then raise exception 'duplicate_song';end if;
 if exists(select 1 from community_private.playlists where id=p_request_id and owner_id=u and not withdrawn and not hidden and title=trim(p_title) and songs=p_songs) then return p_request_id;end if;
 if (select count(*) from community_private.playlists where owner_id=u and not withdrawn)>=20 then raise exception 'publication_limit';end if;
 if (select count(*) from community_private.playlists where owner_id=u and created_at>now()-interval '1 minute')>=5 then raise exception 'rate_limit';end if;
 insert into community_private.playlists(id,owner_id,title,songs) values(p_request_id,u,trim(p_title),p_songs);
 return p_request_id;
end $$;
create function public.community_like(p_id uuid,p_liked boolean) returns void language plpgsql security definer set search_path='' as $$
declare u uuid:=community_private.member(); begin
 if p_liked is null then raise exception 'invalid_like';end if;
 perform 1 from community_private.playlists p join community_private.profiles a on a.id=p.owner_id
 where p.id=p_id and not p.withdrawn and not p.hidden and not a.suspended
 and not exists(select 1 from community_private.blocks where user_id=u and blocked_id=p.owner_id) for share of p;
 if not found then raise exception 'list_unavailable';end if;
 if p_liked then insert into community_private.likes values(u,p_id) on conflict do nothing;else delete from community_private.likes where user_id=u and playlist_id=p_id;end if;
end $$;
create function public.community_withdraw(p_id uuid) returns void language plpgsql security definer set search_path='' as $$
declare u uuid:=community_private.member(); begin
 update community_private.playlists set withdrawn=true where id=p_id and owner_id=u;
 if not found then raise exception 'list_unavailable' using errcode='42501';end if;
 delete from community_private.likes where playlist_id=p_id;
end $$;
create function public.community_report(p_id uuid,p_reason text) returns void language plpgsql security definer set search_path='' as $$
declare u uuid:=community_private.member(); begin
 perform 1 from community_private.profiles where id=u for update;
 if not exists(select 1 from community_private.playlists where id=p_id and not withdrawn and not hidden) then raise exception 'list_unavailable';end if;
 if (select count(*) from community_private.reports where user_id=u and created_at>now()-interval '1 day')>=30 then raise exception 'rate_limit';end if;
 insert into community_private.reports values(u,p_id,p_reason,now()) on conflict(user_id,playlist_id) do update set reason=excluded.reason;
end $$;
create function public.community_block(p_owner uuid,p_blocked boolean) returns void language plpgsql security definer set search_path='' as $$
declare u uuid:=community_private.member(); begin
 if p_owner is null or p_owner=u or p_blocked is null then raise exception 'invalid_block';end if;
 if p_blocked then insert into community_private.blocks values(u,p_owner) on conflict do nothing;else delete from community_private.blocks where user_id=u and blocked_id=p_owner;end if;
end $$;
create function public.community_blocks() returns jsonb language plpgsql stable security definer set search_path='' as $$
declare u uuid:=community_private.member(); begin
 return coalesce((select jsonb_agg(jsonb_build_object('id',p.id,'nickname',p.nickname)) from community_private.blocks b join community_private.profiles p on p.id=b.blocked_id where b.user_id=u),'[]'::jsonb);
end $$;
create function public.community_delete_account(p_confirmation text) returns void language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); begin
 if u is null or p_confirmation is distinct from 'DELETE' then raise exception 'confirmation_required' using errcode='42501';end if;
 delete from auth.users where id=u; -- FKs remove profile, posts, reactions, blocks and reports.
 if not found then raise exception 'account_unavailable';end if;
end $$;
-- Functions default to PUBLIC execution: revoke explicitly before exposing only the intended RPCs.
revoke all on function community_private.member() from public,anon,authenticated;
revoke all on function public.community_profile(text,text),public.community_feed(uuid,boolean,integer),public.community_publish(uuid,text,jsonb,text),public.community_like(uuid,boolean),public.community_withdraw(uuid),public.community_report(uuid,text),public.community_block(uuid,boolean),public.community_blocks(),public.community_delete_account(text) from public,anon,authenticated;
grant execute on function public.community_feed(uuid,boolean,integer) to anon,authenticated;
grant execute on function public.community_profile(text,text),public.community_publish(uuid,text,jsonb,text),public.community_like(uuid,boolean),public.community_withdraw(uuid),public.community_report(uuid,text),public.community_block(uuid,boolean),public.community_blocks(),public.community_delete_account(text) to authenticated;
commit;
