import {PGlite} from '@electric-sql/pglite';
import {readFile} from 'node:fs/promises';
import test from 'node:test';
import assert from 'node:assert/strict';
const db=new PGlite();
const A='00000000-0000-4000-8000-000000000001',B='00000000-0000-4000-8000-000000000002',P='10000000-0000-4000-8000-000000000001';
const songs=[{video_id:'Upe2ewoz1PI',title:'Test track',key:2}];
await db.exec(`create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;insert into auth.users values('${A}'),('${B}');`);
await db.exec(await readFile(new URL('./001_community.sql',import.meta.url),'utf8'));
async function as(user,sql,args=[]){await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[user||'']);await db.exec(`set role ${user?'authenticated':'anon'}`);return db.query(sql,args);}
const publish=(user,id=P,payload=songs)=>as(user,'select public.community_publish($1,$2,$3,$4)',[id,'Test playlist',JSON.stringify(payload),'2026-09-28']);
await test('anonymous users can read empty feed but cannot write or inspect private tables',async()=>{
 assert.deepEqual((await as(null,'select public.community_feed() as value')).rows[0].value,[]);
 await assert.rejects(()=>publish(null),/permission denied/);
 await assert.rejects(()=>as(null,'select * from community_private.profiles'),/permission denied/);
});
await test('profiles require a real user, accepted rules and explicit nickname',async()=>{
 await assert.rejects(()=>as(A,'select public.community_profile($1,$2)',['Alice','old']),/invalid_profile/);
 for(const [id,nick] of [[A,'Alice'],[B,'Bob']])await as(id,'select public.community_profile($1,$2)',[nick,'2026-09-28']);
});
await test('publishing is idempotent and exposes only the intended public payload',async()=>{
 await publish(A);await publish(A);
 const rows=(await as(null,'select public.community_feed() as value')).rows[0].value;
 assert.equal(rows.length,1);assert.equal(rows[0].nickname,'Alice');assert.equal(rows[0].songs[0].key,2);assert.equal(rows[0].likes,0);
 assert.deepEqual(Object.keys(rows[0]).sort(),['curated','id','liked','likes','nickname','owner_id','songs','title']);
});
await test('private fields, duplicate videos, bad keys and oversized lists are rejected',async()=>{
 const id='10000000-0000-4000-8000-000000000002';
 for(const payload of [[{...songs[0],note:'private'}],[songs[0],songs[0]],[{...songs[0],key:13}],[{...songs[0],key:1.5}],[{...songs[0],video_id:'javascript:'}],Array(51).fill(songs[0])])await assert.rejects(()=>publish(A,id,payload));
});
await test('hidden keys are absent, and author cannot change content through request retries',async()=>{
 await assert.rejects(()=>publish(A,P,[{...songs[0],title:'changed'}]));
 const id='10000000-0000-4000-8000-000000000003';await publish(A,id,[{video_id:'Upe2ewoz1PI',title:'Without key'}]);
 const row=(await as(null,'select public.community_feed($1) as value',[id])).rows[0].value[0];assert.equal('key' in row.songs[0],false);
});
await test('cross-account withdrawal is denied and repeated likes count once',async()=>{
 await assert.rejects(()=>as(B,'select public.community_withdraw($1)',[P]),/list_unavailable/);
 await as(B,'select public.community_like($1,true)',[P]);await as(B,'select public.community_like($1,true)',[P]);
 let row=(await as(B,'select public.community_feed($1) as value',[P])).rows[0].value[0];assert.equal(row.likes,1);assert.equal(row.liked,true);
 await as(B,'select public.community_like($1,false)',[P]);row=(await as(null,'select public.community_feed($1) as value',[P])).rows[0].value[0];assert.equal(row.likes,0);
});
await test('blocked authors disappear from both feed and detail and cannot be liked',async()=>{
 await as(B,'select public.community_block($1,true)',[A]);assert.deepEqual((await as(B,'select public.community_feed($1) as value',[P])).rows[0].value,[]);
 await assert.rejects(()=>as(B,'select public.community_like($1,true)',[P]),/list_unavailable/);
 await as(B,'select public.community_block($1,false)',[A]);assert.equal((await as(B,'select public.community_feed($1) as value',[P])).rows[0].value.length,1);
});
await test('reports are private and only supported categories are accepted',async()=>{
 await assert.rejects(()=>as(B,'select public.community_report($1,$2)',[P,'bad category']));
 await as(B,'select public.community_report($1,$2)',[P,'spam']);await assert.rejects(()=>as(A,'select * from community_private.reports'),/permission denied/);
});
await test('withdrawal removes a post from links and rejects likes and stale republish retries',async()=>{
 await as(A,'select public.community_withdraw($1)',[P]);assert.deepEqual((await as(null,'select public.community_feed($1) as value',[P])).rows[0].value,[]);
 await assert.rejects(()=>as(B,'select public.community_like($1,true)',[P]));await assert.rejects(()=>publish(A));
});
await test('moderation flags cannot be changed by clients and hide content immediately',async()=>{
 await assert.rejects(()=>as(A,'update community_private.playlists set curated=true'),/permission denied/);
 await db.exec('reset role');await db.query('update community_private.profiles set suspended=true where id=$1',[A]);assert.deepEqual((await as(null,'select public.community_feed() as value')).rows[0].value,[]);
 await assert.rejects(()=>publish(A,'10000000-0000-4000-8000-000000000004'),/member_required/);
});
await test('account deletion requires confirmation, cascades owned data and invalidates subsequent writes',async()=>{
 await assert.rejects(()=>as(A,"select public.community_delete_account('no')"),/confirmation_required/);
 await as(A,"select public.community_delete_account('DELETE')");
 await assert.rejects(()=>as(A,"select public.community_profile('Alice','2026-09-28')"),/login_required/);
 await db.exec('reset role');assert.equal((await db.query('select count(*)::int as n from community_private.playlists')).rows[0].n,0);assert.equal((await db.query('select count(*)::int as n from community_private.reports')).rows[0].n,0);
 assert.equal((await db.query('select count(*)::int as n from auth.users where id=$1',[B])).rows[0].n,1);
});
await db.close();
