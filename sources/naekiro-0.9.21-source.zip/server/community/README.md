# 내키로 공개 플레이리스트

Android 첫 구현. 로그인 전 공개 목록 보기·곡 선택·보관함 가져오기, 로그인 후 게시·좋아요·신고·차단·회원탈퇴를 제공한다. Google/Kakao는 **시스템 브라우저 → Supabase Auth → PKCE → Android 앱** 경로다. Credential Manager나 카카오톡 네이티브 SDK를 직접 넣은 구현은 아니다.

## 재현과 설정

1. 무료 Supabase 프로젝트를 준비한다. `001_community.sql`은 새 프로젝트에 한 번 적용한다. 모든 데이터 테이블은 노출되지 않는 `community_private` 스키마에 있고 RLS를 켰다. 앱은 명시적으로 권한을 준 RPC 함수만 사용한다.
2. Supabase Auth의 Google·Kakao 제공사를 설정한다. Google은 웹 OAuth 클라이언트, Kakao는 REST API 키와 로그인 Client Secret을 사용한다. 양쪽 반환 주소는 `https://<project-ref>.supabase.co/auth/v1/callback`이다. 비밀키는 Supabase 관리 화면에만 보관한다.
3. Kakao는 `profile_nickname`만 동의 항목으로 사용하고 Supabase의 `Allow users without an email`을 켠다. 앱은 `scope=profile_nickname`을 제공사에 전달한다. `scopes`는 기본 범위에 추가되므로 대체할 수 없다. 실제 로그인 리디렉션의 범위도 검사해야 한다. Google은 기본 OpenID·email·profile만 사용한다. nonce 검사는 끄지 않는다.
4. Auth URL allowlist에는 Play 배포 앱 `kr.keymate.app.auth://callback/*`와 필요한 시험 앱 `kr.keymate.app.youtubeprobe.auth://callback/*`를 각각 등록한다. 0.9.20 배포 전 실제 서버 저장 여부를 배포 기록에서 확인한다. 불필요한 도메인 전체 와일드카드를 허용하지 않는다.
5. `community.properties.example`을 무시되는 `community.properties`로 복사한다. `supabase.url`, **`sb_publishable_` 키**, 공개 공유 페이지의 `community.webUrl`을 넣는다. 관리·service_role·OAuth 비밀키를 넣으면 안 된다.
6. `web/config.example.js`를 호스팅 폴더의 `config.js`로 복사하고 공개 URL/키와 정확한 Android 패키지를 넣는다. 정적 GitHub Pages 등으로 `web/` 내용을 서비스한다. 개인 계정 정보·관리 키를 넣지 않는다.
7. `JAVA_HOME=<JDK17> ./gradlew assembleDebug testDebugUnitTest lintDebug -PsingkeyYouTubeIframe=true -PsingkeyIframePitch=true`. 기존 원본 앱과 다른 패키지·동일 시험 서명으로 설치한다.

공통 서버라도 다른 로그인 제공사 계정의 자동 병합을 앱에서 구현하지 않는다. Supabase의 검증된 이메일 기반 identity linking 정책은 적용될 수 있다. 카카오는 이메일을 요청하지 않아 같은 사람이 양쪽으로 가입하면 별개 계정이 될 수 있다. 개인 보관함은 로그인과 무관하게 기기에 남는다.

## 데이터와 제한

- 공개: UUID, 게시자 ID, 앱에서 정한 닉네임, 제목, 선택 영상 ID·곡명, 명시적으로 공유한 키, 좋아요 수, 운영자 선정 표시. 이메일·제공사 실명·로그인 토큰을 공개 RPC에 포함하지 않는다.
- 비공개: 규칙 동의 기록, 계정별 좋아요·신고·차단. 개인 메모·평가·연습 상태·전체 보관함·재생 기록은 서버로 보내지 않는다.
- 한 목록 1–50곡, 중복 영상 불가, 제목 80자/곡명 200자/닉네임 24자, 키 −12…+12 정수. 한 계정 활성 게시물 20개, 분당 게시 5건, 하루 신고 30건. 게시자 행 잠금으로 동시 요청 제한과 동일 요청 UUID의 재시도를 처리한다.
- 홈은 `curated=true`의 **내키로 추천**(가로 카드 최대 3개)과 **함께 나눈 플레이리스트**(그 외 목록 최대 3개)로 구분한다. 전체보기도 같은 기준으로 분리하며 내 게시물에서는 둘 다 표시한다. 각 영역 안의 순서는 최신순이다. 가상 작성자·가상 좋아요를 만들지 않는다.
- 기존 `community_feed`의 20개 페이지를 사용한다. 클라이언트는 한 요청 흐름에서 최대 5페이지까지 읽어 다른 분류만 있는 페이지를 넘기며, 남은 페이지가 있으면 전체보기의 더 보기로 이어간다. 아직 끝까지 조회하지 못한 영역을 빈 목록으로 단정하지 않는다. 서버 함수·DB 변경은 없다.
- 게시물은 게시 시점 사본이다. 로컬 변경이 공개 글을 바꾸지 않는다. 가져올 때 기본은 자신의 저장 키/신규 곡 원키이며, 공유 키 적용은 별도 선택이다.
- 공개 중단은 즉시 조회에서 제외하는 soft delete이며 서버 행은 계정 삭제/운영자 삭제 전까지 남는다. 타인이 이미 가져간 사본은 회수할 수 없다.
- `community_delete_account`는 현재 인증된 본인의 auth.users를 삭제하고 외래키로 연결 자료를 정리한다. 기기 보관함과 메모는 보존한다. 제공사 자체 계정·서비스 보안 로그는 이 작업과 별개다.
- 세션/PKCE verifier는 Android Keystore AES-GCM 저장, 코드 반환 nonce는 10분 유효, 앱 패키지·호스트·경로·일회성 코드 검증. 로그·백업에 토큰을 넣지 않는다. 손상된 로그인 저장소는 비회원으로 돌아간다.

## 운영

Supabase 대시보드 SQL Editor에서 관리자만 아래 작업을 수행한다. 앱에는 관리자 권한이 없다. UUID는 확인한 실제 ID로 바꾼다. 신고가 누적됐다는 이유만으로 자동 숨김 처리하지 않는다.

```sql
-- 신고 검토: 신고자·내용은 비공개로 유지한다.
select r.created_at, r.reason, r.playlist_id, p.title, a.nickname
from community_private.reports r
join community_private.playlists p on p.id=r.playlist_id
join community_private.profiles a on a.id=p.owner_id
order by r.created_at desc;
-- 운영자 숨김 / 복원 / 선정 표시 (해당 ID 확인 후 한 문장씩 실행)
update community_private.playlists set hidden=true where id='<playlist-id>';
update community_private.playlists set hidden=false where id='<playlist-id>';
update community_private.playlists set curated=true where id='<playlist-id>';
-- 계정 정지: 해당 작성자의 목록은 공개 피드에서도 제외된다.
update community_private.profiles set suspended=true where id='<user-id>';
```

삭제 요청은 `web/account.html`에서 앱의 직접 탈퇴 및 지원 이메일 경로를 안내한다. 지원 요청자는 공개 닉네임만으로 소유자라고 단정하지 않고 제공사 로그인 등으로 본인 확인한다. 관리자 영구 삭제는 실제 소유자·요청 범위를 확인한 후 수행한다. 지원 요청으로 받은 비밀번호나 인증 코드를 저장하지 않는다.

무료 플랜 용량·사용량·중단 알림과 신고를 운영자가 확인해야 한다. 첫 배포는 별도 Android 시험판이다. 일반 사용자 공개 전 실제 OAuth 양쪽 기기 검증, 앱 표시/로그인 브랜딩·제공사 운영 상태, Play 데이터 보안/계정 삭제 링크/UGC 안내를 배포본과 맞춘다. 결제나 개인 클라우드 백업은 이 구현에 포함하지 않는다.

## 검증

`npm ci && npm test`는 PGlite에서 실제 SQL·Postgres 권한을 실행한다. auth.users/auth.uid는 최소 모형이므로 Supabase 제공사의 OAuth 및 실제 auth 스키마 삭제까지 검증했다고 해석하면 안 된다. 익명 접근, 소유자 제한, 게시 payload, 재시도, 좋아요, 신고 비공개, 차단, 철회, 운영자 숨김과 삭제 cascade를 검사한다.

Android `CommunityTest`는 공개 payload와 키 가져오기·PKCE/반환 검증, `CommunityClientTest`는 HTTP 요청·토큰 갱신·취소·손상 세션·응답 제한을 검사한다. HTTP 테스트는 가짜 제공사 응답이며 실제 로그인 성공은 별도 실기기 확인이 필요하다.

현재 환경 및 실기기 결과는 `docs/product/ANDROID_COMMUNITY_2026-09-28.md`와 ignored `dist/youtube-api-2026-09-28/community/`에 기록한다.

참고: [Supabase Google](https://supabase.com/docs/guides/auth/social-login/auth-google), [Supabase Kakao](https://supabase.com/docs/guides/auth/social-login/auth-kakao), [Auth external parameters](https://github.com/supabase/auth/blob/master/internal/api/external.go), [Auth Kakao default scopes](https://github.com/supabase/auth/blob/master/internal/api/provider/kakao.go).
