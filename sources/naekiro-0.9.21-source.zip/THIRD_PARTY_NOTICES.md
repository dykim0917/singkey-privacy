# 사용 라이브러리

- Google Mobile Ads Next-Gen SDK 1.5.0 / User Messaging Platform 4.0.0 — Google SDK 이용약관. 오픈소스 라이선스로 표시하지 않습니다. https://developers.google.com/admob/android/next-gen/terms
- AndroidX WebKit 1.15.0 — Android Open Source Project, Apache-2.0. https://developer.android.com/jetpack/androidx/releases/webkit
- Sonic b93885dcb70aae50c6f76b0fe4e0868f029a077e (modified) — Bill Cox, Apache-2.0. https://github.com/waywardgeek/sonic . 소스·수정 설명·전문: third_party/pitch-dsp/
- OkHttp 4.12.0 — Square, Apache-2.0. https://github.com/square/okhttp
- nanojson (TeamNewPipe fork, e9d656ddb49a412a5a0a5d5ef20ca7ef09549996) — The nanojson Authors, Apache-2.0. https://github.com/TeamNewPipe/nanojson
- jsoup 1.22.2 — Jonathan Hedley, MIT. https://jsoup.org/license

홈 순위 출처: TJ미디어 종합 TOP100(https://www.tjmedia.co.kr/chart/top100). 해당 사이트가 기본 제공하는 집계 기간의 1–10위 곡명·가수·순위를 표시하며, 집계 기간과 원문 링크를 함께 제공합니다. 공식 제휴나 내키로 이용자 순위를 의미하지 않습니다.

일본 곡 차트 출처: JOYSOUND 월간 종합 TOP100(https://www.joysound.com/web/karaoke/ranking/all/monthly). 공개 페이지에서 1–10위 곡명·가수·순위를 읽고 집계 기간과 원문 링크를 표시합니다.
팝송은 내키로가 직접 고른 연습곡이며 순위를 붙이지 않습니다. 참고 카탈로그: KaraFun(https://www.karafun.com/karaoke/best-karaoke/).
표시된 출처는 공식 제휴나 내키로 이용자 순위를 의미하지 않습니다.

`joysound-top10-2026-08.html` 테스트 자료는 2026-09-14 확인한 공식 월간 페이지의 집계 월과 1–10위 구조화 데이터만 축약한 것입니다. 공개 페이지 파싱을 사용하며 공식 API 제공이나 재배포 허가를 주장하지 않습니다.

0.9.19는 NewPipeExtractor와 Media3를 포함하지 않습니다. 내키로(이전 이름 싱키) 자체 코드와 PitchDSP 어댑터는 GPL-3.0-or-later를 유지하며, 자체 권리 범위에 한정한 Google 광고/UMP SDK 결합 예외를 LICENSE-GOOGLE-SDK-EXCEPTION.txt에 제공합니다. 제3자 라이선스와 기존 배포본의 GPL 조건은 변경하지 않습니다. Google SDK는 해당 SDK 약관을 따르며 YouTube/콘텐츠 이용 허가와 별개입니다. Firebase SDK는 포함하지 않습니다. 선택적 분석은 기존 HTTPS 클라이언트로 PostHog API를 호출합니다. 참고한 Transpose 앱의 소스는 복사하지 않았습니다.
