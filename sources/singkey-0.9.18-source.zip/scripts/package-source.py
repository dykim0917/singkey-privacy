"""Package corresponding source without machine configuration or credentials."""
from pathlib import Path
import hashlib
import re
import zipfile

root = Path(__file__).resolve().parents[1]
version = re.search(r"versionName '([^']+)'", (root / 'app/build.gradle').read_text()).group(1)
entries = {}
for folder in ('app/src', 'gradle/wrapper', 'third_party/pitch-dsp'):
    for path in (root / folder).rglob('*'):
        if path.is_file():
            entries[path.relative_to(root).as_posix()] = path.read_bytes()
for name in ('app/build.gradle', 'build.gradle', 'settings.gradle', 'gradle.properties',
             'gradlew', 'gradlew.bat', 'LICENSE', 'LICENSE-GOOGLE-SDK-EXCEPTION.txt',
             'THIRD_PARTY_NOTICES.md', 'analytics.properties.example',
             'monetization.properties.example', 'scripts/build-play-release.ps1',
             'scripts/test-android-browser.cjs', 'scripts/package-source.py'):
    entries[name] = (root / name).read_bytes()
entries['README.md'] = f'''# SingKey {version} corresponding source

Package kr.keymate.app. SingKey-owned code is GPL-3.0-or-later with the
additional permission in LICENSE-GOOGLE-SDK-EXCEPTION.txt. Third-party terms
are listed in THIRD_PARTY_NOTICES.md. Google SDKs retain their own terms.

Build with JDK 17 and Android SDK 36. Set sdk.dir in local.properties, then run
./gradlew assembleDebug testDebugUnitTest lintDebug (gradlew.bat on Windows).
Debug uses official test ad units. Without monetization.properties it uses
Google's sample app ID; only this debug sample-app mode skips publisher UMP.
For the configured publisher app, consent is handled by UMP in debug too.
-PsingkeyAdsEnabled=false disables ad requests and placements (SDKs remain).

PostHog analytics is optional and off until user consent. Copy the example
analytics configuration and supply a public EU ingestion-only project token
to enable it. No personal/admin API key belongs in the app. No Firebase SDK
or NewPipeExtractor is packaged. Browser playback uses AndroidX WebKit and
the Sonic WASM asset; its source, modifications and Emscripten build script
are in third_party/pitch-dsp. The packaged WASM is the output of that script.
Run node scripts/test-android-browser.cjs for DSP and playback-state checks.

Release requires your own signing key via SINGKEY_UPLOAD_STORE and
SINGKEY_UPLOAD_PASSWORD, analytics configuration, and all real Android AdMob
IDs from monetization.properties.example when ads are enabled. The Windows
release script can manage a local upload key. All credentials, local config,
generated builds and personal data are excluded from this archive.

Gradle downloads version-pinned dependencies from settings.gradle repositories.
SOURCE_MANIFEST.sha256 records every other included file for verification.
'''.encode()
for name, data in entries.items():
    assert not any(part in name.lower() for part in ('.jks', '.keystore', 'password.dpapi', 'google-services.json', 'local.properties'))
    assert b'-----BEGIN ' + b'PRIVATE KEY-----' not in data
entries['SOURCE_MANIFEST.sha256'] = ''.join(
    hashlib.sha256(data).hexdigest() + '  ' + name + '\n'
    for name, data in sorted(entries.items())).encode()
out = root / f'dist/singkey-{version}-source.zip'
out.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
print(f'{len(entries)} source files; SHA256 {hashlib.sha256(out.read_bytes()).hexdigest()}')
print(out)
