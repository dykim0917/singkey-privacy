# Build a Play upload bundle with a dedicated key, never the development key.
[CmdletBinding()]
param([string]$SigningDirectory=(Join-Path $env:USERPROFILE '.android\singkey-upload'))
$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
$keyPath=Join-Path $SigningDirectory 'singkey-upload.jks'
$passwordPath=Join-Path $SigningDirectory 'password.dpapi'
$keytool=Join-Path $env:JAVA_HOME 'bin\keytool.exe'
if(-not (Test-Path -LiteralPath $keytool)){throw 'Set JAVA_HOME to JDK 17 before running.'}
if((Test-Path -LiteralPath $keyPath) -ne (Test-Path -LiteralPath $passwordPath)) {
 throw 'Incomplete signing directory. Restore the matching key and password; no files were overwritten.'
}
$oldStore=$env:SINGKEY_UPLOAD_STORE
$oldPassword=$env:SINGKEY_UPLOAD_PASSWORD
$oldAlias=$env:SINGKEY_UPLOAD_ALIAS
try {
 if(-not (Test-Path -LiteralPath $keyPath)) {
  New-Item -ItemType Directory -Force -Path $SigningDirectory | Out-Null
  $identity=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name
  $acl=Get-Acl -LiteralPath $SigningDirectory
  $acl.SetAccessRuleProtection($true,$false)
  $rule=[System.Security.AccessControl.FileSystemAccessRule]::new($identity,'FullControl','ContainerInherit,ObjectInherit','None','Allow')
  $acl.SetAccessRule($rule)
  Set-Acl -LiteralPath $SigningDirectory -AclObject $acl
  $bytes=New-Object byte[] 32
  $rng=[System.Security.Cryptography.RandomNumberGenerator]::Create()
  try {$rng.GetBytes($bytes)} finally {$rng.Dispose()}
  $env:SINGKEY_UPLOAD_PASSWORD=[Convert]::ToBase64String($bytes)
  $secure=ConvertTo-SecureString $env:SINGKEY_UPLOAD_PASSWORD -AsPlainText -Force
  # Windows DPAPI ties this encrypted password to the current Windows user.
  ConvertFrom-SecureString $secure | Set-Content -LiteralPath $passwordPath -Encoding ascii
  & $keytool -genkeypair -keystore $keyPath -storetype JKS -alias singkey-upload -keyalg RSA -keysize 3072 -validity 10000 -dname 'CN=SingKey Upload Key' -storepass:env SINGKEY_UPLOAD_PASSWORD -keypass:env SINGKEY_UPLOAD_PASSWORD
  if($LASTEXITCODE -ne 0){throw 'Upload-key creation failed. Inspect the signing directory before retrying.'}
 } else {
  $secure=(Get-Content -LiteralPath $passwordPath -Raw).Trim() | ConvertTo-SecureString
  $ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try {$env:SINGKEY_UPLOAD_PASSWORD=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)}
  finally {[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)}
 }
 $env:SINGKEY_UPLOAD_STORE=$keyPath
 $env:SINGKEY_UPLOAD_ALIAS='singkey-upload'
 Push-Location $project
 try {
  & .\gradlew.bat --no-daemon bundleRelease
  if($LASTEXITCODE -ne 0){throw 'Release bundle build failed.'}
  New-Item -ItemType Directory -Force -Path dist | Out-Null
  $gradle=Get-Content app/build.gradle -Raw
  $version=[regex]::Match($gradle,"versionName '([^']+)'").Groups[1].Value
  if(-not $version){throw 'Missing versionName.'}
  $bundle="dist/singkey-$version-play.aab"
  Copy-Item -LiteralPath app/build/outputs/bundle/release/app-release.aab -Destination $bundle
  & (Join-Path $env:JAVA_HOME 'bin/jarsigner.exe') -verify $bundle
  if($LASTEXITCODE -ne 0){throw 'Bundle signature verification failed.'}
  & $keytool -exportcert -rfc -keystore $keyPath -alias singkey-upload -storepass:env SINGKEY_UPLOAD_PASSWORD -file dist/singkey-upload-certificate.pem
  if($LASTEXITCODE -ne 0){throw 'Public certificate export failed.'}
  Get-FileHash -LiteralPath $bundle -Algorithm SHA256
  Write-Output "Upload bundle: $bundle"
  Write-Output "Private key is local only: $keyPath. Keep an independent secure backup before production."
 } finally {Pop-Location}
} finally {
 $env:SINGKEY_UPLOAD_STORE=$oldStore
 $env:SINGKEY_UPLOAD_PASSWORD=$oldPassword
 $env:SINGKEY_UPLOAD_ALIAS=$oldAlias
}
