function(config) {
 'use strict';
 if (!['m.youtube.com','www.youtube.com','youtube.com'].includes(location.hostname)) return;
 const send=(event,detail={})=>window.singkeyNative.postMessage(JSON.stringify({token:config.token,event,...detail}));
 let video,graph,key=config.key,failed=false,paused=false;
 const matches=()=>new URL(location.href).searchParams.get('v')===config.videoID;
 const ad=()=>!!document.querySelector('.ad-showing,.ad-interrupting');
 const graphs=new WeakMap();
 function reset(){if(graph)graph.dsp.SKPitchReset(graph.handle);}
 function bind(){
  if(!matches())return;
  const next=document.querySelector('video');if(!next||next===video)return;
  if(graph)graph.context.suspend();video=next;graph=graphs.get(video);failed=false;
  video.addEventListener('seeking',reset);
  send('ready');
 }
 async function prepare(){
  bind();if(!video||failed)return;
  if(graph){await graph.context.resume();return;}
  let context,source;
  try {
   context=new AudioContext({latencyHint:'interactive'});
   const dsp=new WebAssembly.Instance(new WebAssembly.Module(Uint8Array.from(atob(config.wasm),c=>c.charCodeAt(0))),{}).exports;
   const count=2048,handle=dsp.SKPitchCreate(context.sampleRate,2),pointers=dsp.malloc(8),left=dsp.malloc(count*4),right=dsp.malloc(count*4);
   if(!handle||!pointers||!left||!right)throw new Error('allocation');
   new Uint32Array(dsp.memory.buffer,pointers,2).set([left,right]);
   const channels=[new Float32Array(dsp.memory.buffer,left,count),new Float32Array(dsp.memory.buffer,right,count)];
   // No module fetch or CSP changes. This standard legacy Web Audio path is a
   // feasibility probe; main-thread deadline/latency must be measured before use.
   const node=context.createScriptProcessor(count,2,2);
   const target=video;let samples=0,inputEnergy=0,outputEnergy=0,last=0,previous=0;
   node.onaudioprocess=event=>{
    const applied=ad()?0:key;
    if(applied!==previous){dsp.SKPitchSetKey(handle,applied);previous=applied;}
    for(let c=0;c<2;c++)channels[c].set(event.inputBuffer.getChannelData(c));
    for(let i=0;i<count;i++)inputEnergy+=channels[0][i]**2;
    dsp.SKPitchProcess(handle,pointers,count,1);
    for(let c=0;c<2;c++)event.outputBuffer.copyToChannel(channels[c],c);
    for(let i=0;i<count;i++)outputEnergy+=channels[0][i]**2;
    samples+=count;
    if(performance.now()-last>1000){last=performance.now();send('metrics',{key:applied,input:Math.sqrt(inputEnergy/samples),output:Math.sqrt(outputEnergy/samples),healthy:dsp.SKPitchIsHealthy(handle),time:target.currentTime});samples=inputEnergy=outputEnergy=0;}
   };
   source=context.createMediaElementSource(target);source.connect(node);node.connect(context.destination);
   graph={context,dsp,handle,node,source};graphs.set(target,graph);await context.resume();send('pitch_pending');
  }catch(error){failed=true;send('pitch_unavailable',{reason:String(error.message).slice(0,90)});if(source){source.disconnect();source.connect(context.destination);}else await context?.close();}
 }
 globalThis.singkeyBrowserControl=async(name,value)=>{
  bind();if(!video||!matches())return;
  if(name==='key'&&Number.isInteger(value)&&Math.abs(value)<=12){key=value;await prepare();}
  if(name==='pause'){paused=true;video.pause();await graph?.context.suspend();}
  if(name==='toggle'){paused=!video.paused;if(paused)video.pause();else{await graph?.context.resume();await video.play();}}
 };
 document.addEventListener('click',event=>{if(event.isTrusted){paused=false;if(key)prepare();}},{capture:true});
 setInterval(()=>{bind();if(!video||!matches())return;if(paused){video.pause();return;}if(key&&!graph&&!failed)prepare();},500);
}
