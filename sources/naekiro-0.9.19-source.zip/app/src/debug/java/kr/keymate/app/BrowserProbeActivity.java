package kr.keymate.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.*;
import android.widget.*;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Isolated debug harness: never included in a release and never requests AdMob. */
public final class BrowserProbeActivity extends Activity {
 private WebView web;
 private TextView status;
 private int key;
 private String token;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(0,40,0,30);root.setBackgroundColor(Color.BLACK);setContentView(root);
  status=new TextView(this);status.setTextColor(Color.WHITE);status.setText("Browser audio validation");root.addView(status);
  LinearLayout controls=new LinearLayout(this);root.addView(controls);
  for(int step:new int[]{-1,0,1}){Button button=new Button(this);button.setText(step<0?"−":step>0?"+":"0");controls.addView(button);button.setOnClickListener(v->{key=step==0?0:Math.max(-12,Math.min(12,key+step));web.evaluateJavascript("globalThis.singkeyBrowserControl?.('key',"+key+")",null);});}
  web=new WebView(this);root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
  WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);settings.setMediaPlaybackRequiresUserGesture(false);
  CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
  web.setWebChromeClient(new WebChromeClient(){@Override public boolean onConsoleMessage(ConsoleMessage msg){android.util.Log.d("SingKeyProbe","console:"+msg.message());return true;}@Override public void onPermissionRequest(PermissionRequest request){request.deny();}});
  Set<String> origins=new HashSet<>(Arrays.asList("https://www.youtube.com","https://m.youtube.com","https://youtube.com"));
  token=UUID.randomUUID().toString();
  if(!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)||!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)){status.setText("Update Android System WebView");return;}
  WebViewCompat.addWebMessageListener(web,"singkeyNative",origins,(view,message,origin,mainFrame,reply)->{
   if(!mainFrame||message.getData()==null)return;
   try{JSONObject event=new JSONObject(message.getData());if(!token.equals(event.optString("token")))return;String name=event.optString("event");status.setText(name+" · key "+key);android.util.Log.d("SingKeyProbe",event.toString());}catch(Exception ignored){}
  });
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return request.isForMainFrame()&&!("https".equals(request.getUrl().getScheme())&&Arrays.asList("www.youtube.com","m.youtube.com","youtube.com").contains(request.getUrl().getHost()));}
   @Override public void onPageFinished(WebView view,String url){android.util.Log.d("SingKeyProbe","page_finished");}
  });
  String id=getIntent().getStringExtra("video");if(id==null||!id.matches("[A-Za-z0-9_-]{11}"))id="Upe2ewoz1PI";
  key=Math.max(-12,Math.min(12,getIntent().getIntExtra("key",0)));
  try{
   JSONObject config=new JSONObject().put("token",token).put("videoID",id).put("key",key).put("bufferMode",false).put("diagnostics",true).put("processor",asset("BrowserPitchProcessor.js")).put("wasm",android.util.Base64.encodeToString(assetBytes("ProbePitchDSP.wasm"),android.util.Base64.NO_WRAP));
   String source=getIntent().getBooleanExtra("legacyAudio",false)?asset("AndroidPitchProbe.js"):asset("BrowserPlayback.js").replace("window.webkit.messageHandlers.singkeyBrowser.postMessage({token: config.token, event, ...detail});","window.singkeyNative.postMessage(JSON.stringify({token: config.token, event, ...detail}));");
   WebViewCompat.addDocumentStartJavaScript(web,"("+source+")("+config+");",origins);
   web.loadUrl("https://m.youtube.com/watch?v="+id);
  }catch(Exception error){status.setText("Probe asset failure");android.util.Log.e("SingKeyProbe","asset failure",error);}
 }
 private byte[] assetBytes(String name)throws Exception{try(java.io.InputStream input=getAssets().open("browser/"+name);java.io.ByteArrayOutputStream output=new java.io.ByteArrayOutputStream()){byte[] buffer=new byte[8192];int count;while((count=input.read(buffer))!=-1){if(output.size()+count>1024*1024)throw new java.io.IOException("Asset too large");output.write(buffer,0,count);}return output.toByteArray();}}
 private String asset(String name)throws Exception{return new String(assetBytes(name),StandardCharsets.UTF_8);}
 @Override protected void onStop(){if(web!=null){web.evaluateJavascript("globalThis.singkeyBrowserControl?.('pause',0)",null);web.onPause();}super.onStop();}
 @Override protected void onDestroy(){if(web!=null)web.destroy();super.onDestroy();}
}
