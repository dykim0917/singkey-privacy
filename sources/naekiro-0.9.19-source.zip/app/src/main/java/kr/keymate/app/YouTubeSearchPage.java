package kr.keymate.app;

import com.grack.nanojson.*;
import java.io.IOException;
import java.util.*;
import java.util.regex.*;
import okhttp3.HttpUrl;

/** Reads public search metadata as data; never evaluates page JavaScript. */
final class YouTubeSearchPage {
 private static final Pattern INITIAL=Pattern.compile("(?:var\\s+ytInitialData|window\\[\"ytInitialData\"\\]|ytInitialData)\\s*=\\s*");
 static String url(String query,AppLanguage language){
  return new HttpUrl.Builder().scheme("https").host("www.youtube.com").addPathSegment("results")
   .addQueryParameter("search_query",query).addQueryParameter("hl",language.language).addQueryParameter("gl",language.country).build().toString();
 }
 static List<Song> parse(String html)throws IOException{
  if(html==null||html.length()>HttpDownloader.MAX_BODY_BYTES)throw new IOException("Search response too large");
  Matcher match=INITIAL.matcher(html);if(!match.find())throw new IOException("Search data unavailable");
  int start=match.end(),end=-1,depth=0;boolean string=false,escape=false;
  if(start>=html.length()||html.charAt(start)!='{')throw new IOException("Invalid search data");
  for(int i=start;i<html.length();i++){
   char c=html.charAt(i);
   if(string){if(escape)escape=false;else if(c=='\\')escape=true;else if(c=='\"')string=false;}
   else if(c=='\"')string=true;
   else if(c=='{'||c=='['){if(++depth>80)throw new IOException("Search data too deep");}
   else if(c=='}'||c==']'){if(--depth==0){end=i+1;break;}}
  }
  if(end<0)throw new IOException("Incomplete search data");
  try{
   Object root=JsonParser.object().from(html.substring(start,end));
   ArrayList<Song> result=new ArrayList<>();walk(root,0,new int[]{0},new HashSet<>(),result);return result;
  }catch(JsonParserException error){throw new IOException("Invalid search data",error);}
 }
 private static void walk(Object node,int depth,int[] visited,Set<String> seen,List<Song> result)throws IOException{
  if(result.size()>=SearchSafety.MAX_RESULTS)return;
  if(depth>80||++visited[0]>100000)throw new IOException("Search data too complex");
  if(node instanceof JsonObject){
   JsonObject object=(JsonObject)node;JsonObject item=object.getObject("videoRenderer");
   if(item!=null){
    String id=item.getString("videoId",""),title=label(item.getObject("title")),channel=label(item.getObject("ownerText"));
    if(id.matches("[A-Za-z0-9_-]{11}")&&!title.isEmpty()&&title.length()<=2000&&channel.length()<=500&&seen.add(id))
     result.add(new Song("https://www.youtube.com/watch?v="+id,title+(channel.isEmpty()?"":" · "+channel),"https://i.ytimg.com/vi/"+id+"/hqdefault.jpg"));
   }
   // Preserve the page's result order. JSON arrays retain ranking order.
   for(Object value:object.values())walk(value,depth+1,visited,seen,result);
  }else if(node instanceof JsonArray)for(Object value:(JsonArray)node)walk(value,depth+1,visited,seen,result);
 }
 private static String label(JsonObject object){
  if(object==null)return "";String simple=object.getString("simpleText");if(simple!=null)return simple;
  StringBuilder value=new StringBuilder();JsonArray runs=object.getArray("runs");
  if(runs!=null)for(Object run:runs)if(run instanceof JsonObject){value.append(((JsonObject)run).getString("text",""));if(value.length()>2500)return "";}
  return value.toString();
 }
 private YouTubeSearchPage(){}
}
