package kr.keymate.app;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import okhttp3.*;
/** Fixed public metadata endpoints only. No media extraction or arbitrary requests. */
public final class HttpDownloader {
 static final int MAX_BODY_BYTES=8*1024*1024;
 private final OkHttpClient client = new OkHttpClient.Builder().followRedirects(false).followSslRedirects(false).callTimeout(30, TimeUnit.SECONDS).build();
 String read(String url,int limit)throws IOException{
  HttpUrl target=HttpUrl.parse(url);
  if(target==null||!allowed(target)||limit<1||limit>MAX_BODY_BYTES)throw new IOException("Unsupported metadata URL");
  if(Thread.currentThread().isInterrupted())throw new java.io.InterruptedIOException();
  Call call=client.newCall(new Request.Builder().url(target).header("User-Agent","Mozilla/5.0").build());
  if(target.host().equals("suggestqueries.google.com"))call.timeout().timeout(5,TimeUnit.SECONDS);
  try (Response response = call.execute()) {
   if(response.code()!=200||response.body()==null)throw new IOException("Metadata unavailable");
   String body=boundedBody(response.body(),limit);
   if(Thread.currentThread().isInterrupted())throw new java.io.InterruptedIOException();
   return body;
  }
 }
 static boolean allowed(HttpUrl url){return url.isHttps()&&url.port()==443&&url.username().isEmpty()&&url.password().isEmpty()&&
  (url.host().equals("www.youtube.com")&&(url.encodedPath().equals("/results")||url.encodedPath().equals("/oembed"))||url.host().equals("suggestqueries.google.com")&&url.encodedPath().equals("/complete/search"));}
 static String boundedBody(ResponseBody body)throws IOException{
  return boundedBody(body,MAX_BODY_BYTES);
 }
 static String boundedBody(ResponseBody body,int limit)throws IOException{
  if(body.contentLength()>limit)throw new IOException("Metadata response too large");
  okio.BufferedSource source=body.source();
  if(source.request(limit+1L))throw new IOException("Metadata response too large");
  try(ResponseBody limited=ResponseBody.create(source.readByteArray(),body.contentType())){return limited.string();}
 }
}
