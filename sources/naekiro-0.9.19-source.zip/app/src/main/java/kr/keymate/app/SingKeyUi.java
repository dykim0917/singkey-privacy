package kr.keymate.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.LayerDrawable;
import android.view.View;
import android.widget.*;

/** Shared native visual components; no playback or storage logic. */
final class SingKeyUi {
 static final int NAVY=0xff0b0e14, SURFACE=0xff141820, RAISED=0xff1b212c, MINT=0xffccff00, INK=0xfff0f4f8, MUTED=0xff94a1b2;
 static int dp(Context c,int n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
 static GradientDrawable shape(Context c,int color,int radius){
  GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(c,radius));return d;
 }
 static TextView label(Context c,String value,int size,boolean muted){
  TextView v=new TextView(c);v.setText(value);v.setTextSize(size);v.setTextColor(muted?MUTED:INK);v.setFontFeatureSettings("kern");v.setLineSpacing(dp(c,3),1f);return v;
 }
 static void field(EditText v){
  Context c=v.getContext();v.setTextColor(INK);v.setHintTextColor(MUTED);v.setTextSize(16);
  v.setPadding(dp(c,14),dp(c,12),dp(c,14),dp(c,12));v.setMinimumHeight(dp(c,48));
  v.setBackground(outline(c,RAISED,12,0xff29313e));
 }
 static LinearLayout card(Context c){
  LinearLayout v=new LinearLayout(c);v.setOrientation(LinearLayout.VERTICAL);v.setPadding(dp(c,14),dp(c,14),dp(c,14),dp(c,14));v.setBackground(outline(c,SURFACE,14,0xff232a36));
  LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(c,12);v.setLayoutParams(p);return v;
 }
 static Button button(Context c,String label,View.OnClickListener action,boolean primary){
  Button b=new Button(c);b.setText(label);b.setTextSize(14);b.setAllCaps(false);b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
  b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(dp(c,48));b.setMinimumHeight(dp(c,48));b.setMaxLines(2);
  b.setPadding(dp(c,10),dp(c,8),dp(c,10),dp(c,8));
  setButtonEmphasis(b,primary);
  b.setPadding(dp(c,14),dp(c,8),dp(c,14),dp(c,8));b.setStateListAnimator(null);b.setOnClickListener(action);return b;
 }
 static void setButtonEmphasis(Button b,boolean primary){
  Context c=b.getContext();
  int left=b.getPaddingLeft(),top=b.getPaddingTop(),right=b.getPaddingRight(),bottom=b.getPaddingBottom();
  int[][] states={{-android.R.attr.state_enabled},{}};
  b.setTextColor(new ColorStateList(states,new int[]{MUTED,primary?NAVY:INK}));
  GradientDrawable fill=outline(c,primary?MINT:RAISED,10,primary?MINT:0xff29313e);
  fill.setColor(new ColorStateList(states,new int[]{SURFACE,primary?MINT:RAISED}));
  fill.setStroke(dp(c,primary?2:1),new ColorStateList(new int[][]{{android.R.attr.state_focused},{android.R.attr.state_hovered},{}},new int[]{primary?NAVY:MINT,primary?NAVY:MUTED,primary?MINT:0xff29313e}));
  RippleDrawable ripple=new RippleDrawable(ColorStateList.valueOf(primary?0x330b0e14:0x33ccff00),fill,null);
  b.setBackground(new InsetDrawable(ripple,dp(c,3),dp(c,3),dp(c,3),dp(c,3)));
  b.setPadding(left,top,right,bottom);
 }
 static Button videoIcon(Context c,int res,String description,View.OnClickListener action) {
  Button b=iconButton(c,res,description,action);
  // Selection changes the glyph only; the video stays visible behind the control.
  GradientDrawable feedback=shape(c,0,8);
  feedback.setColor(new ColorStateList(new int[][]{{android.R.attr.state_pressed},{android.R.attr.state_focused},{android.R.attr.state_hovered},{}},new int[]{0x33000000,0x33000000,0x22000000,0}));
  b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33ffffff),feedback,shape(c,0xffffffff,8)));
  b.setPadding(dp(c,12),dp(c,12),dp(c,12),dp(c,12));
  b.setCompoundDrawables(icon(c,res,INK,24),null,null,null);return b;
 }
 static GradientDrawable outline(Context c,int color,int radius,int border) {
  GradientDrawable d=shape(c,color,radius);d.setStroke(dp(c,1),border);return d;
 }
 static android.graphics.drawable.Drawable icon(Context c,int res,int color,int size) {
  android.graphics.drawable.Drawable d=c.getDrawable(res).mutate();d.setTint(color);d.setBounds(0,0,dp(c,size),dp(c,size));return d;
 }
 static Button iconButton(Context c,int res,String description,View.OnClickListener action) {
  Button b=button(c,"",action,false);b.setContentDescription(description);
  b.setPadding(dp(c,12),dp(c,12),dp(c,12),dp(c,12));
  b.setCompoundDrawables(icon(c,res,MUTED,24),null,null,null);
  b.setBackground(shape(c,0,8));feedback(b,8);b.setPadding(dp(c,12),dp(c,12),dp(c,12),dp(c,12));
  b.setLayoutParams(new LinearLayout.LayoutParams(dp(c,48),dp(c,48)));return b;
 }
 static Button action(Context c,int res,String label,View.OnClickListener action) {
  Button b=button(c,label,action,false);b.setTextSize(12);b.setMinHeight(dp(c,64));b.setMinimumHeight(dp(c,64));
  b.setCompoundDrawables(null,icon(c,res,MUTED,24),null,null);b.setCompoundDrawablePadding(dp(c,5));
  b.setTextColor(MUTED);b.setBackgroundColor(0);feedback(b,8);b.setPadding(dp(c,4),dp(c,8),dp(c,4),dp(c,8));return b;
 }
 static Button tab(Context c,String label,View.OnClickListener action) {
  Button b=button(c,label,action,false);b.setTextSize(15);b.setMaxLines(1);
  b.setTextColor(new ColorStateList(new int[][]{{android.R.attr.state_selected},{}},new int[]{MINT,MUTED}));
  GradientDrawable underline=shape(c,0,0);
  underline.setColor(new ColorStateList(new int[][]{{android.R.attr.state_selected},{}},new int[]{MINT,0}));
  LayerDrawable background=new LayerDrawable(new android.graphics.drawable.Drawable[]{shape(c,0,0),underline});
  background.setLayerHeight(1,dp(c,3));background.setLayerGravity(1,android.view.Gravity.BOTTOM);
  b.setBackground(background);feedback(b,0);b.setPadding(dp(c,8),dp(c,12),dp(c,8),dp(c,12));return b;
 }
 static Button primaryIcon(Context c,int res,String description,View.OnClickListener action) {
  Button b=iconButton(c,res,description,action);
  GradientDrawable fill=shape(c,MINT,10);
  fill.setStroke(dp(c,2),new ColorStateList(new int[][]{{android.R.attr.state_focused},{android.R.attr.state_hovered},{}},new int[]{NAVY,NAVY,MINT}));
  b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x330b0e14),fill,null));
  b.setCompoundDrawables(icon(c,res,NAVY,24),null,null,null);b.setPadding(dp(c,12),dp(c,12),dp(c,12),dp(c,12));return b;
 }
 static void feedback(View v,int radius) {
  Context c=v.getContext();
  GradientDrawable state=shape(c,0,radius);
  state.setColor(new ColorStateList(new int[][]{{-android.R.attr.state_enabled},{android.R.attr.state_pressed},{android.R.attr.state_focused},{android.R.attr.state_hovered},{android.R.attr.state_selected},{}},new int[]{0,0x33ccff00,0x24ccff00,0x18ccff00,0x12ccff00,0}));
  state.setStroke(dp(c,1),new ColorStateList(new int[][]{{android.R.attr.state_focused},{}},new int[]{MINT,0}));
  android.graphics.drawable.Drawable base=v.getBackground();
  v.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33ccff00),base==null?state:new LayerDrawable(new android.graphics.drawable.Drawable[]{base,state}),shape(c,0xffffffff,radius)));
  v.setFocusable(true);
 }
 static TextView heading(Context c,String text,int size) { TextView v=label(c,text,size,false);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v; }
}
