package kr.keymate.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

/** One overlay travels with PlayerView through portrait, landscape and panel layouts. */
@android.annotation.SuppressLint("ViewConstructor")
final class PlaybackFeedback extends FrameLayout {
 enum State { HIDDEN, LOADING, BUFFERING, FAILED }
 private final ProgressBar progress;
 private final TextView message;
 private final Button retry;
 private State state=State.HIDDEN;
 PlaybackFeedback(Context context,Runnable retrySong){
  super(context);setVisibility(GONE);setClickable(true);
  // Leave the top row free for collapse/fullscreen controls, including large fonts.
  int pad=SingKeyUi.dp(context,24);setPadding(pad,SingKeyUi.dp(context,64),pad,SingKeyUi.dp(context,12));
  LinearLayout content=new LinearLayout(context);content.setOrientation(LinearLayout.VERTICAL);content.setGravity(Gravity.CENTER);
  progress=new ProgressBar(context);progress.setIndeterminateTintList(ColorStateList.valueOf(SingKeyUi.MINT));
  progress.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
  content.addView(progress,new LinearLayout.LayoutParams(SingKeyUi.dp(context,28),SingKeyUi.dp(context,28)));
  message=SingKeyUi.label(context,"",14,false);message.setGravity(Gravity.CENTER);message.setMaxLines(3);
  message.setPadding(0,SingKeyUi.dp(context,12),0,0);message.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
  content.addView(message,new LinearLayout.LayoutParams(-1,-2));
  retry=SingKeyUi.button(context,context.getString(R.string.retry),v->retrySong.run(),false);
  LinearLayout.LayoutParams action=new LinearLayout.LayoutParams(-2,-2);action.topMargin=SingKeyUi.dp(context,12);content.addView(retry,action);
  addView(content,new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER));
 }
 void show(State value){
  if(state==value)return;state=value;
  setVisibility(value==State.HIDDEN?GONE:VISIBLE);
  if(value==State.HIDDEN)return;
  setBackgroundColor(value==State.BUFFERING?0xb30b0e14:SingKeyUi.NAVY);
  progress.setVisibility(value==State.FAILED?GONE:VISIBLE);retry.setVisibility(value==State.FAILED?VISIBLE:GONE);
  message.setPadding(0,value==State.FAILED?0:SingKeyUi.dp(getContext(),12),0,0);
  message.setText(value==State.FAILED?R.string.player_load_failed:value==State.BUFFERING?R.string.player_buffering:R.string.player_loading);
 }
}
