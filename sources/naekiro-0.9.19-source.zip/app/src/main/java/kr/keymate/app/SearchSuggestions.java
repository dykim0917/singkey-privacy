package kr.keymate.app;

import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;
import com.grack.nanojson.*;
import okhttp3.HttpUrl;

/** Small, in-memory suggestion cache; each input owns an independently cancellable session. */
final class SearchSuggestions implements AutoCloseable {
 interface Source { List<String> fetch(String query) throws Exception; }
 private final Source source;
 private final long delayMillis;
 private final ScheduledThreadPoolExecutor worker = new ScheduledThreadPoolExecutor(2);
 private final Map<String,List<String>> cache = new LinkedHashMap<String,List<String>>(20,0.75f,true) {
  @Override protected boolean removeEldestEntry(Map.Entry<String,List<String>> entry) { return size()>20; }
 };
 private volatile boolean closed;

 SearchSuggestions() { this(AppLanguage.KO); }
 SearchSuggestions(AppLanguage language) { this(query -> {
  String url=new HttpUrl.Builder().scheme("https").host("suggestqueries.google.com").addPathSegment("complete").addPathSegment("search")
   .addQueryParameter("client","firefox").addQueryParameter("ds","yt").addQueryParameter("ie","utf-8").addQueryParameter("oe","utf-8")
   .addQueryParameter("hl",language.language).addQueryParameter("gl",language.country).addQueryParameter("q",query).build().toString();
  JsonArray data=JsonParser.array().from(new HttpDownloader().read(url,128*1024));
  if(data.size()<2||!(data.get(1) instanceof JsonArray))throw new java.io.IOException("Suggestions unavailable");
  ArrayList<String> values=new ArrayList<>();for(Object value:(JsonArray)data.get(1))if(value instanceof String)values.add((String)value);return values;
 },300); }
 SearchSuggestions(Source source,long delayMillis) { this.source=source;this.delayMillis=delayMillis;worker.setRemoveOnCancelPolicy(true); }
 static boolean eligible(String input) {
  if(input==null)return false;String value=input.trim();
  return SearchSafety.validInput(input)&&value.length()<=120&&!SearchSafety.looksLikeLink(value)
   &&value.codePoints().anyMatch(c -> Character.isLetterOrDigit(c)&&!(c>=0x1100&&c<=0x11ff)&&!(c>=0x3130&&c<=0x318f));
 }
 static List<String> clean(List<String> values) {
  List<String> result=new ArrayList<>();Set<String> seen=new HashSet<>();
  for(String value:values) {
   if(value==null)continue;String text=value.trim().replaceAll("\\s+"," ");
   if(eligible(text)&&seen.add(text.toLowerCase(Locale.ROOT)))result.add(text);
   if(result.size()==5)break;
  }
  return Collections.unmodifiableList(result);
 }
 Session session(Executor delivery,Consumer<List<String>> receiver) { return new Session(delivery,receiver); }
 final class Session {
  private final Executor delivery;
  private final Consumer<List<String>> receiver;
  private long generation;
  private Future<?> pending;
  Session(Executor delivery,Consumer<List<String>> receiver) {this.delivery=delivery;this.receiver=receiver;}
  synchronized void cancel() { ++generation;if(pending!=null){pending.cancel(true);pending=null;} }
  synchronized void request(String input) {
   cancel();if(closed||!eligible(input))return;
   String query=input.trim();long ticket=generation;
   pending=worker.schedule(()->{
    List<String> values;
    try {
     synchronized(cache){values=cache.get(query);}
     if(values==null){values=clean(source.fetch(query));synchronized(cache){cache.put(query,values);}}
    }catch(Exception ignored){values=Collections.emptyList();}
    List<String> result=values;
    delivery.execute(()->{synchronized(Session.this){if(!closed&&ticket==generation)receiver.accept(result);}});
   },delayMillis,TimeUnit.MILLISECONDS);
  }
 }
 @Override public void close() {closed=true;worker.shutdownNow();synchronized(cache){cache.clear();}}
}
