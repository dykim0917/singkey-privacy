package kr.keymate.app;

import com.grack.nanojson.*;
import java.io.IOException;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import okhttp3.*;

/** Consent-owned, bounded, memory-only event queue using PostHog's public ingestion API. */
final class AnalyticsTransport implements AutoCloseable {
 static final int MAX_EVENTS=200,BATCH_SIZE=50;
 private final String token,distinctId,language,version,buildType;
 private final HttpUrl endpoint;
 private final OkHttpClient http;
 private final ScheduledExecutorService worker;
 private final ArrayDeque<Pending> pending=new ArrayDeque<>();
 private boolean closed,flushQueued;
 private Call inFlight;
 private static final class Pending {final JsonObject event;int attempts;Pending(JsonObject event){this.event=event;}}

 AnalyticsTransport(String token,String host,String distinctId,String language,String version,boolean debug){
  this(token,ingestionEndpoint(host),distinctId,language,version,debug,new OkHttpClient.Builder()
   .followRedirects(false).followSslRedirects(false).callTimeout(15,TimeUnit.SECONDS).build());
 }
 // Endpoint injection is only used by local transport tests.
 AnalyticsTransport(String token,HttpUrl endpoint,String distinctId,String language,String version,boolean debug,OkHttpClient http){
  this.token=token;this.endpoint=endpoint;this.distinctId=distinctId;this.language=language;this.version=version;
  this.buildType=debug?"debug":"release";this.http=http;
  worker=Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r,"SingKeyAnalytics");t.setDaemon(true);return t;});
  worker.scheduleWithFixedDelay(this::send,30,30,TimeUnit.SECONDS);
 }
 static HttpUrl ingestionEndpoint(String host){
  if(!"https://eu.i.posthog.com".equals(host))throw new IllegalArgumentException("Unsupported analytics host");
  return HttpUrl.get(host+"/batch/");
 }
 synchronized void record(UsageEvent event){
  if(closed)return;
  JsonObject props=new JsonObject();props.putAll(event.parameters);
  props.put("app_language",language);props.put("app_version",version);props.put("build_type",buildType);
  props.put("$process_person_profile",false);props.put("$geoip_disable",true);
  JsonObject json=new JsonObject();json.put("event",event.name);json.put("distinct_id",distinctId);
  json.put("properties",props);json.put("timestamp",Instant.now().toString());json.put("uuid",UUID.randomUUID().toString());
  if(pending.size()==MAX_EVENTS)pending.removeFirst();
  pending.addLast(new Pending(json));
  if(pending.size()>=20)flush();
 }
 synchronized void flush(){
  if(closed||flushQueued)return;flushQueued=true;
  worker.execute(()->{synchronized(this){flushQueued=false;}send();});
 }
 private void send(){
  List<Pending> batch=new ArrayList<>();Call call;
  synchronized(this){
   if(closed||pending.isEmpty())return;
   while(!pending.isEmpty()&&batch.size()<BATCH_SIZE)batch.add(pending.removeFirst());
   JsonArray events=new JsonArray();for(Pending item:batch){item.attempts++;events.add(item.event);}
   JsonObject body=new JsonObject();body.put("api_key",token);body.put("batch",events);
   Request request=new Request.Builder().url(endpoint).header("User-Agent","Naekiro/"+version)
    .post(RequestBody.create(JsonWriter.string(body),MediaType.get("application/json; charset=utf-8"))).build();
   call=http.newCall(request);inFlight=call;
  }
  boolean retry=false;
  try(Response response=call.execute()){retry=response.code()==429||response.code()>=500;}
  catch(IOException ignored){retry=true;}
  finally {
   synchronized(this){
    if(inFlight==call)inFlight=null;
    if(!closed&&retry){
     // Retry once at a later flush, preserving the UUID for server deduplication.
     for(int i=batch.size()-1;i>=0;i--){Pending item=batch.get(i);if(item.attempts<2&&pending.size()<MAX_EVENTS)pending.addFirst(item);}
    }
   }
  }
 }
 synchronized int queuedEvents(){return pending.size();}
 @Override public synchronized void close(){
  if(closed)return;closed=true;pending.clear();if(inFlight!=null)inFlight.cancel();worker.shutdownNow();
 }
}
