package kr.keymate.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.*;
import android.graphics.Color;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.webkit.*;
import android.widget.FrameLayout;
import androidx.webkit.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.JSONObject;

/** Visible HTTPS player. No stream extraction, request interception or security bypass. */
@SuppressLint("ViewConstructor")
final class BrowserPlayer extends FrameLayout {
 static final int STATE_IDLE=1,STATE_BUFFERING=2,STATE_READY=3,STATE_ENDED=4;
 interface Listener {
  void onIsPlayingChanged(boolean playing);
  void onPlaybackStateChanged(int state);
  void onPlayerError(Exception error);
  void onPitchUnavailable();
 }
 private static final Set<String> ORIGINS=new HashSet<>(Arrays.asList("https://m.youtube.com","https://www.youtube.com","https://youtube.com"));
 private final Activity activity;
 private final FrameLayout overlay;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private WebView web;
 private ScriptHandler script;
 private Listener listener;
 private String token="",url="",pendingUrl;
 private int state=STATE_IDLE,key;
 private long position;
 private boolean playing,wantsPlayback,released,broken;
 private Exception error;
 private final Runnable timeout=()->fail("Browser playback timeout");
 private final BroadcastReceiver noisy=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent intent){pause();}};

 BrowserPlayer(Activity activity){
  super(activity);this.activity=activity;setBackgroundColor(Color.BLACK);
  // Chromium owns audio focus. A second native focus request steals it from
  // the WebView and immediately pauses playback when the page is unmuted.
  overlay=new FrameLayout(activity);
  createWebView();addView(overlay,new LayoutParams(-1,-1));
  if(Build.VERSION.SDK_INT>=33)activity.registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),Context.RECEIVER_NOT_EXPORTED);
  else activity.registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
 }
 @SuppressLint("SetJavaScriptEnabled")
 private void createWebView(){
  web=new WebView(activity);web.setBackgroundColor(Color.BLACK);
  WebSettings options=web.getSettings();options.setJavaScriptEnabled(true);options.setDomStorageEnabled(true);
  options.setAllowFileAccess(false);options.setAllowContentAccess(false);options.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  options.setMediaPlaybackRequiresUserGesture(false);options.setSupportMultipleWindows(false);
  CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
  web.setWebChromeClient(new WebChromeClient(){@Override public void onPermissionRequest(PermissionRequest request){request.deny();}});
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
    if(!request.isForMainFrame())return false;
    if(allowedOrigin(request.getUrl()))return false;
    // Navigation outside the supported player remains outside the bridge.
    if(request.hasGesture()&&"https".equals(request.getUrl().getScheme())){
     pause();try{activity.startActivity(new Intent(Intent.ACTION_VIEW,request.getUrl()));}catch(ActivityNotFoundException ignored){}
    }else fail("Unsupported player navigation");
    return true;
   }
   @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError problem){if(request.isForMainFrame())fail("Player connection failed");}
   @Override public boolean onRenderProcessGone(WebView view,RenderProcessGoneDetail detail){broken=true;removeView(view);view.destroy();fail("Browser process stopped");return true;}
  });
  LayoutParams content=new LayoutParams(-1,-1);content.topMargin=SingKeyUi.dp(activity,48);addView(web,0,content);
  if(supported())WebViewCompat.addWebMessageListener(web,"singkeyNative",ORIGINS,(view,message,origin,mainFrame,reply)->{
   String data=message.getData();if(released||!mainFrame||!allowedOrigin(origin)||data==null||data.length()>4096)return;
   try{JSONObject event=new JSONObject(data);if(token.equals(event.optString("token")))receive(event);}catch(Exception ignored){}
  });
 }
 private boolean supported(){return WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)&&WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);}
 static boolean allowedOrigin(Uri uri){return uri!=null&&"https".equals(uri.getScheme())&&uri.getUserInfo()==null&&(uri.getPort()==-1||uri.getPort()==443)&&Arrays.asList("m.youtube.com","www.youtube.com","youtube.com").contains(uri.getHost());}
 void addListener(Listener value){listener=value;}
 FrameLayout getOverlayFrameLayout(){return overlay;}
 void load(String canonical,int initialKey,long startPosition,boolean autoplay){
  if(released)return;
  stop();if(broken){script=null;createWebView();broken=false;}
  if(!supported()){fail("Update Android System WebView");return;}
  url=canonical;token=UUID.randomUUID().toString();key=KeyMath.clamp(initialKey);position=Math.max(0,startPosition);wantsPlayback=autoplay;
  error=null;setState(STATE_BUFFERING);
  try{
   String id=canonical.substring(canonical.indexOf("v=")+2);
   if(!id.matches("[A-Za-z0-9_-]{11}"))throw new IOException("Invalid video");
   JSONObject config=new JSONObject().put("token",token).put("videoID",id).put("key",key).put("autoplay",autoplay)
    .put("position",position/1000d).put("diagnostics",BuildConfig.DEBUG)
    .put("wasm",android.util.Base64.encodeToString(assetBytes("BrowserPitchDSP.wasm"),android.util.Base64.NO_WRAP));
   if(script!=null)script.remove();
   String source="(()=>{\n"+asset("AndroidPitchDSP.js")+"\n("+asset("AndroidBrowserPlayback.js")+")("+config+");})();";
   script=WebViewCompat.addDocumentStartJavaScript(web,source,ORIGINS);
   pendingUrl="https://m.youtube.com/watch?v="+id;
   handler.postDelayed(timeout,45000);startWhenVisible();
  }catch(Exception problem){fail("Player assets unavailable");}
 }
 private void startWhenVisible(){
  if(pendingUrl==null||getWindowToken()==null||getWidth()==0||getHeight()==0)return;
  String target=pendingUrl;pendingUrl=null;web.onResume();web.loadUrl(target);
 }
 @Override protected void onAttachedToWindow(){super.onAttachedToWindow();post(this::startWhenVisible);}
 @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){
  super.onSizeChanged(w,h,oldw,oldh);
  // Leave room for the website's own header and 16:9 controls. A full-width
  // desktop-shaped WebView clips its seek bar in a short landscape viewport.
  LayoutParams bounds=(LayoutParams)web.getLayoutParams();
  boolean landscape=activity.getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE;
  bounds.width=landscape?Math.min(w,Math.max(1,(h-SingKeyUi.dp(activity,104))*16/9)):-1;
  bounds.gravity=android.view.Gravity.TOP|android.view.Gravity.CENTER_HORIZONTAL;
  web.setLayoutParams(bounds);post(this::startWhenVisible);
 }
 private void receive(JSONObject message){
  String event=message.optString("event");
  if(BuildConfig.DEBUG&&!event.equals("position")&&!event.equals("metrics"))android.util.Log.d("SingKeyBrowser","event="+event);
  switch(event){
   case "ready":handler.removeCallbacks(timeout);error=null;setState(STATE_READY);if(!wantsPlayback)command("pause",0);break;
   case "playing":
    handler.removeCallbacks(timeout);setState(STATE_READY);
    wantsPlayback=true;setPlaying(true);break;
   case "paused":setPlaying(false);break;
   case "buffering":setPlaying(false);setState(STATE_BUFFERING);break;
   case "ended":setPlaying(false);wantsPlayback=false;setState(STATE_ENDED);break;
   case "failed":case "page_changed":fail("Playback unavailable");break;
   case "pitch_unavailable":setPlaying(false);wantsPlayback=false;if(listener!=null)listener.onPitchUnavailable();break;
   case "original":case "pitch_active":handler.removeCallbacks(timeout);setState(STATE_READY);break;
   case "ad_playing":setPlaying(false);setState(STATE_READY);break;
   case "position":if(!message.optBoolean("ad")){double seconds=message.optDouble("seconds",0);if(Double.isFinite(seconds)&&seconds>=0&&seconds<=86400)position=(long)(seconds*1000);}break;
   case "metrics":if(BuildConfig.DEBUG)android.util.Log.d("SingKeyBrowser",message.toString());break;
   case "diagnostic":if(BuildConfig.DEBUG)android.util.Log.d("SingKeyBrowser",message.optString("reason"));break;
   default:break;
  }
 }
 private void setPlaying(boolean value){if(playing==value)return;playing=value;setKeepScreenOn(value);if(listener!=null)listener.onIsPlayingChanged(value);}
 private void setState(int value){if(state==value)return;state=value;if(listener!=null)listener.onPlaybackStateChanged(value);}
 private void fail(String reason){handler.removeCallbacks(timeout);error=new IOException(reason);setPlaying(false);wantsPlayback=false;setState(STATE_IDLE);if(listener!=null)listener.onPlayerError(error);}
 private void command(String action,double value){if(!released&&!broken)web.evaluateJavascript("globalThis.singkeyBrowserControl?.("+JSONObject.quote(action)+","+value+")",null);}
 void setKey(int value){key=KeyMath.clamp(value);command("key",key);}
 void layoutChanged(){command("layout",0);}
 void play(){if(released||error!=null)return;wantsPlayback=true;web.onResume();command("play",0);}
 void pause(){wantsPlayback=false;command("pause",0);setPlaying(false);}
 void seekTo(long millis){position=Math.max(0,millis);command("seek",position/1000d);}
 void stop(){pause();pendingUrl=null;handler.removeCallbacks(timeout);if(!broken)web.stopLoading();setState(STATE_IDLE);}
 void release(){if(released)return;stop();released=true;handler.removeCallbacksAndMessages(null);activity.unregisterReceiver(noisy);if(!broken){if(script!=null)script.remove();web.destroy();}}
 boolean isPlaying(){return playing;}
 boolean getPlayWhenReady(){return wantsPlayback;}
 int getPlaybackState(){return state;}
 int getMediaItemCount(){return url.isEmpty()?0:1;}
 Exception getPlayerError(){return error;}
 long getCurrentPosition(){return position;}
 private byte[] assetBytes(String name)throws IOException{
  try(InputStream input=activity.getAssets().open("browser/"+name);ByteArrayOutputStream result=new ByteArrayOutputStream()){
   byte[] buffer=new byte[8192];int n;while((n=input.read(buffer))!=-1){if(result.size()+n>1024*1024)throw new IOException("Asset too large");result.write(buffer,0,n);}return result.toByteArray();
  }
 }
 private String asset(String name)throws IOException{return new String(assetBytes(name),StandardCharsets.UTF_8);}
}
