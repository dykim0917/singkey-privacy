package kr.keymate.app;

import android.app.Activity;
import android.widget.Toast;
import com.google.android.ump.*;

final class AdvertisingConsent {
 private final Activity activity;
 private final ConsentInformation information;
 private final Runnable changed;
 private boolean ready,formOpen;
 AdvertisingConsent(Activity activity,Runnable changed){this.activity=activity;this.changed=changed;information=BuildConfig.ADS_ENABLED?UserMessagingPlatform.getConsentInformation(activity):null;}
 boolean canRequest(){return BuildConfig.ADS_ENABLED&&ready&&!formOpen&&BuildConfig.ADS_CONFIGURED;}
 boolean optionsRequired(){return information!=null&&information.getPrivacyOptionsRequirementStatus()==ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED;}
 void start(){
  if(!BuildConfig.ADS_ENABLED||!BuildConfig.ADS_CONFIGURED)return;
  // Google's sample application cannot host this publisher's UMP message. Only debug test ads bypass it.
  if(BuildConfig.DEBUG&&BuildConfig.ADS_SAMPLE_APP){ready=true;changed.run();return;}
  ConsentRequestParameters.Builder parameters=new ConsentRequestParameters.Builder();
  if(BuildConfig.DEBUG&&BuildConfig.ADS_TEST_EEA)parameters.setConsentDebugSettings(new ConsentDebugSettings.Builder(activity).setDebugGeography(ConsentDebugSettings.DebugGeography.DEBUG_GEOGRAPHY_EEA).build());
  information.requestConsentInfoUpdate(activity,parameters.build(),()->{
   if(activity.isDestroyed())return;
   formOpen=true;changed.run();
   UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity,error->{formOpen=false;debugError(error);refresh();});
  },error->{debugError(error);refresh();});
 }
 private void debugError(FormError error){if(BuildConfig.DEBUG&&error!=null)android.util.Log.d("SingKeyAds","Consent: "+error.getErrorCode()+" "+error.getMessage());}
 private void refresh(){if(activity.isDestroyed()||information==null)return;ready=information.canRequestAds();changed.run();}
 void showOptions(){
  if(!BuildConfig.ADS_ENABLED)return;
  if(!optionsRequired()){Toast.makeText(activity,R.string.ads_privacy_not_required,Toast.LENGTH_LONG).show();return;}
  formOpen=true;changed.run();
  UserMessagingPlatform.showPrivacyOptionsForm(activity,error->{formOpen=false;refresh();if(error!=null)Toast.makeText(activity,R.string.ads_privacy_failed,Toast.LENGTH_LONG).show();});
 }
}
