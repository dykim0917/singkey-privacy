package kr.keymate.app;

import java.util.*;

/** Fixed schemas: no URL, query, song/list name, email, or exception message can enter an event. */
final class UsageEvent {
 final String name;
 final Map<String,Object> parameters;
 private UsageEvent(String name,Object... pairs){
  this.name=name;Map<String,Object> values=new LinkedHashMap<>();
  for(int i=0;i<pairs.length;i+=2)values.put((String)pairs[i],pairs[i+1]);
  parameters=Collections.unmodifiableMap(values);
 }
 static UsageEvent screen(String page,boolean landscape){
  String value=Arrays.asList("home","search","player","library","settings","help","contact","info").contains(page)?page:"other";
  return new UsageEvent("screen_view","screen_name",value,"screen_class","MainActivity","layout",landscape?"landscape":"portrait");
 }
 static UsageEvent search(boolean backing,boolean landscape){return new UsageEvent("search_submitted","backing",backing?1L:0L,"layout",landscape?"landscape":"portrait");}
 static UsageEvent results(int count,boolean failed){return new UsageEvent("search_completed","result_count",(long)Math.min(100,Math.max(0,count)),"outcome",failed?"error":count==0?"empty":"success");}
 static UsageEvent key(int from,int to){return new UsageEvent("pitch_changed","from_semitones",(long)KeyMath.clamp(from),"to_semitones",(long)KeyMath.clamp(to));}
 static UsageEvent saved(int key){return new UsageEvent("song_saved","semitones",(long)KeyMath.clamp(key));}
 static UsageEvent queued(int count){return new UsageEvent("queue_added","queue_size",(long)Math.min(1000,Math.max(0,count)));}
 static UsageEvent started(boolean saved,int key){return new UsageEvent("practice_started","saved_song",saved?1L:0L,"semitones",(long)KeyMath.clamp(key));}
 static UsageEvent practice(long millis){return new UsageEvent("practice_time","seconds",Math.min(14400L,Math.max(0,millis/1000)));}
 static UsageEvent failure(boolean extraction){return new UsageEvent("playback_failed","stage",extraction?"extraction":"player");}
 static UsageEvent ad(String placement,boolean impression){return new UsageEvent(impression?"banner_impression":"banner_load_failed","placement",Arrays.asList("home","player","landscape").contains(placement)?placement:"other");}
}
