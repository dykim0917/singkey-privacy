package kr.keymate.app;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Native autocomplete with bounded suggestions and no network work on the UI thread. */
@android.annotation.SuppressLint("ViewConstructor") // Constructed in code with the Activity-owned source, never inflated.
final class SearchInput extends AutoCompleteTextView {
 private final SuggestionAdapter suggestions;
 private final SearchSuggestions.Session session;
 private final ViewTreeObserver.OnGlobalLayoutListener layoutListener=this::showAvailableSuggestions;
 private String requested="";
 private Runnable submit;
 private View suggestionsAnchor;
 private final View.OnLayoutChangeListener anchorLayout=(v,l,t,r,b,ol,ot,or,ob)->setDropDownWidth(r-l);

 SearchInput(Context context,SearchSuggestions source) {
  super(context);setThreshold(1);setSingleLine(true);
  setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(SearchSafety.MAX_INPUT)});
  setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH|android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI);
  setDropDownBackgroundDrawable(SingKeyUi.outline(context,SingKeyUi.RAISED,12,0xff394351));
  setDropDownVerticalOffset(SingKeyUi.dp(context,4));
  if(Build.VERSION.SDK_INT>=29)setInputMethodMode(ListPopupWindow.INPUT_METHOD_NEEDED);
  suggestions=new SuggestionAdapter();setAdapter(suggestions);
  Handler main=new Handler(Looper.getMainLooper());
  session=source.session(main::post,values->{
   if(!hasFocus()||!isShown()||!getText().toString().trim().equals(requested))return;
   suggestions.replace(values);showAvailableSuggestions();
  });
  addTextChangedListener(new TextWatcher(){
   public void beforeTextChanged(CharSequence s,int start,int count,int after){}
   public void onTextChanged(CharSequence s,int start,int before,int count){}
   public void afterTextChanged(Editable value){if(isPerformingCompletion())stopSuggestions();else requestSuggestions();}
  });
  setOnClickListener(v->requestSuggestions());
  setOnItemClickListener((parent,view,position,id)->{finishInput();if(submit!=null)submit.run();});
  setOnDismissListener(()->{
   // AutoCompleteTextView also dismisses after an empty adapter update; that
   // must not cancel the newer request which is still waiting for debounce.
   if(suggestions.getCount()>0){session.cancel();requested="";suggestions.replace(Collections.emptyList());}
  });
 }
 void onSuggestion(Runnable action) {submit=action;}
 void anchorTo(View anchor) {
  if(suggestionsAnchor==anchor)return;
  if(suggestionsAnchor!=null)suggestionsAnchor.removeOnLayoutChangeListener(anchorLayout);
  suggestionsAnchor=anchor;
  if(anchor.getId()==View.NO_ID)anchor.setId(View.generateViewId());setDropDownAnchor(anchor.getId());
  if(anchor.getWidth()>0)setDropDownWidth(anchor.getWidth());
  anchor.addOnLayoutChangeListener(anchorLayout);
 }
 void finishInput() {
  stopSuggestions();clearFocus();
  ((android.view.inputmethod.InputMethodManager)getContext().getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getWindowToken(),0);
 }
 void stopSuggestions() {
  if(session==null)return;session.cancel();requested="";suggestions.replace(Collections.emptyList());super.dismissDropDown();
 }
 private void requestSuggestions() {
  stopSuggestions();
  if(!hasFocus()||!isShown()||!SearchSuggestions.eligible(getText().toString()))return;
  requested=getText().toString().trim();session.request(requested);
 }
 @Override protected void performFiltering(CharSequence text,int keyCode) { /* Debounced by our session. */ }
 private void showAvailableSuggestions() {
  if(suggestions==null||suggestions.getCount()==0||!hasFocus()||!isShown()||!hasWindowFocus())return;
  Rect frame=new Rect();getWindowVisibleDisplayFrame(frame);
  View anchor=getRootView().findViewById(getDropDownAnchor());if(anchor==null)anchor=this;
  int[] location=new int[2];anchor.getLocationOnScreen(location);
  int room=frame.bottom-location[1]-anchor.getHeight()-SingKeyUi.dp(getContext(),8);
  TextView item=(TextView)suggestions.getView(0,null,null);
  item.measure(MeasureSpec.makeMeasureSpec(Math.max(getWidth(),1),MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(0,MeasureSpec.UNSPECIFIED));
  // Never obscure the keyboard or show an unreadable fraction of a suggestion.
  if(room<item.getMeasuredHeight()){if(isPopupShowing())super.dismissDropDown();return;}
  int rows=Math.min(suggestions.getCount(),Math.min(room,SingKeyUi.dp(getContext(),260))/item.getMeasuredHeight());
  int height=rows*item.getMeasuredHeight();
  if(getDropDownHeight()!=height)setDropDownHeight(height);
  if(!isPopupShowing())showDropDown();
 }
 @Override protected void onFocusChanged(boolean focused,int direction,Rect old) {
  super.onFocusChanged(focused,direction,old);
  if(session!=null){if(focused)requestSuggestions();else stopSuggestions();}
 }
 @Override protected void onWindowVisibilityChanged(int visibility) {
  super.onWindowVisibilityChanged(visibility);if(visibility!=View.VISIBLE)stopSuggestions();
 }
 @Override public boolean onKeyPreIme(int keyCode,KeyEvent event) {
  if(keyCode==KeyEvent.KEYCODE_BACK&&event.getAction()==KeyEvent.ACTION_DOWN&&isPopupShowing())stopSuggestions();
  return super.onKeyPreIme(keyCode,event);
 }
 @Override protected void onAttachedToWindow() {super.onAttachedToWindow();getViewTreeObserver().addOnGlobalLayoutListener(layoutListener);}
 @Override protected void onDetachedFromWindow() {stopSuggestions();getViewTreeObserver().removeOnGlobalLayoutListener(layoutListener);super.onDetachedFromWindow();}

 private final class SuggestionAdapter extends BaseAdapter implements Filterable {
  private List<String> values=Collections.emptyList();
  // The popup is dismissed before replacing rows and rebuilt on showDropDown.
  // Notifying AutoCompleteTextView here would let its observer open an
  // unbounded popup above the input, covering the landscape tabs.
  void replace(List<String> value){values=value;}
  public int getCount(){return values.size();}
  public String getItem(int position){return values.get(position);}
  public long getItemId(int position){return position;}
  public View getView(int position,View convert,ViewGroup parent) {
   TextView text=convert instanceof TextView?(TextView)convert:SingKeyUi.label(getContext(),"",16,false);
   text.setText(getItem(position));text.setContentDescription(getContext().getString(R.string.suggested_query,getItem(position)));
   text.setSingleLine(true);text.setEllipsize(TextUtils.TruncateAt.END);text.setGravity(Gravity.CENTER_VERTICAL);
   text.setMinHeight(SingKeyUi.dp(getContext(),48));text.setPadding(SingKeyUi.dp(getContext(),12),SingKeyUi.dp(getContext(),12),SingKeyUi.dp(getContext(),12),SingKeyUi.dp(getContext(),12));
   text.setCompoundDrawables(SingKeyUi.icon(getContext(),R.drawable.ic_sk_search,SingKeyUi.MUTED,18),null,null,null);text.setCompoundDrawablePadding(SingKeyUi.dp(getContext(),10));
   return text;
  }
  public Filter getFilter(){return new Filter(){
   protected FilterResults performFiltering(CharSequence constraint){return new FilterResults();}
   protected void publishResults(CharSequence constraint,FilterResults results){}
  };}
 }
}
