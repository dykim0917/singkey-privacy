package kr.keymate.app;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import com.grack.nanojson.JsonParser;
import okhttp3.*;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

final class SupportForm implements AutoCloseable {
 private final Activity activity;
 private final OkHttpClient client=new OkHttpClient.Builder().connectTimeout(10,TimeUnit.SECONDS).readTimeout(25,TimeUnit.SECONDS).callTimeout(35,TimeUnit.SECONDS).build();
 private EditText email,message;
 private Spinner topic;
 private TextView status;
 private Button send;
 private CheckBox consent;
 private Call call;
 private boolean closed;
 private String requestId=UUID.randomUUID().toString(),lastPayload="";
 private static final String[] TOPICS={"problem","idea","other"};
 SupportForm(Activity activity){this.activity=activity;}
 void populate(LinearLayout page,Runnable back,Bundle saved){
  page.removeAllViews();SettingsPage.header(page,R.string.contact_title,back);
  addText(page,R.string.contact_intro,14);
  addText(page,R.string.contact_topic,13);
  topic=new Spinner(activity);ArrayAdapter<String> adapter=new ArrayAdapter<>(activity,android.R.layout.simple_spinner_dropdown_item,new String[]{activity.getString(R.string.contact_problem),activity.getString(R.string.contact_idea),activity.getString(R.string.contact_other)});topic.setAdapter(adapter);topic.setMinimumHeight(dp(48));topic.setContentDescription(activity.getString(R.string.contact_topic));page.addView(topic,new LinearLayout.LayoutParams(-1,-2));
  addText(page,R.string.contact_reply,13);email=field(page,R.string.contact_reply_hint,254);email.setContentDescription(activity.getString(R.string.contact_reply));email.setSingleLine(true);email.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
  addText(page,R.string.contact_message,13);message=field(page,R.string.contact_message_hint,3000);message.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);message.setGravity(Gravity.TOP);message.setMinLines(5);message.setMaxLines(8);
  TextView metadata=SingKeyUi.label(activity,activity.getString(R.string.contact_metadata,SettingsPage.version(activity),android.os.Build.VERSION.RELEASE),12,true);metadata.setPadding(0,dp(12),0,dp(8));page.addView(metadata);
  consent=new CheckBox(activity);consent.setText(R.string.contact_consent);consent.setTextColor(SingKeyUi.MUTED);consent.setTextSize(12);consent.setMinHeight(dp(48));consent.setButtonTintList(android.content.res.ColorStateList.valueOf(SingKeyUi.MINT));page.addView(consent,new LinearLayout.LayoutParams(-1,-2));
  status=SingKeyUi.label(activity,"",13,true);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);status.setPadding(0,dp(8),0,dp(8));page.addView(status);
  send=SingKeyUi.button(activity,activity.getString(R.string.contact_send),v->submit(),true);page.addView(send,new LinearLayout.LayoutParams(-1,-2));
  TextView fallback=SingKeyUi.label(activity,"getbathtime@gmail.com",12,true);fallback.setTextIsSelectable(true);fallback.setPadding(0,dp(12),0,dp(12));page.addView(fallback);
  if(saved!=null){email.setText(saved.getString("contactEmail",""));message.setText(saved.getString("contactMessage",""));topic.setSelection(Math.max(0,Math.min(2,saved.getInt("contactTopic",0))));consent.setChecked(saved.getBoolean("contactConsent",false));requestId=saved.getString("contactId",requestId);lastPayload=saved.getString("contactPayload","");}
 }
 void save(Bundle state){if(email!=null){state.putString("contactEmail",email.getText().toString());state.putString("contactMessage",message.getText().toString());state.putInt("contactTopic",topic.getSelectedItemPosition());state.putBoolean("contactConsent",consent.isChecked());state.putString("contactId",requestId);state.putString("contactPayload",lastPayload);}}
 private void submit(){
  String reply=email.getText().toString().trim(),body=message.getText().toString().trim();
  if(!SupportRequest.validEmail(reply)){email.setError(activity.getString(R.string.contact_invalid_email));email.requestFocus();return;}
  if(!SupportRequest.validMessage(body)){message.setError(activity.getString(R.string.contact_invalid_message));message.requestFocus();return;}
  if(!consent.isChecked()){status.setText(R.string.contact_need_consent);return;}
  String endpoint=activity.getString(R.string.support_endpoint);
  if(!endpoint.startsWith("https://")){status.setText(R.string.contact_unavailable);return;}
  String signature=TOPICS[topic.getSelectedItemPosition()]+"\n"+reply+"\n"+body+"\n"+SettingsPage.version(activity)+"\n"+android.os.Build.VERSION.RELEASE+"\n"+LanguagePreferences.resolve(activity).language;
  if(!signature.equals(lastPayload)){requestId=UUID.randomUUID().toString();lastPayload=signature;}
  String json=SupportRequest.json(requestId,TOPICS[topic.getSelectedItemPosition()],reply,body,SettingsPage.version(activity),android.os.Build.VERSION.RELEASE,LanguagePreferences.resolve(activity).language);
  ((InputMethodManager)activity.getSystemService(Activity.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(message.getWindowToken(),0);
  sending(true);status.setText(R.string.contact_sending);
  call=client.newCall(new Request.Builder().url(endpoint).post(RequestBody.create(json,MediaType.get("application/json; charset=utf-8"))).build());
  call.enqueue(new Callback(){
   @Override public void onFailure(Call call,IOException e){done(false,false);}
   @Override public void onResponse(Call call,Response response){
    boolean success=false,limited=false;
    try(Response r=response){if(r.isSuccessful()&&r.body()!=null){com.grack.nanojson.JsonObject result=JsonParser.object().from(r.body().string());success="sent".equals(result.getString("status"));limited="limited".equals(result.getString("status"));}else limited=r.code()==429;}
    catch(Exception ignored){}done(success,limited);
   }
  });
 }
 private void done(boolean success,boolean limited){activity.runOnUiThread(()->{
  if(closed||activity.isDestroyed())return;call=null;sending(false);
  status.setText(success?R.string.contact_sent:limited?R.string.contact_limited:R.string.contact_failed);
  if(success){email.setText("");message.setText("");consent.setChecked(false);requestId=UUID.randomUUID().toString();lastPayload="";}
 });}
 private void sending(boolean busy){send.setEnabled(!busy);email.setEnabled(!busy);message.setEnabled(!busy);topic.setEnabled(!busy);consent.setEnabled(!busy);}
 private EditText field(LinearLayout page,int hint,int max){EditText field=new EditText(activity);SingKeyUi.field(field);field.setHint(hint);field.setContentDescription(activity.getString(hint));field.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max)});page.addView(field,new LinearLayout.LayoutParams(-1,-2));return field;}
 private void addText(LinearLayout page,int res,int size){TextView label=SingKeyUi.label(activity,activity.getString(res),size,true);label.setPadding(0,dp(16),0,dp(8));page.addView(label);}
 private int dp(int value){return SingKeyUi.dp(activity,value);}
 @Override public void close(){closed=true;new Thread(()->{try{client.dispatcher().cancelAll();client.connectionPool().evictAll();}finally{client.dispatcher().executorService().shutdown();}},"singkey-support-close").start();}
}
