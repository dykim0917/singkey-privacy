package kr.keymate.app;

import com.grack.nanojson.*;
import java.io.IOException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.*;
import okhttp3.*;

/** Public karaoke charts, limited to ten text entries; no guessed video URLs. */
final class FeaturedSongs implements AutoCloseable {
 static final String SOURCE_URL = "https://www.tjmedia.co.kr/chart/top100";
 static final String JAPAN_SOURCE_URL = "https://www.joysound.com/web/karaoke/ranking/all/monthly";
 static final String POP_CATALOG_URL = "https://www.karafun.com/karaoke/best-karaoke/";
 private static final String API_URL = "https://www.tjmedia.co.kr/legacy/api/topAndHot100";
 private static final ZoneId SEOUL = ZoneId.of("Asia/Seoul");
 // Monthly aggregation can exceed OkHttp's default ten-second read timeout.
 private final OkHttpClient client = new OkHttpClient.Builder().readTimeout(25,TimeUnit.SECONDS)
  .callTimeout(30,TimeUnit.SECONDS).build();
 private volatile boolean closed;

 static final class Entry {
  final int rank;
  final String title, artist, query;
  Entry(int rank,String title,String artist) {
   this.rank=rank;this.title=title;this.artist=artist;query=artist+" "+title;
  }
 }
 static final class Chart {
  final HomeCategory category;
  final LocalDate start, end;
  final long fetchedAt;
  final List<Entry> entries;
  Chart(LocalDate start,LocalDate end,long fetchedAt,List<Entry> entries) {
   this(HomeCategory.KOREAN,start,end,fetchedAt,entries);
  }
  Chart(HomeCategory category,LocalDate start,LocalDate end,long fetchedAt,List<Entry> entries) {
   this.category=category;
   this.start=start;this.end=end;this.fetchedAt=fetchedAt;
   this.entries=Collections.unmodifiableList(new ArrayList<>(entries));
  }
  boolean isFresh(long now) { return fetchedAt<=now && day(fetchedAt).equals(day(now)); }
  String periodLabel() {
   DateTimeFormatter date=DateTimeFormatter.ofPattern("yyyy.MM.dd",Locale.KOREA);
   return start.format(date)+" – "+end.format(date);
  }
  String encode() {
   JsonObject root=new JsonObject();root.put("version",2);root.put("category",category.id);root.put("start",start.toString());
   root.put("end",end.toString());root.put("fetchedAt",fetchedAt);JsonArray rows=new JsonArray();
   for(Entry entry:entries) {
    JsonObject row=new JsonObject();row.put("rank",entry.rank);row.put("indexTitle",entry.title);
    row.put("indexSong",entry.artist);rows.add(row);
   }
   root.put("items",rows);return JsonWriter.string(root);
  }
 }
 private static LocalDate day(long time) { return Instant.ofEpochMilli(time).atZone(SEOUL).toLocalDate(); }
 static LocalDate[] periodFromPage(String html) throws IOException {
  LocalDate[] dates=new LocalDate[2];String[] fields={"searchStartDate","searchEndDate"};
  try {
   for(int i=0;i<fields.length;i++) {
    Matcher match=Pattern.compile("\\$\\([\"']#"+fields[i]+"[\"']\\)\\.val\\([\"'](\\d{4}-\\d{2}-\\d{2})[\"']\\)").matcher(html);
    if(!match.find())throw new IOException("Missing TJ chart period");
    dates[i]=LocalDate.parse(match.group(1));
   }
   validatePeriod(dates[0],dates[1]);return dates;
  } catch(DateTimeException e) {throw new IOException("Invalid TJ chart period",e);}
 }
 private static void validatePeriod(LocalDate start,LocalDate end) throws IOException {
  if(start.isAfter(end)||start.isBefore(end.minusDays(62)))throw new IOException("Invalid chart range");
 }
 Chart fetch() throws IOException {
  // Follow the official page's default aggregation period, including month boundaries.
  LocalDate[] period=periodFromPage(read(new Request.Builder().url(SOURCE_URL).build()));
  if(period[1].isAfter(day(System.currentTimeMillis())))throw new IOException("Future chart period");
  FormBody form=new FormBody.Builder().add("chartType","TOP").add("strType","")
   .add("searchStartDate",period[0].toString()).add("searchEndDate",period[1].toString()).build();
  String json=read(new Request.Builder().url(API_URL).post(form).build());
  return parseResponse(json,period[0],period[1],System.currentTimeMillis());
 }
 Chart fetch(HomeCategory category) throws IOException {
  if(category==HomeCategory.KOREAN)return fetch();
  if(category==HomeCategory.JAPANESE)return parseJoysound(read(new Request.Builder().url(JAPAN_SOURCE_URL).build()),System.currentTimeMillis());
  throw new IllegalArgumentException("Recommendations are local, not a chart");
 }
 static String sourceUrl(HomeCategory category) {
  return category==HomeCategory.KOREAN?SOURCE_URL:category==HomeCategory.JAPANESE?JAPAN_SOURCE_URL:POP_CATALOG_URL;
 }
 static List<Entry> popRecommendations() {
  // SingKey editorial picks from a verified karaoke catalog; zero means no rank.
  return Collections.unmodifiableList(Arrays.asList(
   new Entry(0,"Dancing Queen","ABBA"),new Entry(0,"Someone Like You","Adele"),
   new Entry(0,"I Want It That Way","Backstreet Boys"),new Entry(0,"Pink Pony Club","Chappell Roan"),
   new Entry(0,"Can't Help Falling in Love","Elvis Presley"),new Entry(0,"My Way","Frank Sinatra"),
   new Entry(0,"Don't Stop Believin'","Journey"),new Entry(0,"Wonderwall","Oasis"),
   new Entry(0,"Creep","Radiohead"),new Entry(0,"Zombie","The Cranberries")));
 }
 static Chart parseJoysound(String html,long fetchedAt) throws IOException {
  try {
   org.jsoup.nodes.Document page=org.jsoup.Jsoup.parse(html);
   YearMonth month=null;
   Pattern period=Pattern.compile("^集計期間[:：]\\s*(\\d{4})/(\\d{2})$");
   for(org.jsoup.nodes.Element p:page.select("p")) {
    Matcher match=period.matcher(p.text());
    if(match.matches()) {
     if(month!=null)throw new IOException("Ambiguous JOYSOUND period");
     month=YearMonth.of(Integer.parseInt(match.group(1)),Integer.parseInt(match.group(2)));
    }
   }
   if(month==null||!month.isBefore(YearMonth.from(day(fetchedAt))))throw new IOException("Missing or unfinished JOYSOUND month");
   JsonArray entries=null;
   for(org.jsoup.nodes.Element script:page.select("script[type=application/ld+json]")) {
    JsonArray graph=JsonParser.object().from(script.data()).getArray("@graph");
    if(graph==null)continue;
    for(Object item:graph) {
     if(!(item instanceof JsonObject))continue;
     JsonObject node=(JsonObject)item;
     if(!"WebPage".equals(node.getString("@type"))||!JAPAN_SOURCE_URL.equals(node.getString("url")))continue;
     JsonObject list=node.getObject("mainEntity");
     if(list==null||!"ItemList".equals(list.getString("@type")))continue;
     if(entries!=null)throw new IOException("Ambiguous JOYSOUND ranking");
     entries=list.getArray("itemListElement");
    }
   }
   if(entries==null||entries.size()>100)throw new IOException("Missing JOYSOUND ranking");
   JsonArray rows=new JsonArray();
   for(Object item:entries) {
    JsonObject ranked=(JsonObject)item, song=ranked.getObject("item");
    if(!"ListItem".equals(ranked.getString("@type"))||!"MusicRecording".equals(song.getString("@type")))throw new IOException("Invalid JOYSOUND song");
    JsonObject row=new JsonObject();row.put("rank",ranked.get("position"));row.put("indexTitle",song.getString("name"));
    row.put("indexSong",song.getObject("byArtist").getString("name"));rows.add(row);
   }
   return chart(HomeCategory.JAPANESE,month.atDay(1),month.atEndOfMonth(),fetchedAt,rows);
  } catch(JsonParserException|RuntimeException e) {throw new IOException("Invalid JOYSOUND chart",e);}
 }
 private String read(Request request) throws IOException {
  if(closed)throw new IOException("Chart source closed");
  Call call=client.newCall(request);
  if(closed){call.cancel();throw new IOException("Chart source closed");}
  try(Response response=call.execute()) {
   if(!response.isSuccessful()||response.body()==null)throw new IOException("Chart HTTP "+response.code());
   java.io.InputStream input=response.body().byteStream();
   java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;
   while((count=input.read(buffer))!=-1) {
    if(bytes.size()+count>1_000_000)throw new IOException("Chart response too large");
    bytes.write(buffer,0,count);
   }
   return new String(bytes.toByteArray(),java.nio.charset.StandardCharsets.UTF_8);
  }
 }
 static Chart parseResponse(String json,LocalDate start,LocalDate end,long fetchedAt) throws IOException {
  try {
   JsonObject root=JsonParser.object().from(json);
   if(!"99".equals(root.getString("resultCode")))throw new IOException("TJ chart unavailable");
   return chart(start,end,fetchedAt,root.getObject("resultData").getArray("items"));
  } catch(JsonParserException|RuntimeException e) {throw new IOException("Invalid TJ chart response",e);}
 }
 static Chart decode(String value) throws IOException {
  if(value==null||value.isEmpty())return null;
  try {
   JsonObject root=JsonParser.object().from(value);
   int version=root.getInt("version");
   if(version!=1&&version!=2)throw new IOException("Unknown chart cache");
   HomeCategory category=HomeCategory.KOREAN;
   if(version==2) {
    String id=root.getString("category");
    if(HomeCategory.JAPANESE.id.equals(id))category=HomeCategory.JAPANESE;
    else if(!HomeCategory.KOREAN.id.equals(id))throw new IOException("Unknown chart category");
   }
   return chart(category,LocalDate.parse(root.getString("start")),LocalDate.parse(root.getString("end")),
    root.getLong("fetchedAt"),root.getArray("items"));
  } catch(JsonParserException|RuntimeException e) {throw new IOException("Invalid chart cache",e);}
 }
 private static Chart chart(LocalDate start,LocalDate end,long fetchedAt,JsonArray rows) throws IOException {
  return chart(HomeCategory.KOREAN,start,end,fetchedAt,rows);
 }
 private static Chart chart(HomeCategory category,LocalDate start,LocalDate end,long fetchedAt,JsonArray rows) throws IOException {
  validatePeriod(start,end);
  if(fetchedAt<=0||rows==null||rows.size()>100)throw new IOException("Invalid chart data");
  TreeMap<Integer,Entry> top=new TreeMap<>();
  for(Object value:rows) {
   if(!(value instanceof JsonObject))throw new IOException("Invalid chart row");
   JsonObject row=(JsonObject)value;int rank=Integer.parseInt(String.valueOf(row.get("rank")));
   if(rank<1||rank>100)throw new IOException("Invalid rank");
   if(rank>10)continue;
   Entry entry=new Entry(rank,clean(row.getString("indexTitle")),clean(row.getString("indexSong")));
   if(top.put(rank,entry)!=null)throw new IOException("Duplicate rank");
  }
  // Reject incomplete responses instead of presenting a partial or invented ranking.
  if(top.size()!=10)throw new IOException("Incomplete TOP10");
  if(end.isAfter(day(fetchedAt)))throw new IOException("Future chart period");
  if(category==HomeCategory.JAPANESE&&(!start.equals(start.withDayOfMonth(1))||!end.equals(start.withDayOfMonth(start.lengthOfMonth()))))throw new IOException("Invalid monthly chart range");
  return new Chart(category,start,end,fetchedAt,new ArrayList<>(top.values()));
 }
 private static String clean(String value) throws IOException {
  if(value==null)throw new IOException("Missing song text");
  String text=org.jsoup.parser.Parser.unescapeEntities(value,false).trim().replaceAll("\\s+"," ");
  if(text.isEmpty()||text.length()>300)throw new IOException("Invalid song text");
  return text;
 }
 @Override public void close() {
  if(closed)return;closed=true;
  // TLS shutdown can write close_notify; Activity recreation must not do network IO.
  new Thread(()->{try{client.dispatcher().cancelAll();client.connectionPool().evictAll();}finally{client.dispatcher().executorService().shutdown();}},"singkey-chart-close").start();
 }
}
