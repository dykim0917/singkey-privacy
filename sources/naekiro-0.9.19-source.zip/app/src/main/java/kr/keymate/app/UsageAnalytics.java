package kr.keymate.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.UUID;

final class UsageAnalytics {
 private final SharedPreferences preferences;
 private AnalyticsTransport transport;
 private static final String CONSENT="posthog_analytics_allowed";
 private static final String IDENTITY="posthog_installation_id";
 private final String appLanguage;
 private final PracticeMeter meter=new PracticeMeter();
 private boolean enabled,playing;
 private String lastScreen="";
 UsageAnalytics(Activity activity){
  preferences=activity.getSharedPreferences("usage_privacy",Activity.MODE_PRIVATE);
  // A different processor needs a fresh choice; never inherit the old Firebase consent.
  enabled=configured()&&preferences.getBoolean(CONSENT,false);
  appLanguage=AppLanguage.from(activity.getResources().getConfiguration().getLocales().get(0)).language;
  if(enabled)startTransport();
 }
 boolean enabled(){return enabled;}
 boolean configured(){return !BuildConfig.ANALYTICS_TOKEN.isEmpty();}
 void askIfNeeded(Activity activity,Runnable next){
  if(!configured()||preferences.contains(CONSENT)){next.run();return;}
  prompt(activity,next);
 }
 void prompt(Activity activity,Runnable next){
  // A single scrollable column keeps both choices reachable with large system fonts.
  LinearLayout content=new LinearLayout(activity);content.setOrientation(LinearLayout.VERTICAL);
  int pad=SingKeyUi.dp(activity,20);content.setPadding(pad,pad,pad,pad);content.setBackgroundColor(SingKeyUi.SURFACE);
  TextView title=SingKeyUi.heading(activity,activity.getString(R.string.analytics_consent_title),20);
  if(android.os.Build.VERSION.SDK_INT>=28)title.setAccessibilityHeading(true);content.addView(title);
  TextView message=SingKeyUi.label(activity,activity.getString(R.string.analytics_consent_message),16,false);message.setPadding(0,pad,0,pad);content.addView(message);
  ScrollView scroll=new ScrollView(activity);scroll.addView(content);
  AlertDialog dialog=new AlertDialog.Builder(activity).setView(scroll).create();
  content.addView(SingKeyUi.button(activity,activity.getString(R.string.analytics_allow),v->{setEnabled(true);dialog.dismiss();next.run();},false),new LinearLayout.LayoutParams(-1,-2));
  LinearLayout.LayoutParams declineLayout=new LinearLayout.LayoutParams(-1,-2);declineLayout.topMargin=SingKeyUi.dp(activity,8);
  content.addView(SingKeyUi.button(activity,activity.getString(R.string.analytics_decline),v->{setEnabled(false);dialog.dismiss();next.run();},false),declineLayout);
  dialog.setOnCancelListener(d->{setEnabled(false);next.run();});dialog.show();
 }
 void setEnabled(boolean allowed){
  meter.reset();enabled=allowed&&configured();lastScreen="";
  preferences.edit().putBoolean(CONSENT,enabled).apply();
  if(transport!=null){transport.close();transport=null;}
  if(enabled)startTransport();else preferences.edit().remove(IDENTITY).apply();
  if(enabled&&playing)meter.playing(true,SystemClock.elapsedRealtime());
 }
 private void startTransport(){
  String identity=preferences.getString(IDENTITY,null);
  if(identity==null){identity=UUID.randomUUID().toString();preferences.edit().putString(IDENTITY,identity).apply();}
  transport=new AnalyticsTransport(BuildConfig.ANALYTICS_TOKEN,BuildConfig.ANALYTICS_HOST,identity,appLanguage,BuildConfig.VERSION_NAME,BuildConfig.DEBUG);
 }
 void record(UsageEvent event){
  if(!enabled||transport==null)return;
  if(BuildConfig.DEBUG)android.util.Log.d("SingKeyAnalytics",event.name+" "+event.parameters);
  transport.record(event);
 }
 void screen(String page,boolean landscape){String screen=page+":"+landscape;if(screen.equals(lastScreen))return;lastScreen=screen;record(UsageEvent.screen(page,landscape));}
 void playing(boolean value){playing=value;if(enabled)meter.playing(value,SystemClock.elapsedRealtime());}
 void flushPractice(){long time=meter.take(SystemClock.elapsedRealtime());if(time>=1000)record(UsageEvent.practice(time));if(transport!=null)transport.flush();}
 void close(){if(transport!=null){transport.close();transport=null;}}
}
