package kr.keymate.app;

import java.util.EnumMap;

/** Separate caches and in-flight requests keep a late chart from replacing another group. */
final class HomeFeed {
 static final class State {
  FeaturedSongs.Chart chart;
  boolean loading, failed;
  long attemptedAt;
 }
 private final EnumMap<HomeCategory,State> states=new EnumMap<>(HomeCategory.class);
 private HomeCategory selected;
 HomeFeed(HomeCategory selected) {
  this.selected=selected;for(HomeCategory category:HomeCategory.values())states.put(category,new State());
 }
 HomeCategory selected() { return selected; }
 void select(HomeCategory category) { selected=category; }
 State state(HomeCategory category) { return states.get(category); }
 void restore(HomeCategory category,FeaturedSongs.Chart chart) {
  if(chart!=null&&chart.category!=category)throw new IllegalArgumentException("Chart category mismatch");
  state(category).chart=chart;
 }
 boolean begin(HomeCategory category,long now,boolean force) {
  State state=state(category);
  if(!category.isChart()||state.loading)return false;
  boolean throttled=state.attemptedAt>0&&now>=state.attemptedAt&&now-state.attemptedAt<60_000;
  if(!force&&((state.chart!=null&&state.chart.isFresh(now))||throttled))return false;
  state.attemptedAt=now;state.loading=true;state.failed=false;return true;
 }
 void complete(HomeCategory category,FeaturedSongs.Chart chart) {
  if(chart!=null&&chart.category!=category)throw new IllegalArgumentException("Chart category mismatch");
  State state=state(category);state.loading=false;state.failed=chart==null;
  if(chart!=null)state.chart=chart;
 }
}
