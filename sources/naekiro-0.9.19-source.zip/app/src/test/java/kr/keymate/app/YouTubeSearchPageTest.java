package kr.keymate.app;
import java.io.IOException;
import org.junit.Test;
import static org.junit.Assert.*;
import okhttp3.HttpUrl;

public class YouTubeSearchPageTest {
 private String video(String id,String title){return "{\"videoRenderer\":{\"videoId\":\""+id+"\",\"title\":{\"runs\":[{\"text\":\""+title+"\"}]},\"ownerText\":{\"simpleText\":\"Channel\"}}}";}
 @Test public void readsRankedArraysDeduplicatesAndNeverExecutesMarkup()throws Exception{
  String json="{\"contents\":["+video("Upe2ewoz1PI","아이유 {夜} \\\"test\\\"")+","+video("Upe2ewoz1PI","duplicate")+","+video("invalid","bad")+","+video("k9QvUzisLEI","&lt;script&gt;")+"]}";
  java.util.List<Song> songs=YouTubeSearchPage.parse("<script>window[\"ytInitialData\"] = "+json+"; window.evil();</script>");
  assertEquals(2,songs.size());assertEquals("아이유 {夜} \"test\" · Channel",songs.get(0).title);
  assertEquals("https://www.youtube.com/watch?v=k9QvUzisLEI",songs.get(1).url);assertTrue(SearchSafety.thumbnail(songs.get(0).thumbnailUrl));
 }
 @Test public void distinguishesEmptyResultsFromAnUnexpectedPage()throws Exception{
  assertTrue(YouTubeSearchPage.parse("var ytInitialData = {\"contents\":[]};").isEmpty());
  for(String text:new String[]{"<html>Sign in</html>","var ytInitialData = {", "var ytInitialData = {broken}"})assertThrows(IOException.class,()->YouTubeSearchPage.parse(text));
  assertThrows(IOException.class,()->YouTubeSearchPage.parse("var ytInitialData = {\"contents\":"+"[".repeat(81)+"]".repeat(81)+"}"));
 }
 @Test public void encodesQueryAsOneValueAndKeepsLocaleSeparate(){
  String query="아이유 &gl=XX <script>";HttpUrl url=HttpUrl.parse(YouTubeSearchPage.url(query,AppLanguage.JA));
  assertEquals(query,url.queryParameter("search_query"));assertEquals("JP",url.queryParameter("gl"));assertEquals("ja",url.queryParameter("hl"));
 }
 @Test public void metadataClientCannotBecomeAnArbitraryProxy(){
  assertTrue(HttpDownloader.allowed(HttpUrl.get("https://www.youtube.com/results?search_query=test")));
  assertTrue(HttpDownloader.allowed(HttpUrl.get("https://suggestqueries.google.com/complete/search?q=test")));
  for(String url:new String[]{"http://www.youtube.com/results","https://www.youtube.com/redirect", "https://youtube.com.example.com/results", "https://127.0.0.1/results", "https://user@www.youtube.com/results", "https://www.youtube.com:444/results"})assertFalse(url,HttpDownloader.allowed(HttpUrl.get(url)));
 }
}
