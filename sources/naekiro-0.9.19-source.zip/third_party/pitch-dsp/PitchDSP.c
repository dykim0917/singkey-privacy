#include "PitchDSP.h"
#include "vendor/sonic.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdatomic.h>

#define SK_CHUNK 256
#define SK_LATENCY 0.080

// Sonic preserves tempo while resampling pitch. A preallocated FIFO absorbs its
// variable block output; the matching video offset keeps the content aligned.
// All allocation occurs in Create/Destroy, outside the realtime process path.
struct SKPitch {
    sonicStream stream;
    float *input, *output, *fifo;
    uint32_t channels, capacity, latency, read, count;
    uint64_t segmentInput, segmentOutput;
    float ratios[25];
    int appliedKey;
    _Atomic int key, healthy;
    _Atomic uint64_t processedFrames, audibleFrames;
};
double SKPitchLatencySeconds(void) { return SK_LATENCY; }
SKPitch *SKPitchCreate(double rate, uint32_t channels) {
    if (!isfinite(rate) || rate < 8000 || rate > 192000 || channels < 1 || channels > 8) return NULL;
    SKPitch *p = calloc(1, sizeof(SKPitch));
    if (!p) return NULL;
    p->channels = channels; p->capacity = (uint32_t)(rate * .5) + 4096;
    p->latency = (uint32_t)llround(rate * SK_LATENCY); p->count = p->latency;
    p->stream = sonicCreateStream((int)llround(rate), (int)channels);
    p->input = calloc(SK_CHUNK * channels, sizeof(float));
    p->output = calloc(SK_CHUNK * channels, sizeof(float));
    p->fifo = calloc((size_t)p->capacity * channels, sizeof(float));
    if (!p->stream || !p->input || !p->output || !p->fifo) { SKPitchDestroy(p); return NULL; }
    for (int k = -12; k <= 12; k++) {
        // Match tempo to the integer resampling ratio. Sonic's local 64-bit
        // resampler preserves full rates (including exact 44.1 kHz octaves).
        int oldRate = (int)llround(rate), newRate = (int)llround(oldRate / pow(2.0, k / 12.0));
        p->ratios[k + 12] = (float)oldRate / newRate;
    }
    atomic_init(&p->key, 0); atomic_init(&p->healthy, 1); atomic_init(&p->processedFrames, 0);
    atomic_init(&p->audibleFrames, 0);
    return p;
}
void SKPitchDestroy(SKPitch *p) {
    if (!p) return;
    if (p->stream) sonicDestroyStream(p->stream);
    free(p->input); free(p->output); free(p->fifo); free(p);
}
void SKPitchSetKey(SKPitch *p, int key) {
    if (p) atomic_store_explicit(&p->key, key < -12 ? -12 : key > 12 ? 12 : key, memory_order_relaxed);
}
int SKPitchIsHealthy(SKPitch *p) { return p ? atomic_load_explicit(&p->healthy, memory_order_relaxed) : 0; }
uint64_t SKPitchProcessedFrames(SKPitch *p) { return p ? atomic_load_explicit(&p->processedFrames, memory_order_relaxed) : 0; }
uint64_t SKPitchAudibleFrames(SKPitch *p) { return p ? atomic_load_explicit(&p->audibleFrames, memory_order_relaxed) : 0; }
void SKPitchReset(SKPitch *p) {
    if (!p) return;
    sonicResetStream(p->stream);
    memset(p->fifo, 0, (size_t)p->capacity * p->channels * sizeof(float));
    p->read = 0; p->count = p->latency;
    p->segmentInput = p->segmentOutput = 0;
    atomic_store_explicit(&p->healthy, 1, memory_order_relaxed);
}
static void drain(SKPitch *p) {
    int received;
    while (SKPitchIsHealthy(p) && (received = sonicReadFloatFromStream(p->stream, p->output, SK_CHUNK)) > 0) {
        if ((uint32_t)received > p->capacity - p->count) { atomic_store_explicit(&p->healthy, 0, memory_order_relaxed); return; }
        for (int f = 0; f < received; f++) {
            uint32_t at = (p->read + p->count) % p->capacity;
            memcpy(p->fifo + at * p->channels, p->output + f * p->channels, p->channels * sizeof(float));
            p->count++;
        }
        p->segmentOutput += (uint64_t)received;
    }
}
static void changeKey(SKPitch *p, int key) {
    // Finish the previous factor before changing the resampler. Otherwise its
    // queued source samples are interpreted at a new factor and time drifts.
    if (p->segmentInput) {
        if (!sonicFlushStream(p->stream)) atomic_store_explicit(&p->healthy, 0, memory_order_relaxed);
        drain(p);
        int64_t remaining = (int64_t)p->segmentInput - (int64_t)p->segmentOutput;
        if (remaining < 0 && (uint64_t)(-remaining) <= p->count) p->count -= (uint32_t)(-remaining);
        else if (remaining >= 0 && (uint64_t)remaining <= p->capacity - p->count) {
            while (remaining-- > 0) {
                uint32_t at = (p->read + p->count) % p->capacity;
                memset(p->fifo + at * p->channels, 0, p->channels * sizeof(float)); p->count++;
            }
        } else atomic_store_explicit(&p->healthy, 0, memory_order_relaxed);
    }
    sonicResetStream(p->stream);
    p->segmentInput = p->segmentOutput = 0;
    sonicSetPitch(p->stream, p->ratios[key + 12]); p->appliedKey = key;
}
void SKPitchProcess(SKPitch *p, float **channels, uint32_t frames, uint32_t stride) {
    if (!p || !channels || stride < 1) return;
    for (uint32_t c = 0; c < p->channels; c++) if (!channels[c]) return;
    int key = atomic_load_explicit(&p->key, memory_order_relaxed);
    if (p->appliedKey != key && SKPitchIsHealthy(p)) changeKey(p, key);
    for (uint32_t offset = 0; offset < frames;) {
        uint32_t n = frames - offset; if (n > SK_CHUNK) n = SK_CHUNK;
        if (SKPitchIsHealthy(p)) {
            for (uint32_t f = 0; f < n; f++) for (uint32_t c = 0; c < p->channels; c++) {
                float value = channels[c][(offset + f) * stride];
                p->input[f * p->channels + c] = isfinite(value) ? fmaxf(-1, fminf(1, value)) : 0;
            }
            if (!sonicWriteFloatToStream(p->stream, p->input, (int)n)) atomic_store_explicit(&p->healthy, 0, memory_order_relaxed);
            p->segmentInput += n;
            drain(p);
            if (p->count < n) atomic_store_explicit(&p->healthy, 0, memory_order_relaxed);
        }
        int healthy = SKPitchIsHealthy(p);
        uint32_t audible = 0;
        for (uint32_t f = 0; f < n; f++) {
            int hasSignal = 0;
            for (uint32_t c = 0; c < p->channels; c++) {
                float value = healthy ? p->fifo[p->read * p->channels + c] : 0;
                channels[c][(offset + f) * stride] = value;
                hasSignal |= fabsf(value) > .000001f;
            }
            audible += hasSignal;
            if (healthy) { p->read = (p->read + 1) % p->capacity; p->count--; }
        }
        atomic_fetch_add_explicit(&p->audibleFrames, audible, memory_order_relaxed);
        offset += n;
    }
    atomic_fetch_add_explicit(&p->processedFrames, frames, memory_order_relaxed);
}
