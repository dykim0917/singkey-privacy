# Naekiro 0.9.19 corresponding source

Package kr.keymate.app. Naekiro (formerly SingKey) code is GPL-3.0-or-later with the
additional permission in LICENSE-GOOGLE-SDK-EXCEPTION.txt. Third-party terms
are listed in THIRD_PARTY_NOTICES.md. Google SDKs retain their own terms.

Build with JDK 17 and Android SDK 36. Set sdk.dir in local.properties, then run
./gradlew assembleDebug testDebugUnitTest lintDebug (gradlew.bat on Windows).
Debug uses official test ad units. Without monetization.properties it uses
Google's sample app ID; only this debug sample-app mode skips publisher UMP.
For the configured publisher app, consent is handled by UMP in debug too.
-PsingkeyAdsEnabled=false disables ad requests and placements (SDKs remain).

PostHog analytics is optional and off until user consent. Copy the example
analytics configuration and supply a public EU ingestion-only project token
to enable it. No personal/admin API key belongs in the app. No Firebase SDK
or NewPipeExtractor is packaged. Browser playback uses AndroidX WebKit and
the Sonic WASM asset; its source, modifications and Emscripten build script
are in third_party/pitch-dsp. The packaged WASM is the output of that script.
Run node scripts/test-android-browser.cjs for DSP and playback-state checks.

Release requires your own signing key via SINGKEY_UPLOAD_STORE and
SINGKEY_UPLOAD_PASSWORD, analytics configuration, and all real Android AdMob
IDs from monetization.properties.example when ads are enabled. The Windows
release script can manage a local upload key. All credentials, local config,
generated builds and personal data are excluded from this archive.

Gradle downloads version-pinned dependencies from settings.gradle repositories.
SOURCE_MANIFEST.sha256 records every other included file for verification.
