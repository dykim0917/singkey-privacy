// Compatibility entry point; privacy content has its own maintained pages.
require('./export-naekiro-brand.cjs');
