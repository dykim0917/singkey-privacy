// Export the code-native Naekiro identity consistently for Android and publishing.
// The Imagegen exploration is preserved separately; this draws fresh vector assets.
const fs = require('node:fs');
const path = require('node:path');
const sharp = require('sharp');
const root = path.resolve(__dirname, '..');
const out = path.join(root, 'docs/brand/naekiro');
const res = path.join(root, 'app/src/main/res');
const navy = '#0B0E14', lime = '#CCFF00', white = '#F0F4F8';
const capsule = (x,y,w,h,r) => `M${x+r} ${y}H${x+w-r}A${r} ${r} 0 0 1 ${x+w} ${y+r}V${y+h-r}A${r} ${r} 0 0 1 ${x+w-r} ${y+h}H${x+r}A${r} ${r} 0 0 1 ${x} ${y+h-r}V${y+r}A${r} ${r} 0 0 1 ${x+r} ${y}Z`;
const circle = (x,y,r) => `M${x-r} ${y}A${r} ${r} 0 1 0 ${x+r} ${y}A${r} ${r} 0 1 0 ${x-r} ${y}Z`;
const shapes = [
 [white, capsule(64,48,16,304,8)], [white,circle(72,280,27)],
 [white, capsule(320,48,16,304,8)], [white,circle(328,120,27)],
 [lime,capsule(190,48,20,126,10)], [lime,capsule(190,226,20,126,10)],
 [lime,`${circle(200,200,50)} ${circle(200,200,24)}`,'evenodd']
];
const mark = shapes.map(([c,d,rule]) => `<path fill="${c}" d="${d}"${rule?' fill-rule="evenodd"':''}/>`).join('');
const svg = (w,h,body) => `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${body}</svg>`;
const text = (value,x,y,size,color=white,extra='') => `<text x="${x}" y="${y}" font-family="Malgun Gothic, Arial, sans-serif" font-size="${size}" font-weight="700" fill="${color}" ${extra}>${value}</text>`;
function write(file,value) { fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,value); }
async function asset(name,source) {write(path.join(out,name+'.svg'),source);await sharp(Buffer.from(source)).png().toFile(path.join(out,name+'.png'));}
function vector(width,height,viewport,transform='') {
 const paths=shapes.map(([c,d,rule])=>`    <path android:fillColor="${c}" android:pathData="${d}"${rule?' android:fillType="evenOdd"':''} />`).join('\n');
 return `<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="${width}dp" android:height="${height}dp" android:viewportWidth="${viewport}" android:viewportHeight="${viewport}">\n${transform?`  <group ${transform}>\n`:''}${paths}\n${transform?'  </group>\n':''}</vector>\n`;
}
(async()=>{
 fs.mkdirSync(out,{recursive:true});
 await asset('naekiro-symbol',svg(400,400,mark));
 await asset('icon-512',svg(512,512,`<rect width="512" height="512" fill="${navy}"/><g transform="translate(36 36) scale(1.1)">${mark}</g>`));
 for(const [locale,name,tag] of [['ko','내키로','유튜브에서 찾은 그 버전, 내 키로.'],['en','Naekiro','That version you found. In your key.'],['ja','Naekiro','好きなアレンジを、自分のキーで。']]) {
  await asset(`wordmark-${locale}`,svg(840,240,`<g transform="translate(8 12) scale(.54)">${mark}</g>${text(name,260,159,locale==='ko'?104:100)}`));
  await asset(`feature-${locale}-1024x500`,svg(1024,500,`<rect width="1024" height="500" fill="${navy}"/><g transform="translate(66 80) scale(.85)">${mark}</g>${text(name,442,246,locale==='ko'?94:86)}${text(tag,445,308,locale==='ko'?24:20,'#B9C3D0')}`));
  const splash=svg(400,160,text(name,200,94,locale==='ko'?58:52,white,'text-anchor="middle"'));
  const folder=locale==='ko'?'drawable-ko-nodpi':'drawable-nodpi';
  if(locale!=='ja'){fs.mkdirSync(path.join(res,folder),{recursive:true});await sharp(Buffer.from(splash)).png().toFile(path.join(res,folder,'naekiro_splash_wordmark_art.png'));}
 }
 write(path.join(res,'drawable/naekiro_mark.xml'),vector(56,56,400));
 write(path.join(res,'drawable/naekiro_launcher.xml'),vector(108,108,108,'android:scaleX="0.16" android:scaleY="0.16" android:translateX="22" android:translateY="22"'));
 write(path.join(res,'drawable/naekiro_splash_icon.xml'),vector(288,288,600,'android:translateX="100" android:translateY="100"'));
 for(const [name,content] of [
  ['naekiro_splash_wordmark.xml','<layer-list xmlns:android="http://schemas.android.com/apk/res/android"><item android:width="200dp" android:height="80dp"><bitmap android:src="@drawable/naekiro_splash_wordmark_art" android:gravity="fill" android:filter="true" /></item></layer-list>\n'],
  ['naekiro_splash_background.xml','<layer-list xmlns:android="http://schemas.android.com/apk/res/android"><item android:drawable="@color/singkey_navy"/><item android:width="288dp" android:height="288dp" android:gravity="center" android:drawable="@drawable/naekiro_splash_icon"/><item android:width="200dp" android:height="80dp" android:gravity="bottom|center_horizontal" android:bottom="32dp" android:drawable="@drawable/naekiro_splash_wordmark"/></layer-list>\n']
 ])write(path.join(res,'drawable',name),content);
 // Store entry points used by earlier tooling now point to the current identity.
 for(const ext of ['svg','png']){
  fs.copyFileSync(path.join(out,`icon-512.${ext}`),path.join(root,`docs/play/assets/icon-512.${ext}`));
  fs.copyFileSync(path.join(out,`feature-ko-1024x500.${ext}`),path.join(root,`docs/play/assets/feature-1024x500.${ext}`));
 }
 console.log('Exported Naekiro vector identity, localized wordmarks, Android splash/launcher and store assets.');
})().catch(e=>{console.error(e);process.exitCode=1;});
